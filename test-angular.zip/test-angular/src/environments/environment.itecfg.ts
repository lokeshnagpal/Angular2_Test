export const environment = {
  production: false,

  // CFC URLs
  environmentUrl: 'https://corflowclm-ite.swissreapps-np.com/cfg/',
  loadClaim: 'https://corflowclm-ite.swissreapps-np.com/cfg/ws/restApp/claim/',
  loadTaskDetails: 'https://corflowclm-ite.swissreapps-np.com/cfg/ws/restApp/claim/tasks',
  saveTaskComments: 'https://corflowclm-ite.swissreapps-np.com/cfg/ws/restApp/task/comments',
  taskComments: 'https://corflowclm-ite.swissreapps-np.com/cfg/ws/restApp/task/',
  lookupUrl: 'https://corflowclm-ite.swissreapps-np.com/cfg/ws/restApp/corflowClaim',
  taskServiceUrl: 'https://corflowclm-ite.swissreapps-np.com/cfg/ws/restApp/task/',
  getClaimSummaryUrl: 'https://corflowclm-ite.swissreapps-np.com/cfg/ws/restApp/overview/claim/',
  saveClaimSummaryUrl: 'https://corflowclm-ite.swissreapps-np.com/cfg/ws/restApp/claim/summary',
  processStepUrl: 'https://corflowclm-ite.swissreapps-np.com/cfg/ws/restApp/task/processSteps/',
  taskDetailsUrl: 'https://corflowclm-ite.swissreapps-np.com/cfg/ws/restApp/llr/',
  taskOverviewUrl: 'https://corflowclm-ite.swissreapps-np.com/cfg/ws/restApp/overview/task/',
  startTask: 'https://corflowclm-ite.swissreapps-np.com/cfg/ws/restApp/llr',
  ackTemplateUrl: 'https://corflowclm-ite.swissreapps-np.com/cfg/acknowledgement/loadAcknowledgementDetails',
  uploadUrl: 'https://corflowclm-ite.swissreapps-np.com/cfg/servlet.appld',
  searchUrl: 'https://corflowclm-ite.swissreapps-np.com/cfg/ws/restApp/corflowClaim/search',
  statsUrl: 'https://corflowclm-ite.swissreapps-np.com/cfg/ws/restApp/corflowClaim/stats',
  getFilterValuesUrl: 'https://corflowclm-ite.swissreapps-np.com/cfg/ws/restApp/corflowClaim/filter',
  llenTaskList: 'https://corflowclm-ite.swissreapps-np.com/cfg/ws/restApp/claim/tasks',
  financialUrl: 'https://corflowclm-ite.swissreapps-np.com/cfg/ws/restApp/financial/',
  documentUrl: 'https://corflowclm-ite.swissreapps-np.com/cfg/ws/restApp/document/',
  customSettingsUrl: 'https://corflowclm-ite.swissreapps-np.com/cfg/ws/restApp/corflowClaim/filter/custom',
  actionButtonsUrl: 'https://corflowclm-ite.swissreapps-np.com/cfg/ws/restApp//task/',
  policyDocumentsUrl: 'https://corflowclm-ite.swissreapps-np.com/cfg/ws/restApp/policyDocument/',

  // Others
  streamingServlet: 'https://corsoedms-test.swissreapps-np.com/cs1/StreamingServlet',
  uploadDocument: 'https://cordoc-test.swissreapps-np.com/c1v/service/',
  manApiUrl: 'https://man-train1.swissreapps-np.com/claim-app',

  // CCC URLs
  edmsSearchUrl: 'https://corflowclm-ite.swissreapps-np.com/ccg/claimAdditionalModule/getDocuments',
  saveUrl: 'https://corflowclm-ite.swissreapps-np.com/ccg/claimHandlingAgreement/saveAgreementDetails',
  chaSearchUrl: 'https://corflowclm-ite.swissreapps-np.com/ccg/claimAdditionalModule/Search',
  claimHandlingAttributesUrl: 'https://corflowclm-ite.swissreapps-np.com/ccg/claimHandlingAgreement/getAttributes',
  savePreferredPartnersUrl: 'https://corflowclm-ite.swissreapps-np.com/ccg/claimHandlingAgreement/savePartnerData/',
  saveNotesUrl: 'https://corflowclm-ite.swissreapps-np.com/ccg/claimHandlingAgreement/saveNotesData/',
  saveCommunicationUrl: 'https://corflowclm-ite.swissreapps-np.com/ccg/claimHandlingAgreement/saveCommunication/',
  programDetailsUrl: 'https://corflowclm-ite.swissreapps-np.com/ccg/claimAdditionalModule/loadTableInfo/PROGRAM_TABLE',
  preferredPartnersUrl: 'https://corflowclm-ite.swissreapps-np.com/ccg/claimAdditionalModule/loadTableInfo/PREFFERED_PARTNERS_TABLE',
  noteCheckUrl: 'https://corflowclm-ite.swissreapps-np.com/ccg/claimAdditionalModule/loadTableInfo/CHA_NOTES_TABLE',
  communicationUrl: 'https://corflowclm-ite.swissreapps-np.com/ccg/claimAdditionalModule/loadTableInfo/CHA_COMMUNICATIONS_TABLE',
  workingLayerUrl: 'https://corflowclm-ite.swissreapps-np.com/ccc/excessTower',
  cccLookupUrl: 'https://corflowclm-train3.swissreapps-np.com/ccc/claimAdditionalModule/getLookupValues/'
};
