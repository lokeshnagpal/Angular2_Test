
import { Injectable, Inject } from '@angular/core';
import { Http, Headers, RequestOptions } from '@angular/http';

import { HttpClientModule,HttpClient } from '@angular/common/http';
// import { HttpModule } from '@angular/http';
import { Observable, Subject } from 'rxjs';
import { map } from 'rxjs/operators';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';
@Injectable()
export class ClientService {

    private cardReqDetails = {
        cardName: '',
        responseRecieved: false,
        showProgressBar: false
    }
    private url: string;
    private sharePointsearchFldrName: any;
    private attributesToGetData: any;
    private options: any;
    private headers: any;
    private urlToXml: any;
    public claimNumber:any;
    public queryParams: any;
    private subject = new Subject<any>();
    public overviewData = new BehaviorSubject<any>({});
    constructor(private _http: Http,private httpClient:HttpClient) {

    }

    public setUrl(url, attr?) {
        if (attr) {
            if (typeof (attr) != 'string') {
                this.attributesToGetData = JSON.stringify(attr);
            } else {
                this.attributesToGetData = attr;
            }
            this.url = url + this.attributesToGetData;
        } else {
            this.url = url
        }


    }

    public getClientData():Observable<any>{
      return this.httpClient.get(this.url,{withCredentials:true}).pipe(map(response =>{
                this.cardReqDetails.responseRecieved = true;
               this.cardReqDetails.showProgressBar = false;
               return response
      }))
        // return this._http.get(this.url).pipe(map(response => {
        //     this.cardReqDetails.responseRecieved = true;
        //     this.cardReqDetails.showProgressBar = false;
        //     return response.json()
        // }));
    }

    public postClientData(attr):Observable<any> {
    //    this.headers = new Headers();       
    //     this.options = new RequestOptions({ headers: this.headers, withCredentials: true }); // Create a request option (For Local env)
    //     let dummy = JSON.stringify(attr);
    //     return this._http.post(this.url, dummy, this.options).pipe(map(response => {
    //         this.cardReqDetails.responseRecieved = true;
    //         this.cardReqDetails.showProgressBar = false;
    //         return response.json()
    //     }));

    this.headers = new Headers();       
    this.options = new RequestOptions({ headers: this.headers, withCredentials: true }); // Create a request option (For Local env)
    let dummy = JSON.stringify(attr);
    return this.httpClient.post(this.url, dummy, this.options).pipe(map(response => {
        this.cardReqDetails.responseRecieved = true;
        this.cardReqDetails.showProgressBar = false;
        return response
    }));

    }

    public postClaimsData(attr):Observable<any> {
    //     this.headers = new Headers();
    //  this.headers.append('Content-Type', 'application/json');
    //      this.options = new RequestOptions({ headers: this.headers, withCredentials: true }); // Create a request option (For Local env)
    //  let dummy =((attr));
    //      return this._http.post(this.url,(dummy), this.options).pipe(map(response => {
    //          this.cardReqDetails.responseRecieved = true;
    //          this.cardReqDetails.showProgressBar = false;
    //          return response;
    //      }));

          this.headers = new Headers();
     this.headers.append('Content-Type', 'application/json');
         this.options = new RequestOptions({ headers: this.headers, withCredentials: true }); // Create a request option (For Local env)
     let dummy =((attr));
         return this.httpClient.post(this.url,(dummy), this.options).pipe(map(response => {
             this.cardReqDetails.responseRecieved = true;
             this.cardReqDetails.showProgressBar = false;
             return response;
         }));
     
     }

    public postCCCData(attr):Observable<any> {
        // this.headers = new Headers();
        //   //this.headers.append('Content-Type', 'application/json');
        //  this.options = new RequestOptions({ headers: this.headers, withCredentials: true }); // Create a request option (For Local env)
        //  let dummy = JSON.parse(JSON.stringify(attr));
        //  return this._http.post(this.url, dummy, this.options).pipe(map(response => {
        //      this.cardReqDetails.responseRecieved = true;
        //      this.cardReqDetails.showProgressBar = false;
        //      return response.json();
        //  }));

        this.headers = new Headers();
        this.headers.append('Content-Type', 'application/json');
            this.options = new RequestOptions({ headers: this.headers, withCredentials: true }); // Create a request option (For Local env)
        let dummy =((attr));
            return this.httpClient.post(this.url,(dummy), this.options).pipe(map(response => {
                this.cardReqDetails.responseRecieved = true;
                this.cardReqDetails.showProgressBar = false;
                return response;
            }));
     }
    public getFileNoteDisplayData() {
        return this._http.get(this.url).pipe(map(response => {
            return response.json();
        }));
    }

    public setXmlUrl(url) {
        this.urlToXml = url;
    }
    public getXml() {
        return this._http.get(this.urlToXml).pipe(map(response => response));
    }

    public setSharePointName(nameToSearch) {
        this.sharePointsearchFldrName = nameToSearch;
    }
    public getSharePointName() {
        return this.sharePointsearchFldrName;
    }
    // public getJsonData():Observable<any>{
    //     let jsonUrl="./assets/jsonFile.json";
    //     return this._http.get(jsonUrl).pipe(map(response => response.json()));
    // }

    // method to set the details of card that made service request
    public setCardReqDetails(cardName) {
        this.cardReqDetails.cardName = cardName;
        this.cardReqDetails.responseRecieved = false;
        setTimeout(() => {
            if (!this.cardReqDetails.responseRecieved) {
                this.cardReqDetails.showProgressBar = true;
            }
        }, 400)
    }

    // method to return the reqCardDetails
    public getCardReqDetails() {
        return this.cardReqDetails;
    }

    public setClaimNumber(val){
        this.claimNumber=val;
    }
    public getClaimNumber(){
        return this.claimNumber;
    }

    public getDiaryTableData(attr){
        const headers = new Headers({ 'Content-Type': 'text/plain' });
        const options = new RequestOptions({ headers: headers, withCredentials: true});
        return this._http.post(this.url, JSON.stringify(attr), options);
    }

    public testUpload(formData) {
        const options = new RequestOptions({ withCredentials: true});
        return this._http.post(this.url, formData, options);
    }
    public setQueryParams(obj) {
        this.queryParams = obj;
    }
    public getQueryParams() {
        return this.queryParams;
    }
    public setProgramObservable(obj: any) {
        this.subject.next(obj);
    }
    public getProgramObservable(): Observable<any> {
        return this.subject.asObservable();
    } 
    public getDocuments(){
        return this._http.get(this.url).pipe(map(response=>{
      return response.json()
        }))
    }
    public linkDocuments(attr){
        const headers = new Headers({ 'Content-Type': 'text/plain' });
        const options = new RequestOptions({ headers: headers, withCredentials: true});
        return this._http.post(this.url, JSON.stringify(attr), options);
        }
        public postLayer(attr){
            const headers = new Headers({ 'Content-Type': 'application/json' });
            const options = new RequestOptions({ headers: headers, withCredentials: true});
            return this._http.post(this.url, JSON.stringify(attr), options);
            }
     
            public setOverviewData(data): void {
                this.overviewData.next(data);
              }
              public getOverviewData(): Observable<any> {
                return this.overviewData.asObservable();
              }    
              public getClientsData() {
              return this._http.get(this.url).pipe(map(response =>  response.text() ? response.json() : {}));
              }
}
