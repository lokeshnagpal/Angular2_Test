import { Injectable, Inject } from '@angular/core';
import {Headers, RequestOptions,Http } from '@angular/http';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';
// import "rxjs/add/operator/map";
import { HttpClientModule ,HttpClient} from '@angular/common/http';
// import { HttpModule } from '@angular/http';


// @Injectable({
//   providedIn: 'root'
// })
export class BaseHttpService {

  
  constructor(public httpClient) { }

  public httpGet(url:string):Observable<any>{
    // return this._http.get(this.url).map(res => res.json());
    // return this._http.get(url).pipe(map(response => response.json()));
    return this.httpClient.get(url,{withCredentials:true}).pipe(map(response =>{   
     return response
}))
}

public httpPost(url:string,data:any):Observable<any>  {
    // let headers = new Headers();   
    // let options = new RequestOptions({ headers: headers, withCredentials: true }); // Create a request option (For Local env)
    // let dummy = JSON.stringify(data);
    // return this._http.post(url, dummy, options).pipe(map(response =>response.json()));

    let headers = new Headers();       
    let options = new RequestOptions({ headers: headers, withCredentials: true }); // Create a request option (For Local env)
    let dummy = JSON.stringify(data);
    return this.httpClient.post(url, dummy, options).pipe(map(response => {    
        return response
    }));

}


}
