import { ApplicationStateService } from './util/application.state.service';

import { Component,HostListener } from '@angular/core';
//import { createEpicMiddleware } from 'redux-observable';
//import { NgRedux, NgReduxModule } from '@angular-redux/store';
//import { IAppState, rootReducer, INITIAL_STATE } from './store/store';


// const epicMiddleware = createEpicMiddleware(diaryAsyncHandler);
// const middlewares = [ epicMiddleware ];


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})

export class AppComponent {
  title = 'CorflowClaims';
  // constructor (ngRedux: NgRedux<IAppState>) {
    //Configures the redux at the root level
    // ngRedux.configureStore(rootReducer, INITIAL_STATE,  middlewares,
    //   []);
   // }
   constructor(public appStateService:ApplicationStateService){}


   @HostListener('window:resize', ['$event'])
   onResize(event) {
    this.appStateService.onResize(event);
   
   }
}
