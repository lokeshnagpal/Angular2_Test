import { Routes, RouterModule }  from '@angular/router';
import { NgModule } from '@angular/core';
import { ClaimsHandlingAgreementComponent } from './claims-handling-agreement/claims-handling-agreement.component';


// noinspection TypeScriptValidateTypes
const routes: Routes = [
  {
    path: '',
    component: ClaimsHandlingAgreementComponent    
  }
];

// export const routing = RouterModule.forChild(routes);
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ClaimsRoutingModule { }