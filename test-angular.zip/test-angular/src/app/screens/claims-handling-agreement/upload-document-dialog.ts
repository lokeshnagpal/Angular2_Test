
import { Component, OnInit, ChangeDetectorRef, Input,Inject } from '@angular/core';
import { uploadObject } from './uploadObject';
import { environment } from 'src/environments/environment';
import { ClientService } from 'src/app/services/client.service';
import { MatSnackBar, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { CommonTransformerService } from 'src/app/util/common-transformer.service';
@Component({
  selector: 'app-upload-document-dialog',
  templateUrl: './upload-document-dialog.html',
  styleUrls: ['./upload-document-dialog.scss']
})
export class UploadDocumentsDialog {
public filesObj:any;
public fileData:any=[];
public  formFieldList:any= [];
public  formDatas:any;
public date=new Date();
public uploadList: uploadObject[] = [];
public uploadedList: any = [];
public uploadFormValid;
public urlToUploadDoc: any;
public selectedFilesForUpload = [];
public sendable: any;
public programUpload:any;
public  program: string;
public insured: string;
public dealId: string;
public sourceSystem: string;
public businessArea: string;
public function: string;
public region: string;
public progressBarForUpload:boolean = false;
public validateFlag: boolean = false;
public buttonHide: boolean = false;
public uploadFileLoad: boolean = false;
public fileUploaded: boolean = false;
public loadForm = false;
public uploadFlag: boolean;
public btnEnable: boolean = false;
public progressFlag: boolean = false;
public dialogHeading:any;
public imageUrl:any;
public fileExtension:any=[];
context: any = {
  businessArea: 'CHA',
  status: 'Upload'
};
 
 public programDetailData:any;
  constructor(public dialogRef: MatDialogRef<UploadDocumentsDialog>,@Inject(MAT_DIALOG_DATA) public data: any,private clientDataService:ClientService,  public commonTransformerService: CommonTransformerService) { }

  ngOnInit() {
      this.programDetailData= this.data.attributes;
      this.dialogHeading=this.data.header;
   let documentType={
     attrId:"3140",
     attrRules:[{rule:{ruleType: "NOTIFY_ON_VALUE_CHANGE"}, logicalExpression: false, executeOnSubmit: false, affectedAttributeId: "3164", affectedAttributeName: "Document Category",attributeValue: "ANY_VALUE"}],
     dbColumnName: "DOCUMENT_TYPE",
     group: "Document Category",
     name: "Document Type",
     secAttrMapId: "3163",
     sectionCode: "FINANCIAL_TASK_TYPE",
     sectionId: "157",
     sectionName: "Task Type",
     source: "HIERARCHICAL_REFDATA",
     type: "LOOKUP",
     readOnly: false
   }
  let documentCategory={
    attrId:"3141",
     attrRules:[],
     dbColumnName: "DOCUMENT_CATEGORY",
     name: "Document Category",
     secAttrMapId: "3164",
     sectionCode: "FINANCIAL_TASK_TYPE",
     sectionId: "157",
     sectionName: "Task Type",
     source: "HIERARCHICAL_REFDATA",
     type: "TEXTBOX",
     readOnly: true
  }
  this.formFieldList.push(documentType);
  this.formFieldList.push(documentCategory);
 
  }
//   public fileDroppedEvent(event) {
//    this.filesObj = {
//      target:{
//          files: event.target.files || event.dataTransfer.files 
//      }
    
//  };
//  this.fileData.push(this.filesObj);
//  console.log("1211",this.filesObj.target.files);
//  this.preventDefaultAndStopPropagation(event);
//  this.prepareToLoad();
// }
prepareForUpload(event){
 this.buttonHide = true;
    this.uploadList = [];
    this.fileData = [];
    this.uploadedList = [];
    
   
 for (let fl of event.target.files){
   this.fileData.push(fl)
  console.log("11",fl.name)
  let index=fl.name.indexOf(".");
  this.fileExtension=fl.name.slice(index+1);
  switch(this.fileExtension){
    case "txt": this.imageUrl="./assets/PDF_Icon.png";break;
    case "pdf":this.imageUrl="./assets/PDF_Icon.png";;break;
    case "html":this.imageUrl="./assets/PDF_Icon.png";;break;
    case "htm":this.imageUrl="./assets/PDF_Icon.png";;break;
    case  "doc":this.imageUrl="./assets/DOC_Icon.png";break;
    case "docx":this.imageUrl="./assets/DOC_Icon.png";break;
    case "ppt":this.imageUrl="./assets/PPT_Icon.png";break;
    case "pptx":this.imageUrl="./assets/PPT_Icon.png";break;
    case "eml":this.imageUrl="./assets/EML_Icon.png";break;
    case "xls":this.imageUrl="./assets/XLS_Icon.png";break;
    case "xlsx":this.imageUrl="./assets/XLS_Icon.png";break;
    case "ods":this.imageUrl="./assets/XLS_Icon.png";break;
    default :this.imageUrl="./assets/PDF_Icon.png";break;

  }
  console.log("uploadform", this.fileExtension,this.imageUrl);
   let dummyObj: uploadObject = {
    documentName: fl.name,
    documentCategory: "",
    documentType: "",
    documentId: '',
    documentDate: this.date,
    fileSelected: true,
    file: fl,
    uploadStatus: '',
    fileToBeUploaded: false,
    imgUrl:this.imageUrl
  };
  this.uploadList.push(dummyObj);
  this.btnEnable = true;
  this.uploadFlag = true;
  this.fileUploaded = true;
  this.uploadFileLoad = true;
//    this.ref.detectChanges();
   console.log(this.uploadList,"uploadlist")
}
 

//  this.uploadSelectedFiles.emit(filesObj);

 }
 updateUploadData(){
    let type:any;
    let category;
    for (let key in this.formDatas) {
         
        if (key=="DOCUMENT_TYPE") {   
     type=this.formDatas[key]}
     else if (key=="DOCUMENT_CATEGORY"){
category=this.formDatas[key]}
     }
     for(let index=0;index<this.uploadList.length;index++){
this.uploadList[index].documentCategory=category;
this.uploadList[index].documentType=type;
     }
 }
// method to clear the previous file selection
 clearSelection(val){
     if(val.files && val.files.length>0){
      val.value = '';
   this.fileData=[]
}
}
public preventDefaultAndStopPropagation(event) {
  event.preventDefault();
  event.stopPropagation();
}
public getCancel() {
  this.uploadList = [];
  this.fileData = [];
//   this.ref.detectChanges();
  // this.clearQueue.emit()
}
private uploadSelectedFile(event) {
  this.progressBarForUpload=true;
  this.uploadList = event;
  setTimeout(() => {
      this.uploadFile(event);
      this.progressBarForUpload=false;
  }, 200)
}

public uploadFile(event) {
    this.updateUploadData()
    console.log(this.uploadList,"updtaedlist")
    console.log("hieei1")
  this.uploadFormValid = true;
  for (let ele of this.uploadList) {
      ele.fileToBeUploaded = false;
  }
  for (let item of this.uploadList) {
      console.log("item",item)
      console.log("item1",item.documentType)
      console.log("item2",item.documentName)
      console.log("item3",item.documentDate)
      console.log("item4",item.documentCategory)
      let indexOfElement = this.uploadList.indexOf(item)
      item.fileToBeUploaded = true;
      if (item.documentDate == null) {
          item.documentDate = this.date;
      }
      if (item.documentType == '' || item.documentName == '' || item.documentDate == ''
          || !item.documentType || !item.documentDate || !item.documentName) {
          this.uploadFormValid = false;
      }
     
  }
  if (this.uploadFormValid) {
      console.log(this.programDetailData,"parentprogram")
      this.program=this.programDetailData[4].programId;
      this.businessArea=this.programDetailData[5].businessArea;
      this.sourceSystem=this.programDetailData[6].sourceSystem;
      this.function=this.programDetailData[7].function;
      this.region=this.programDetailData[8].region;
      this.dealId=this.programDetailData[3].value;
this.programUpload = "PR_"+this.programDetailData[9].program;
  // this.programUpload = this.programDetailData[4].programId;
  // this.programUpload = this.programDetailData[0].value;
  this.urlToUploadDoc = environment.uploadDocument+'uploadDocument' ;
  console.log("edmsUrl",this.urlToUploadDoc)
  console.log("hieei13")
  for (let fl of this.uploadList) {
    if (fl.documentId == '') {
         this.validateFlag = true;
         
        if (fl.documentName != '' && fl.documentType != '' && fl.documentDate != '') {
          this.sendable = new FormData();
          this.sendable.append('file', fl.file, fl.file.name);
          this.sendable.append('DOCUMENT_NAME', fl.documentName)
          this.sendable.append('DOC_INDEX', this.uploadList.indexOf(fl));
          this.sendable.append('DOCUMENT_CATEGORY', fl.documentCategory);
          this.sendable.append('DOCUMENT_TYPE', fl.documentType);
          this.sendable.append('DOCUMENT_DATE', this.dateInServiceFormat(fl.documentDate));
            
          this.sendable.append('SOURCE_SYSTEM',this.sourceSystem );
          this.sendable.append('BUSINESS_AREA',this.businessArea );
          this.sendable.append('REGION',this.region );
          this.sendable.append('FUNCTION',this.function);
          this.sendable.append('ACTIVITY_ID',  this.programUpload );
          this.sendable.append('DEAL_ID', this.dealId);
      this.progressFlag = true;
      console.log("hieei5iie",this.sendable)
     this.uploadFiles(this.sendable, fl);
     console.log("fileieei",this.fileExtension)
    //  this.dialogRef.close({event:'close'});
 
    }
    else {
        console.log("hi")
      this.progressBarForUpload = false;
      this.showMessage("Please fill mandatory fields to upload",5000)
  }
  

   }

  }
//   this.ref.detectChanges();
}
}
showMessage(errorMessage: string, durationValue: number) {
  this.commonTransformerService.showMessage(errorMessage, durationValue);
      }
public dateInServiceFormat(dateToConvert){
      let monthList = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
      let monthNUmbers = ["01","02","03","04","05","06","07","08","09","10","11","12"];
      let dateVal = String(dateToConvert);
      let formDate = dateVal.split(" ");
      let  dateFormat =  formDate[3]  +  "-"  +  (monthNUmbers[monthList.indexOf(formDate[1])])  +  "-"  +  formDate[2];
      if (dateFormat.indexOf('undefined') < 0) {
        return dateFormat;
    } else {
        return dateToConvert;
    }
 }

 public uploadFiles(sendable, fl) {
  let xhr = new XMLHttpRequest();
  
  let self = this;
  xhr.open('POST', this.urlToUploadDoc, true);
  xhr.withCredentials = true;
  xhr.send(sendable);
  xhr.onreadystatechange = function () {
    console.log(xhr.response,"e");
    console.log('uploaded ---------------------------------------------------', self.uploadList)
    self.dialogRef.close({event:'close',data:self.uploadList, header:self.dialogHeading});
      if (xhr.readyState == 4) {
          if (xhr.status == 200) {
              if (xhr.response != '') {
                  if (xhr.response.indexOf('User') < 0 && xhr.response.indexOf('STATUS') < 0) {
                         let objReturned
                      if (xhr.response.indexOf('\\') > 0) {
                          let dummy = xhr.response.split(',');
                          let dummy1 = dummy[1].split('""');
                          let dummy2 = dummy1[2].split(':');
                          let dummy3 = dummy2[1].split('}');
                          objReturned = dummy3[0]
                          console.log("res1",objReturned)
                      } else {
                          objReturned = JSON.parse(xhr.response)
                          console.log("res2",objReturned)
                          
                        
                      }
                      self.uploadList[objReturned.docIndex].documentId = objReturned.documentId
                      self.uploadedList.push(self.uploadList[objReturned.docIndex]);
                      self.selectedFilesForUpload.splice(self.selectedFilesForUpload.indexOf(self.uploadList[objReturned.docIndex]), 1);
                      console.log("res3",objReturned)
                      if (self.selectedFilesForUpload.length <= 0) {
                          self.btnEnable = false;
                          console.log("res4",objReturned)
                      }
                     self.validateFlag = false;
                      self.progressBarForUpload = false
                      // self.uploadSuccessEvent.emit(self.program) 
                    //   self.ref.detectChanges();
                    console.log("res5",objReturned);
                      xhr.abort();
                    
                      return;
                  } else {
                      let msg = JSON.parse(xhr.response)
                      console.log("flag",msg)
                      self.showMessage(msg.STATUS, 5000)
                      self.progressBarForUpload = false
                  }
              }
              else {
                console.log("res6","6")
               self.showMessage("Upload Failed", 5000 )
                  self.progressBarForUpload = false
              }
          } else if (xhr.status == 500) {
              self.progressBarForUpload = false;
              for (let file of self.uploadList) {
                  if (file.documentName == fl.documentName) {

                      file.uploadStatus = false;
                      break;
                  }
              }
              console.log(xhr.statusText,"B");
              console.log(xhr.response,"A")
              return;
          }
      }
      self.progressBarForUpload = false;
  }
  // self.dialogRef.close({event:'close'});
  this.uploadFileLoad=false;
  self.progressBarForUpload = true;
}
 
}

