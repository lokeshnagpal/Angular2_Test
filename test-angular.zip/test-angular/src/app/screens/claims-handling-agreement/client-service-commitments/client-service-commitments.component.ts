import { Component, OnInit, Input, SimpleChange, SimpleChanges, ChangeDetectorRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { ClientService } from 'src/app/services/client.service';
import { MatTableDataSource } from '@angular/material';

@Component({
  selector: 'app-client-service-commitments',
  templateUrl: './client-service-commitments.component.html',
  styleUrls: ['./client-service-commitments.component.scss']
})
export class ClientServiceCommitmentsComponent implements OnInit {

  @Input() public clientData ;
  @Input() public saveSuccess;
  @Input() public clearUnsaved;
  private communicationCheck: boolean;
  public  communicationColumnList: any;
  private communicationRowList: any = [];
  private communicationUrl: any;
  private communicationsTableCriteria: any;
    private communicationsTableRecordCount: any;
    private searchUrl: any;
    private claimHandlingAttributesUrl:string;
    public showdelete:boolean=false;
    public valueHolder:any=[] ;
    public tableData:any=[];
    public loadedData:any=[];   
  //  public dataSource:any;
   public tableUpdatedData:any = [];
   public id = 0;
   @Input() program;
  constructor(private route: ActivatedRoute ,private clientDataService:ClientService, private cdref: ChangeDetectorRef) {
      
    this.claimHandlingAttributesUrl=environment.claimHandlingAttributesUrl;
   this.communicationUrl=environment.communicationUrl;
   this.searchUrl=environment.chaSearchUrl;
  }

  displayedColumns: string[] = ['blank','CADANCE_VALUE', 'ACTIVITY_VALUE', 'COMMENTS_VALUE', 'delete','blank'];
  dataSource;
  ngOnInit() {
    this.loadComunicationTableData(true);
    }

ngOnChanges(changes: SimpleChanges){
  
  if (changes.clientData) {
    this.clientData.id = this.id++;
    this.tableUpdatedData=[...this.tableUpdatedData, this.clientData];
    this.dataSource=(this.tableUpdatedData);
  }
  if (changes.saveSuccess) {
    this.setDataAsFromService();
  }
if(changes.clearUnsaved){
  this.clearUnsavedData();
}
}
setDataAsFromService() {
  this.dataSource.forEach(row => {
    row.fromService = true;
  });
}
clearUnsavedData(){
  this.dataSource.forEach(row=>{
    if(!row.fromService){
      this.deleteRow(row);
    }
  });
}
  public loadComunicationTableData(initialLoad: boolean) {
    let self = this;
    let objToPost:any;
    this.clientDataService.setUrl(this.communicationUrl);
    this.clientDataService.getClientData().subscribe(res => {
        this.communicationCheck = true;
        if (initialLoad) {
            self.communicationColumnList = res.tableHeader;
              this.communicationsTableCriteria = {
                "sectionId": res.sectionDetails.sectionId,
                "sortDirection": res.defaultSortingParam,
                "sortColumnId": res.defaultSortingColumnId,
                "startRow": "1",
                "endRow": res.defaultRowsPerPage,
                "additionalCriteria": { "PROGRAM": this.program},
                "filterCriteria": {},
            };
        }

        let searchCriteria = {
            "sectionId": this.communicationsTableCriteria.sectionId,
            "sortDirection": this.communicationsTableCriteria.sortDirection,
            "sortColumnId": this.communicationsTableCriteria.sortColumnId,
            "startRow": this.communicationsTableCriteria.startRow,
            "endRow": this.communicationsTableCriteria.endRow,
            "additionalCriteria": this.communicationsTableCriteria.additionalCriteria,
            "filterCriteria": this.communicationsTableCriteria.filterCriteria,
            "subFilterCriteria": this.communicationsTableCriteria.subFilterCriteria,
        };
        this.clientDataService.setUrl(this.searchUrl);
       this.clientDataService.postCCCData(searchCriteria).subscribe(res => {
          
          self.communicationRowList = res.data;
          self.communicationsTableRecordCount = res.recordCount;
          this.tableUpdatedData = [];
          for (let i = 0; i < res.data.length; i++) {
            this.valueHolder=[];
            for (var name in res.data[i]) { 
              if(res.data[i][name].dbColumnName != 'PROGRAM_COMMUNICATIONS_ID'){
          objToPost=res.data[i][name].value
          this.valueHolder.push(objToPost);
             }
            }
            let formatedValue={
              'CADANCE_VALUE':this.valueHolder[0],
              'ACTIVITY_VALUE':this.valueHolder[1],
              'COMMENTS_VALUE':this.valueHolder[2],
              'fromService': true
            }
            if(formatedValue.ACTIVITY_VALUE!="" || formatedValue.CADANCE_VALUE!="" || formatedValue.COMMENTS_VALUE!="")
            this.tableUpdatedData.push(formatedValue)
        }
         
    this.dataSource=(this.tableUpdatedData);

       });
    });

}
deleteRow(elm) {

this.tableUpdatedData = this.tableUpdatedData.filter(value => value.id != elm.id);
this.dataSource = this.tableUpdatedData

}
}
