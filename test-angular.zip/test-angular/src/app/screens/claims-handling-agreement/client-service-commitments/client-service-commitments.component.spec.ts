import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClientServiceCommitmentsComponent } from './client-service-commitments.component';

describe('ClientServiceCommitmentsComponent', () => {
  let component: ClientServiceCommitmentsComponent;
  let fixture: ComponentFixture<ClientServiceCommitmentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClientServiceCommitmentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClientServiceCommitmentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
