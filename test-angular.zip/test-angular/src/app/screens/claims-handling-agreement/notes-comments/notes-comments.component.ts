import { Component, OnInit, Input, SimpleChanges, Output, EventEmitter } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { ClientService } from 'src/app/services/client.service';
import { DatePipe } from '@angular/common';
@Component({
  selector: 'app-notes-comments',
  templateUrl: './notes-comments.component.html',
  styleUrls: ['./notes-comments.component.scss']
})
export class NotesCommentsComponent implements OnInit {
  @Input() public notesData ;
  @Input() public saveSuccess;
  @Input() public clearUnsaved;
  @Input() program;
  @Output() noteEvent = new EventEmitter();
  public searchUrl: any;
  public claimHandlingAttributesUrl:string;
    public noteCheckUrl:string;
    public programId:any;
    public notesCheck: boolean;
   public notesColumnList: any = [];
    private notesRowList: any = [];
    public notesTableCriteria: any;
    private notesTableRecordCount: any;
    private noteFilterLookupVal: any;
    private data: any;
    public valueHolder:any=[] ;
    public tableData:any=[];
    public loadedData:any=[];    
    public sysDate:any;
  constructor(private route: ActivatedRoute ,private clientDataService:ClientService,private datePipe: DatePipe) {
      
    this.claimHandlingAttributesUrl=environment.claimHandlingAttributesUrl;
   this.noteCheckUrl=environment.noteCheckUrl;
   this.searchUrl=environment.chaSearchUrl;
  }

  ngOnInit() {
        this.loadNotesTableData(true);
    }
    ngOnChanges(changes: SimpleChanges){
      if (changes.notesData) {
        this.tableData.push({
          date: this.datePipe.transform(new Date(),"d MMM y"),
          note: this.notesData,
          fromService:false
        });
      }
  
      
      if (changes.saveSuccess) {
        this.setDataAsFromService();
      }
      if(changes.clearUnsaved){
        this.clearUnsavedData();
      }
      this.noteEvent.emit(this.tableData)
     
      }
      setDataAsFromService() {
        this.tableData.forEach(row => {
          row.fromService = true;
        });
      }
      clearUnsavedData(){
        let length=this.tableData.length;
  for(let index=length-1; index>=1;index--){
    this.deleteRow(index);
  }
      }




  public loadNotesTableData(initialLoad: boolean) {
    let self = this;
    this.clientDataService.setUrl(this.noteCheckUrl);
    this.clientDataService.getClientData().subscribe(res => {
      let objToPost: any;
        this.notesCheck = true;
        if (initialLoad) {
            self.notesColumnList = res.tableHeader;
            this.notesTableCriteria = {
                "sectionId": res.sectionDetails.sectionId,
                "sortDirection": res.defaultSortingParam,
                "sortColumnId": res.defaultSortingColumnId,
                "startRow": "1",
                "endRow": res.defaultRowsPerPage,
                "additionalCriteria": { "PROGRAM": this.program },
                "filterCriteria": {},
            };
        }

        let searchCriteria = {
            "sectionId": this.notesTableCriteria.sectionId,
            "sortDirection": this.notesTableCriteria.sortDirection,
            "sortColumnId": this.notesTableCriteria.sortColumnId,
            "startRow": this.notesTableCriteria.startRow,
            "endRow": this.notesTableCriteria.endRow,
            "additionalCriteria": this.notesTableCriteria.additionalCriteria,
            "filterCriteria": this.notesTableCriteria.filterCriteria,
            "subFilterCriteria": this.notesTableCriteria.subFilterCriteria,
        };


      
        this.clientDataService.setUrl(this.searchUrl);
        this.clientDataService.postCCCData(searchCriteria).subscribe(res => {
          self.notesRowList = res.data;
          self.notesTableRecordCount = res.recordCount;
          console.log('res', res)
            for (let i = 0; i < res.data.length; i++) {
              this.valueHolder=[];
              for (var name in res.data[i]) { 
                if(res.data[i][name].dbColumnName != 'PROGRAM_NOTES_ID'){
                  if(res.data[i][name].dbColumnName=='NOTE_DATE' && res.data[i][name].value && res.data[i][name].value != ''){
                    console.log("date",res.data[i][name].value)
                    let newDate=(res.data[i][name].value).slice(0,8)
                    let year=newDate.slice(0,4);
                    let mnth= newDate.slice(4,6);
                    let date= newDate.slice(6,8);
                  let  formatedDate=this.datePipe.transform(new Date(year+"/"+mnth+"/"+date),"y MMM d")
                  objToPost=this.datePipe.transform(formatedDate,"d MMM y")
                  }
                  else{
                    objToPost=res.data[i][name].value
                  }
                   this.valueHolder.push(objToPost);
                }
              }
              if(this.valueHolder[0]!=""){
                this.loadedData.push(this.valueHolder)
              }   
          }
        });
    });
     }
     deleteRow(index){
      this.tableData.splice(index,1);
    }
}
