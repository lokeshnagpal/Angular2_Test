import { Component,OnInit, ViewChild, Type, Input, SimpleChanges } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { ClientService } from 'src/app/services/client.service';
import { ClaimHandlingDialog } from '../claims-handling-dialog';

@Component({
  selector: 'app-program-details',
  templateUrl: './program-details.component.html',
  styleUrls: ['./program-details.component.scss']
})
export class ProgramDetailsComponent implements OnInit {
  public cardToTemplateMaping: { [type: string]: Type<ViewChild> } = {};
  public claimHandlingAttributesUrl:any;
  public programDetailsUrl:any;
  public userdetails:any;
  public claimButton:boolean=true;
   public sections:any;
   private programCode :any;
   private dealId:any;
   private sourceSystem:any;
   private businessArea:any;
   private region:any;
   private function:any;
   private insured:any;
   private advancedSearchCriteria:any;
   private programId:any; 
   public attribute: any = [];
   private attr: any;
   private attachemntCheck: any;
   private cardId:any;
   private sectionCode:any; 
   public requestObject:any=[];
   public programFlag=false;
   @Input() prgramDetailsData;
  constructor(private route: ActivatedRoute ,private clientDataService:ClientService) {
      
    this.claimHandlingAttributesUrl=environment.claimHandlingAttributesUrl;
 
    this.route
        .queryParams
        .subscribe(params => {
            this.programId = +params['programId'] || 0;
            this.programCode = params['programCode'];
            this.dealId = params['dealId'];
            this.insured=params['INSURED'];
            this.sourceSystem=params['SOURCE_SYSTEM'];
            this.businessArea=params['BUSINESS_AREA'];
            this.function=params['FUNCTION'];
            this.region=params['REGION'];
        });
  
       
    }

  ngOnInit() { 
  }
  // ngOnChanges(changes: SimpleChanges){
  //   for(let aRow of this.prgramDetailsData){
  //     if(aRow.attributeName=="Program ID"){
  //    this.programFlag=true;
  //     }
  //     else{
  //       this.programFlag=false;
  //     }
  //   }
  // }

}
