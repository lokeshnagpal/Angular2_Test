import { Component,  Input, Output, EventEmitter, OnInit } from '@angular/core';

@Component({
  selector: 'app-file-drag-drop',
  templateUrl: './file-drag-drop.component.html',
  styleUrls: ['./file-drag-drop.component.scss']
})
export class FileDragDropComponent implements OnInit {
  @Input() checkinAlignText;

  @Output() uploadSelectedFiles: EventEmitter<any> = new EventEmitter();

  constructor( ) {
              }

  ngOnInit(){
  }
 //method triggered when file is dropped in the drop zone
  public fileDroppedEvent(event) {
         let filesObj = {
          target:{
              files: event.target.files || event.dataTransfer.files 
          }
      };
      this.uploadSelectedFiles.emit(filesObj);
      this.preventDefaultAndStopPropagation(event);
      }
  // method to clear the previous file selection
      clearSelection(val){
          if(val.files && val.files.length>0){
           val.value = '';
  }
}
// generic method to prevent default functionalities for file drop 
  public preventDefaultAndStopPropagation(event) {
      event.preventDefault();
      event.stopPropagation();
    }

}
