import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {  ClaimsRoutingModule } from './claims-handling-agreement.routing';
 import { CustomBrowserXhr } from './../../custom-browser-xhr';
import { BrowserXhr } from '@angular/http';
import { SharedModule } from './../../shared/shared.module';
import { ClientService } from './../../services/client.service';
import {ClaimHandlingDialog} from './claims-handling-dialog';

import { NotesCommentsComponent } from './notes-comments/notes-comments.component';
import { KeyContactsComponent } from './key-contacts/key-contacts.component';
import { ProgramDetailsComponent } from './program-details/program-details.component';
import { ClientServiceCommitmentsComponent } from './client-service-commitments/client-service-commitments.component';
import { ClaimsHandlingAgreementComponent } from './claims-handling-agreement/claims-handling-agreement.component';
import { FileDragDropComponent } from './file-drag-drop/file-drag-drop.component';
import { UploadDocumentsDialog } from './upload-document-dialog';


// import {FormStepProcessComponent} from './../../lib/modules/dynamic-form/components/form-step-process/form-step-process-component'

@NgModule({
    imports:[
        CommonModule,        
        FormsModule,
        ReactiveFormsModule,  
        SharedModule,
        ClaimsRoutingModule
        

    ],
   declarations:[
    ClaimsHandlingAgreementComponent,ClaimHandlingDialog, NotesCommentsComponent, KeyContactsComponent, ProgramDetailsComponent, ClientServiceCommitmentsComponent, FileDragDropComponent,UploadDocumentsDialog
    //    FormStepProcessComponent
    ],
    providers: [ClientService, { provide: BrowserXhr, useClass: CustomBrowserXhr }],
 entryComponents:[ClaimHandlingDialog, UploadDocumentsDialog]
})
export class ClaimHandlingAgreementModule { 
    
}