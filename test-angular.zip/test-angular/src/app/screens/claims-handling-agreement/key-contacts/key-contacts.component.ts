import { Component, OnInit, Input, SimpleChanges } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { ClientService } from 'src/app/services/client.service';

@Component({
  selector: 'app-key-contacts',
  templateUrl: './key-contacts.component.html',
  styleUrls: ['./key-contacts.component.scss']
})
export class KeyContactsComponent implements OnInit {
@Input() public contactData ;
@Input() public saveSuccess;
@Input() public clearUnsaved;
@Input() prgramDetailData;
@Input() program;
@Input() documentList;
  private searchUrl: any;
  private claimHandlingAttributesUrl:string;
  private preferredPartnersUrl:string;
  private partnerCheck: boolean;
 public partnerColumnList: any;
  private partnerRowList: any = [];
  private partnersTableCriteria: any;
  private partnersTableRecordCount: any;
  public valueHolder:any=[] ;
public tableData:any=[];
public loadedData:any=[];
public documentData:any=[]

public edmsSearchUrl=environment.edmsSearchUrl + '/';
  constructor(private route: ActivatedRoute ,private clientDataService:ClientService) {
    console.log("hi",this.prgramDetailData)
    this.claimHandlingAttributesUrl=environment.claimHandlingAttributesUrl;
   this.preferredPartnersUrl=environment.preferredPartnersUrl;
   this.searchUrl=environment.chaSearchUrl;
  }

  ngOnInit() {
    this.loadPartnerTableData(true);
    this.loadDocument();
  }
  ngOnChanges(changes: SimpleChanges){
   
    console.log("onchng",this.prgramDetailData)
    if (changes.contactData) {
      this.contactData.push(false);
      this.tableData.push(this.contactData);
    }
    if (changes.saveSuccess) {
      this.setDataAsFromService();
    }
    if(changes.clearUnsaved){
      this.clearUnsavedData();
    }
    if(changes.documentList){
      console.log("changes//////////////////////////////////////////////////////////////////////////////////////////////////////////")
     this.documentData = [...this.documentList, ...this.documentData];
      const temp = this.documentData.filter(item => {
        if ((item.documentId || item.docId) && !item.length) {
          return true;
        }
        return false;
      });
      this.documentData = [...temp];
      console.log(temp, 'fddddddddddddddddddddddddddddddddddddddfdddddddddddd');
      console.log(this.documentData,"documentssaved");
    }
  }
  setDataAsFromService() {
    this.tableData.forEach(row => {
      row[6] = true;
    });
  }
  clearUnsavedData(){
  let length=this.tableData.length;
  for(let index=length-1; index>=1;index--){
    this.deleteRow(index);
  }
  }
  loadDocument(){
    //  let urlData='{"ACTIVITY_ID":"IBP4683.3"}';
    // this.programId=this.prgramDetailData[4].programId;
  //  let urlData='{"ACTIVITY_ID":"'+this.prgramDetailData+'"}';
  //  let urlData='{"ACTIVITY_ID":this.prgramDetailData}';
 let urlData='{"ACTIVITY_ID":"'+"PR_"+this.program+'"}';
    console.log(urlData)
    this.clientDataService.setUrl(this.edmsSearchUrl+urlData); 
    this.clientDataService.getClientsData().subscribe(response => {
    console.log("check",response);
    this.documentData.push(...response);
    for (let i=0;i<this.documentData.length;i++){
      console.log(this.documentData[i].documentName, i)
    }
    })
  }
  openDocument(docId){
    window.top.open(environment.streamingServlet + '?docId=' + docId + '&appName=NATIVE&openInline=Y')
  }
  public loadPartnerTableData(initialLoad: boolean) {
    let self = this;
    let objToPost: any;
    this.clientDataService.setUrl(this.preferredPartnersUrl);
    this.clientDataService.getClientData().subscribe(res => {
        this.partnerCheck = true;
        if (initialLoad) {
            self.partnerColumnList = res.tableHeader;
            this.partnersTableCriteria = {
                "sectionId": res.sectionDetails.sectionId,
                "sortDirection": res.defaultSortingParam,
                "sortColumnId": res.defaultSortingColumnId,
                "startRow": "1",
                "endRow": res.defaultRowsPerPage,
                "additionalCriteria": { "PROGRAM": this.program},
                "filterCriteria": {},
            };
        }

        let searchCriteria = {
            "sectionId": this.partnersTableCriteria.sectionId,
            "sortDirection": this.partnersTableCriteria.sortDirection,
            "sortColumnId": this.partnersTableCriteria.sortColumnId,
            "startRow": this.partnersTableCriteria.startRow,
            "endRow": this.partnersTableCriteria.endRow,
            "additionalCriteria": this.partnersTableCriteria.additionalCriteria,
            "filterCriteria": this.partnersTableCriteria.filterCriteria,
            "subFilterCriteria": this.partnersTableCriteria.subFilterCriteria,
        };

        this.clientDataService.setUrl(this.searchUrl);
        this.clientDataService.postCCCData(searchCriteria).subscribe(res => {
            self.partnerRowList = res.data;
            self.partnersTableRecordCount = res.recordCount;
            for (let i = 0; i < res.data.length; i++) {
              this.valueHolder=[];
              for (var name in res.data[i]) { 
                if(res.data[i][name].dbColumnName != 'PROGRAM_PARTNERS_ID'){
                  
                  objToPost=res.data[i][name].value
                   this.valueHolder.push(objToPost);
                }
              }
              if(this.valueHolder[0]!=""|| this.valueHolder[1]!=""|| this.valueHolder[2]!=""|| this.valueHolder[3]!=""|| this.valueHolder[4]!=""|| this.valueHolder[5]!="" )
              this.loadedData.push(this.valueHolder)
          }
        });
    });
  
}
deleteRow(index){
  this.tableData.splice(index,1);
}
}
