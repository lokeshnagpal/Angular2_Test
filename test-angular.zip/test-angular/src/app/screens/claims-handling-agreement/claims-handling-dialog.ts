import { Component, OnInit,Inject, ViewChild } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef, MatDialog,MatSnackBar ,MatTable} from '@angular/material';
import { FormControl, FormGroup, FormBuilder, Validators ,ValidatorFn} from '@angular/forms';
import { ClientService } from 'src/app/services/client.service';
import { environment } from 'src/environments/environment';
import { CommonTransformerService } from 'src/app/util/common-transformer.service';

@Component({
    selector: 'claim-handling-dialog',
    templateUrl: 'claims-handling-dialog.html',
   styleUrls: ['./claims-handling-dialog.scss']
})
export class ClaimHandlingDialog {
public emailAddress:any;
public subject:any;
public mailContent:any;
public diaryDialogForm: FormGroup;
public dialogAttributes: any=[];
public claimDialogAttributes: any=[];
public sections: any = [];
public formDatas:any;
public dialogHeading:any="";
public savePreferredPartners:any;
public saveNotes:any;
public claimHandlingAttributesUrl:any;
public saveCommunications:any;
public attributeHolder:any ;
private attribute: any = [];
public program:any;
context: any = {
    businessArea: 'CHA',
    status: 'Dialog'
  };
  // @ViewChild(MatTable,{static:true}) table: MatTable<any>;
    constructor(
        public dialogRef: MatDialogRef<ClaimHandlingDialog>,
        @Inject(MAT_DIALOG_DATA) public data: any,public fb: FormBuilder,public clientService: ClientService,public commonTransformerService: CommonTransformerService
   
    ) {
      this.savePreferredPartners = environment.savePreferredPartnersUrl;
      this.saveNotes = environment.saveNotesUrl;
      this.claimHandlingAttributesUrl=environment.claimHandlingAttributesUrl;
      this.saveCommunications = environment.saveCommunicationUrl;
      this.program= (this.data.program).toString();
    }
    ngOnInit() {
    
       let newIndex=0;
        // this.clientService.setUrl(environment.communicationUrl);
        // this.clientService.getClientData().subscribe(response => {
        //   this.sections = response.tableHeader;
        //   console.log("dialog",this.sections)
        // });
        this.dialogAttributes = this.data.attributes;
        this.dialogHeading=this.data.header;
     for(let index=0; index<this.dialogAttributes.length; index++)
     {
      if(this.dialogAttributes[index].type !="PRIMARYKEY" && this.dialogAttributes[index].type !="DATECOLUMN" )
      {
        this.claimDialogAttributes[newIndex]=this.dialogAttributes[index];
        newIndex++; 
      }
        
        
     }
     for (let i = 0; i < this.dialogAttributes.length; i++) {
      let myAttr:any = {
          attrId:  this.dialogAttributes[i].attrId,
          attributeName:  this.dialogAttributes[i].name,
          attributeType:  this.dialogAttributes[i].type,
          value:  this.dialogAttributes[i].value,
          isValueHref: this.dialogAttributes[i].isValueHref,
          dbColumnName:this.dialogAttributes[i].dbColumnName          
      }
      this.attribute.push(myAttr); 
    }  
    }
    addData(){
     
    let objToPost: any;
    // this.attributeHolder = [];
    let commitmentHolder:any;
    if(this.dialogHeading=="Add a Client Service Commitment"){
      this.attributeHolder=this.formDatas;
    }
    else{
      this.attributeHolder = [];
      for (let i = 0; i < this.attribute.length; i++) {
        for (let key in this.formDatas) {
         
         if (this.attribute[i].dbColumnName ==(key)) {   
      objToPost=this.formDatas[key]
    this.attributeHolder.push(objToPost);
  }
  }
  }
    }

  if(this.formDatas!=undefined && this.dialogHeading!=undefined){
  this.dialogRef.close({event:'close', data:this.attributeHolder, header:this.dialogHeading});
  }
    }


    showMessage(message: string, durationValue: number) {
      this.commonTransformerService.showMessage(message, durationValue);
  }



}
   

