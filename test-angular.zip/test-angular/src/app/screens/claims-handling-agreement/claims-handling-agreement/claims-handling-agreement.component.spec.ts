import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClaimsHandlingAgreementComponent } from './claims-handling-agreement.component';

describe('ClaimsHandlingAgreementComponent', () => {
  let component: ClaimsHandlingAgreementComponent;
  let fixture: ComponentFixture<ClaimsHandlingAgreementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClaimsHandlingAgreementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClaimsHandlingAgreementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
