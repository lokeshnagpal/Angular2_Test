import { Component,OnInit, ViewChild, Type, SimpleChanges } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DatePipe } from '@angular/common';

// import { AppState, InternalStateType } from '../app.service';
import { MatMenuTrigger } from '@angular/material/menu';
import { MatDialog, MatSnackBar, MatDialogClose } from '@angular/material';
;
import { environment } from 'src/environments/environment';
import { ClientService } from 'src/app/services/client.service';
import { ClaimHandlingDialog } from '../claims-handling-dialog';
import { analyzeAndValidateNgModules } from '@angular/compiler';
import { CommonTransformerService } from 'src/app/util/common-transformer.service';
import { UploadDocumentsDialog } from '../upload-document-dialog';
import { ApplicationStateService } from 'src/app/util/application.state.service';
@Component({
  selector: 'app-claims-handling-agreement',
  templateUrl: './claims-handling-agreement.component.html',
  styleUrls: ['./claims-handling-agreement.component.scss']
})
export class ClaimsHandlingAgreementComponent implements OnInit {

  public cardToTemplateMaping: { [type: string]: Type<ViewChild> } = {};
   public claimHandlingAttributesUrl:any;
   public communicationUrl:any;
   public saveUrl:any;
   public preferredPartnersUrl:any;
   public userdetails:any;
   public noteCheckUrl:any;
   public programCode:any;
   public program:any;
   public dealId:any;
   public sourceSystem:any;
   public businessArea:any;
   public region:any;
   public function:any;
   public insured:any;
   public advancedSearchCriteria:any;
   public programId:any; 
   public attribute: any = [];
   public attr: any;
   public claimButton:boolean=true;
   public sections:any;
   public dialogAttributes: any;
   public dialogHeader:any="";
   public clientValue:any=[]
   public notesValue:any=[]
   public contactValue:any=[];
   public clientList:any=[]
   public notesList:any=[]
   public contactList:any=[];
   public programDetailsData:any;
   public clientServiceCommitmentsList:any=[];
   public claimAgreementCommentsList:any=[];
   public  keyContactsList:any=[];
   public saveSuccess: number = 0;
   public clearUnsaved:number=0;
   public noteEventData:any;
   public edmsSearchUrl=environment.edmsSearchUrl + '/';
   public activityId:any;
   public programNo:any;
   public documentList:any=[];
   @ViewChild(MatMenuTrigger, {static: false}) trigger: MatMenuTrigger;
   public icon:string="add";
   public isIE;
   
    constructor(private route: ActivatedRoute ,private clientDataService:ClientService,public dialog: MatDialog, 
      public commonTransformerService: CommonTransformerService,private datePipe: DatePipe, public applicationStateService: ApplicationStateService) {
        this.isIE = this.applicationStateService.isBrowserIE();
        this.claimHandlingAttributesUrl=environment.claimHandlingAttributesUrl;
        this.communicationUrl=environment.communicationUrl;
        this.preferredPartnersUrl=environment.preferredPartnersUrl;
        this.noteCheckUrl=environment.noteCheckUrl;
        this.saveUrl=environment.saveUrl;
       
        this.route
        .queryParams
        .subscribe(params => {
            this.program = +params['program'] || 0;
            this.programId= params['programId'];
            this.dealId = params['dealId'];
            this.insured=params['INSURED'];
            this.sourceSystem=params['SOURCE_SYSTEM'];
            this.businessArea=params['BUSINESS_AREA'];
            this.function=params['FUNCTION'];
            this.region=params['REGION'];
        });
     
        
       
    }
    ngOnInit(){
      this.loadProgramDetails(true);
        this.trigger.menuOpened.subscribe(() => this.icon = 'close');
        this.trigger.menuClosed.subscribe(() => this.icon = 'add');
        
       this.dialogHeader=" ";
    }
    // ngOnChanges(changes: SimpleChanges){
    //     if (changes.contactData) {
    //       this.contactList.push(this.contactValue);  
    //     }
       
    //   }
     openMenu(){
    this.trigger.menuOpened.subscribe(() => this.icon = 'close');
    this.trigger.menuClosed.subscribe(() => this.icon = 'add');
     
    }
    openCommitment(){
        this.clientDataService.setUrl(this.communicationUrl);
        this.dialogHeader="Add a Client Service Commitment";
        this.openDialogbox();
    }

    openNotes(){
        this.clientDataService.setUrl(this.noteCheckUrl);
        this.dialogHeader="Notes / Comments";
        this.openDialogbox();
    }

    openContact(){
        this.clientDataService.setUrl(this.preferredPartnersUrl);
        this.dialogHeader="Add Contact";
        this.openDialogbox();
    }
    openDocument(){
      this.dialogAttributes=this.attr;
      this.dialogHeader="Add Documents";
      let dialogRef = this.dialog.open(UploadDocumentsDialog, {
        width: '40%',      
        panelClass: 'my-panel',
        data: {
            attributes: this.dialogAttributes, header:this.dialogHeader, program: this.program,programId:this.programId,dealId:this.dealId, insured:this.insured,
        }
});
dialogRef.afterClosed().subscribe(result => {
  if (result!=undefined){
    console.log("header",result)
    for(let item of result.data){
      this.documentList = [...this.documentList,item];
    }
    console.log("item",this.documentList)
  }
});
    }
    openDialogbox(){
        this.clientDataService.getClientData().subscribe(response => {
            this.dialogAttributes = response.tableHeader;
        let dialogRef = this.dialog.open(ClaimHandlingDialog, {
            width: '40%',
            // data: { res:res,program:this.program},                
            panelClass: 'my-panel',
            data: {
                attributes: this.dialogAttributes, header:this.dialogHeader, program: this.program,programId:this.programId,dealId:this.dealId, insured:this.insured,
            }
    });
    
    
    dialogRef.afterClosed().subscribe(result => {
      if (result!=undefined){
        console.log("header",result)
        if(result.header=="Add a Client Service Commitment")
        {
            this.clientValue = result.data;
            // this.notesValue=[]
            // this.contactValue=[]
            this.clientList.push(this.clientValue)
        }
        else if(result.header=="Notes / Comments")
        {
            // this.clientValue =[]
            this.notesValue= result.data;
          //  this.notesList.push(this.notesValue)
            // this.contactValue=[]
        }
        else if(result.header=="Add Contact")
        {
            // this.clientValue =[]
            // this.notesValue=[]
            this.contactValue=result.data;
            this.contactList.push(this.contactValue); 
        }
     
      }
      });
  
    })
   
    }

    public loadProgramDetails(initialLoad: boolean) {
      this.attribute = [];
      this.clientDataService.setUrl(this.claimHandlingAttributesUrl);
      
  console.log(this.dealId,"dealid")
    let requestObject = {
                program:this.program,
                programId:this.programId,
                dealId:this.dealId,
                insured:this.insured,
                sourceSystem:this.sourceSystem,
                function:this.function,
                businessArea:this.businessArea,
                region:this.region,
                sectionCode:"PROGRAM_DETAILS",
      }
    // this.clientDataService.setUrl('https://corflowclm-train2.swissreapps-np.com/ccc/claimHandlingAgreement/getAttributes');
      this.clientDataService.postCCCData(requestObject).subscribe(response => {
          console.log('programDetail', response);
          let programDialogData=response.attributeList;
          this.program=response.program;
          this.businessArea=response.businessArea;
          this.sourceSystem=response.sourceSystem;
          this.function=response.function;
          this.region=response.region;
           this.clientDataService.setProgramObservable(this.program);
          for (let i = 0; i < programDialogData.length; i++) {
              let myAttr:any = {
                  attrId: programDialogData[i].attrId,
                  attributeName: programDialogData[i].attributeName,
                  attributeType: programDialogData[i].attributeType,
                  value: programDialogData[i].value,
                  isValueHref:programDialogData[i].isValueHref,
                  
              }
              if(myAttr.isValueHref && programDialogData[i].attributeOptions.length>0 ){
                  myAttr.attributeOptions=programDialogData[i].attributeOptions[0].name
              }
              this.attribute.push(myAttr);               
          }
          this.attribute.push({programId:this.programId})
          this.attribute.push({businessArea:this.businessArea})
          this.attribute.push({sourceSystem:this.sourceSystem})
          this.attribute.push({function:this.function})
          this.attribute.push({region:this.region})
          this.attribute.push({program:this.program})
          
          this.attr = this.attribute;
          this.activityId=this.attr[4].programId;
          this.programNo=this.attr[9].program;
              })
    
    }

    // openAttachment(){ 
    //   this.advancedSearchCriteria = {
                    
    //     "ACTIVITY_ID": this.programCode
    // }
    // let urlData:string=JSON.stringify(this.advancedSearchCriteria);
    // console.log(urlData,"1")
    // // this.programCode = '147858';
    // urlData='{"ACTIVITY_ID":"147845"}';
    // // urlData='{"ACTIVITY_ID":"'+this.programCode+'"}';
    // console.log(this.edmsSearchUrl+urlData);
    //     this.clientDataService.setUrl(this.edmsSearchUrl+urlData); 
    //           this.clientDataService.getClientsData().subscribe(response => {
    //       console.log("check",response)
    // //         this.dialogAttributes = response.tableHeader;
    // //     let dialogRef = this.dialog.open(ClaimHandlingDialog, {
    // //         width: '40%',
    // //         // data: { res:res,program:this.program},                
    // //         panelClass: 'my-panel',
    // //         data: {
    // //             attributes: this.dialogAttributes
    // //         }
    // //  });
    // // dialogRef.afterClosed().subscribe(result => {
    // // });
    // })
    // }
  
    
  saveData(){

      this.programDetailsData={
          "programId":this.attr[9].program,
        "programCode":this.attr[0].value,
        "programName": this.attr[1].value,
        "masterInsurer":this.attr[2].value,
        "dealID":this.attr[3].value
      }

      
    if(this.contactList.length>0)   {  
    for(let value of this.contactList )
    {
        let objToPost={
            "partnersId":"",
            "name": value[0],
             "companyPosition": value[1],
             "telephone": value[2],
            "mobile":value[3],
             "emailAddress": value[4],
             "roleOfContact": value[5]
        }
        this.keyContactsList.push(objToPost);
    }
  }
  else{
    let objToPost={
      "partnersId":"",
      "name":"",
       "companyPosition":"",
       "telephone": "",
      "mobile":"",
       "emailAddress": "",
       "roleOfContact":""
  }
  this.keyContactsList.push(objToPost);
  }
    this.contactList=[];

 
    for(let events of this.noteEventData){
      let commentValue=[];
      commentValue.push(events.note);
      commentValue.push(this.datePipe.transform(events.date,"yyyyMMdd"),)
      this.notesList.push(commentValue);
    }
   if(this.notesList.length>0){
    for(let value of this.notesList )
    {
      // console.log("daaatteeto save",this.datePipe.transform(value[1],"mm/dd/yyyy"))
      let objToPost
      if(value[0][0]!=undefined){
       objToPost={
            "noteId":"",
      "note": value[0][0],
      "date":value[1]
        }
        this.claimAgreementCommentsList.push(objToPost);
      }
       
    }
  }
  else{
    let objToPost={
      "noteId":"",
"note":"",
"date":""
  }
  this.claimAgreementCommentsList.push(objToPost);
  }
    this.notesList=[];

    if(this.clientList.length>0){
    for(let value of this.clientList )
    {
        let cadenceValue:any;
        let activityValue:any;
        let commentValue:any;
        for(let key in value){
            if(key=="CADANCE_VALUE")
           {
              cadenceValue=value[key];
           }
           else  if(key=="ACTIVITY_VALUE")
           {
              activityValue=value[key];
           }
           else  if(key=="COMMENTS_VALUE")
           {
              commentValue=value[key];
           }
        }
      
      
        let objToPost={
            "communicationId":"",
        "cadence": cadenceValue,
      "activity": activityValue,
      "comment": commentValue
        }
        this.clientServiceCommitmentsList.push(objToPost);
    }
  }
  else{
    let objToPost={
      "communicationId":"",
  "cadence": "",
"activity": "",
"comment": ""
  }
  this.clientServiceCommitmentsList.push(objToPost);
  }
    this.clientList=[];
        let programAttributeModel = {
          "programDetails": this.programDetailsData,
          "clientServiceCommitments": this.clientServiceCommitmentsList,
          "claimAgreementComments": this.claimAgreementCommentsList,
          "keyContacts":this.keyContactsList
        }

          this.clientDataService.setUrl(this.saveUrl);
          this.clientDataService.postClaimsData((programAttributeModel)).subscribe(programDialogDatas => {
              this.commonTransformerService.showMessage("Saved Successfully", 3000);
              this.saveSuccess++;
          });
         
        }
        
        public saveandclose(){
         
         this.saveData();
          // window.open('','_self');
          // window.close();
      }

     public  clearAndclose(){
       this.clearUnsaved++;
       this.commonTransformerService.showMessage("Cancel", 3000);
      //  window.opener=self;
      //  window.close();
     }
          
}



