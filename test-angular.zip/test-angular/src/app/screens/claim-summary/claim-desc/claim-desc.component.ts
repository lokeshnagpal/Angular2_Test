import { RichTextComponent } from './../../../shared/ui/rich-text/rich-text.component';
import { LLRService } from './../../llr/llr.service';
import { Constants } from './../../../util/application.constants';
import { ApplicationStateService } from './../../../util/application.state.service';
import { Component, OnInit, Input, ViewChild, ElementRef } from '@angular/core';
import { BaseComponent } from './../../../shared/ui/base/base.component';
import { Subscription } from 'rxjs';
import { ClaimSummaryService } from './../claim-summary.service';
import { MatSnackBar, MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { EditorComponent } from './../../../shared/ui/editor/editor.component';
import { environment } from './../../../../environments/environment';
import { CommonTransformerService } from 'src/app/util/common-transformer.service';


@Component({
  selector: 'app-claim-desc',
  templateUrl: './claim-desc.component.html',
  styleUrls: ['./claim-desc.component.scss']
})
export class ClaimDescComponent implements OnInit {


  @Input('isDisabled') isDisabled: boolean;
  @Input('isExpand') isExpand: boolean;
  public claimDescLabel = "Claim Description";
  public subscription: Subscription;
  public claimDescriptionData: any = "";
  public url:string;
  @ViewChild('parentContent', {static: false})
  parentContent: ElementRef;

  @ViewChild('childContent', {static: false})
  childContent: ElementRef;

  constructor(public baseComponent: BaseComponent, public commonTransformerService: CommonTransformerService,
    public claimSummary:ClaimSummaryService, public applicationStateService: ApplicationStateService) {
    this.url = environment.saveClaimSummaryUrl;
  }

  ngOnInit() {
    this.subscribeToData();
  }

  ngAfterViewInit(){
    this.subscription=this.baseComponent.getRichTextData.subscribe(res =>{ 
      if (Object.keys(res).length > 0) {
           this.claimSummary.updateClaimSummary(this.url, res.result, 'CLAIM-DESC').subscribe(response => {

           });
        }
    })
  }
  subscribeToData() {

    this.subscription = this.baseComponent._getClaimSummary().subscribe(res => {
      if (res.claimDescription != null) {
        this.claimDescriptionData = res.claimDescription;
      }
    });

  }
  public showMessage(message: string, durationValue: number) {
    this.commonTransformerService.showMessage(message, durationValue);
  }
  ngOnDestroy() {
    if (this.subscription !== undefined) {
      this.subscription.unsubscribe();
    }
  }
  toggleView($event) {
    if (this.parentContent.nativeElement.offsetHeight >195) {
      this.parentContent.nativeElement.style.height = '195px';
      this.childContent.nativeElement.innerHTML =  'VIEW MORE';
      console.log(this.parentContent.nativeElement, this.childContent.nativeElement)
      } else {
        this.parentContent.nativeElement.style.height = 'auto';
        this.childContent.nativeElement.innerHTML = 'VIEW LESS';
        console.log(this.parentContent.nativeElement, this.childContent.nativeElement)
        
      }
       
    }
  //open editor to update claim desc data
  // editEditor(){
  //   this.editFlag=true;
  //   let dialogRef;
  //   dialogRef = this.dialog.open(EditorComponent, {
  //     width: '750px',height:'auto',
  //     panelClass: 'claim-desc-editor-panel',
  //     data: {
  //       editorValue:this.claimDescriptionData,        
  //       editorTemplate:{
  //         editorLabel:this.claimDescLabel,
  //         cancel:Constants.CANCEL,
  //         save:Constants.SAVE_DRAFT
  //       }
  //     }
  //   })
  //   dialogRef.afterClosed().subscribe(result => {
  //     this.editFlag=false;
  //     this.claimDescriptionData=result;
  //     if(this.section!=undefined){
  //         let taskObj = {
  //           attrId: this.section.attributes[0].attrId,
  //           dbColumnName: this.section.attributes[0].dbColumnName,
  //           type: this.section.attributes[0].type,
  //           value: result
  //         }

  //       this.attributeHolder.push(taskObj)
  //       let  sectionAttrHolderObject = {
  //           "sectionName": this.section.sectionName,
  //           "attributeMap":  this.attributeHolder
  //         }        
  //         this.llrService.setTaskDetailsData(sectionAttrHolderObject);
  //     }

  //     this.service.updateClaimSummary(this.url,result,'CLAIM-DESC').subscribe(response=>{

  //     });
  //   });
  // }
}
