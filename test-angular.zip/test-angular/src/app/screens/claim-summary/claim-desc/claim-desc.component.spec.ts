import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClaimDescComponent } from './claim-desc.component';

describe('ClaimDescComponent', () => {
  let component: ClaimDescComponent;
  let fixture: ComponentFixture<ClaimDescComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClaimDescComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClaimDescComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
