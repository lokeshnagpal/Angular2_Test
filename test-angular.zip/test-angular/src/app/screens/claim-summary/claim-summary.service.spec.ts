import { TestBed } from '@angular/core/testing';

import { ClaimSummaryService } from './claim-summary.service';

describe('ClaimSummaryService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ClaimSummaryService = TestBed.get(ClaimSummaryService);
    expect(service).toBeTruthy();
  });
});
