import { CommonTransformerService } from 'src/app/util/common-transformer.service';
import { Constants } from './../../../util/application.constants';
import { Component, OnInit, Input, ViewChild, ElementRef } from '@angular/core';
import { BaseComponent } from './../../../shared/ui/base/base.component';
import { Subscription } from 'rxjs';
import { ClaimSummaryService } from './../claim-summary.service';
import { MatSnackBar } from '@angular/material';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { ClientService } from 'src/app/services/client.service';
import { ApplicationStateService } from 'src/app/util/application.state.service';

@Component({
  selector: 'app-policy-info',
  templateUrl: './policy-info.component.html',
  styleUrls: ['./policy-info.component.scss']
})
export class PolicyInfoComponent  implements OnInit {
  public policyList: any;
  public policyHeaderData: any;
  public policyBodyData:any=[];
  public subscription: Subscription;
  public policyProperties: any = [];
  public policyInformationData: any;
  public firstValue:any
  public constant = Constants;
  public policyNumber;
  public policyDocuments;
  public isIE: boolean = false;
  public showTooltip: boolean = false;
  public currency: string = 'USD';

  @Input("policyInformation") policyInformation: any;
  @Input('isDisabled') isDisabled: boolean;
  @Input('isExpand') isExpand: boolean;
  @Input() claimNumber?: any;
  @ViewChild('docsTooltip', {static: false}) docsTooltip: ElementRef;

  constructor(public service: ClaimSummaryService,public baseComponent:BaseComponent,private snackBar: MatSnackBar,
    protected commonTransformerService: CommonTransformerService, public router: Router, public clientService: ClientService,
    private applicationStateService: ApplicationStateService) {
      this.isIE = this.applicationStateService.isBrowserIE();
  }

  ngOnInit() {
    this.subscribeToData();
    if (this.claimNumber) {
      this.clientService.setUrl(environment.policyDocumentsUrl + 'claim/' + this.claimNumber);
      this.clientService.getClientData().subscribe(response => {
        this.policyDocuments = response.policyDocData;
      });
    }
  }

  subscribeToData() {    
    this.subscription= this.baseComponent._getClaimSummary().subscribe(res => {
      this.policyNumber = res.policyInformation.policyId;
      this.currency = res.financials.summary.currency ? res.financials.summary.currency : 'USD';
      this.currency += ' ';
      let policyDate:any={
        'policyDate':{

        }
      }
      // const temp = {
      //   policyId: '131.429',
      //   insured: 'skymark',
      //   broker: 'JTL',
      //   country: 'Japan',
      //   premium: 682000,
      //   // status: 'BINDER',
      //   openClaims: '5',
      //   navigationUrl: 'https://www.google.com',
      //   inceptionDate: '20190901',
      //   expirationDate: '20190901' 
      //   };
      // res.policyInformation = temp;
      let obj:any=res.policyInformation;
      this.policyHeaderData=res.policyInformation;
      this.policyBodyData=this.commonTransformerService.convertIntoKeyValue(res.policyInformation);

      policyDate.policyDate.policyInceptionLabel=Constants.INCEPTIONDATE;
      policyDate.policyDate.policyInceptionValue=this.commonTransformerService.dateMHFormatChange(obj.inceptionDate)
      policyDate.policyDate.policyExpirationLabel=Constants.EXPIRATIONDATE;
      policyDate.policyDate.policyExpirationValue=this.commonTransformerService.dateMHFormatChange(obj.expirationDate);

      let policyInformationData:any=[];
     policyInformationData=Object.assign([], this.policyBodyData);
  
    policyInformationData.forEach((element,i) => {
      let index=this.policyBodyData.findIndex(x=>x.name===Constants.INCEPTIONDATE || x.name===Constants.EXPIRATIONDATE || x.name===undefined);
      if(index>-1){
        this.policyBodyData.splice(index,1);
      }
    });   

    this.policyBodyData.push(policyDate);
    // let index=this.policyBodyData.findIndex(x=>x.name===undefined); 
    // if(index>-1){
    //   this.policyBodyData.splice(index,1);
    // }
      // this.policyInformationData = this.service.policyData(res.policyInformation); 
      // if(this.policyInformationData.headerAttributes[0].value!=undefined){
      //   let splitValue:any=this.policyInformationData.headerAttributes[0].value.split(" ");
      //   this.firstValue=splitValue[0].substring(0,1) + splitValue[1].substring(0,1)
      // }   
     });  
  }

  openClaims() {
    if (this.policyHeaderData.navigationUrl) {
      window.open(this.policyHeaderData.navigationUrl);
    }
  }
  launchDocument(docId) {
    window.open(environment.streamingServlet + '?docId=' + docId + '&appName=NATIVE&openInline=Y ')
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  openPolicyDocuments() {
    this.router.navigate(['claimSummary/policy'], { queryParams: { claimNumber: this.claimNumber, policyNumber: this.policyNumber } });
  }
  toggleTooltip(event) {
    this.showTooltip = !this.showTooltip;
    this.docsTooltip.nativeElement.style.top = (event.pageY + 30) + 'px';
  }
}
