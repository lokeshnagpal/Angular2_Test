import { CustomBrowserXhr } from './../../custom-browser-xhr';
import { SharedModule } from './../../shared/shared.module';
import { NgModule } from '@angular/core';
import { ClaimSummaryRoutingModule } from './claim-summary-routing.module';
import { ClaimSummaryComponent } from './claim-summary/claim-summary.component';

import { CoInsuranceComponent } from './co-insurance/co-insurance.component';
import { PolicyInfoComponent } from './policy-info/policy-info.component';
import { FinancialSummaryComponent } from './financial-summary/financial-summary.component';

import {SliderDialogComponent} from './../../shared/ui/sliderDialog/sliderDialog.component';
import { PolicyDocumentsComponent } from './policy-documents/policy-documents.component';
import { FinancialGraphComponent } from './financial-graph/financial-graph.component';

@NgModule({
  declarations: [
    ClaimSummaryComponent,  
     CoInsuranceComponent, 
     PolicyInfoComponent,     
     FinancialSummaryComponent,
     SliderDialogComponent,
     PolicyDocumentsComponent,
     FinancialGraphComponent,  
    ],
  imports: [
    ClaimSummaryRoutingModule,SharedModule,   
  ],
  
  entryComponents:[SliderDialogComponent]
})
export class ClaimSummaryModule { }
