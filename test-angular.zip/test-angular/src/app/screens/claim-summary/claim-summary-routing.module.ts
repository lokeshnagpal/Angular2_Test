import { ClaimSummaryComponent } from './claim-summary/claim-summary.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PolicyDocumentsComponent } from './policy-documents/policy-documents.component';

const routes: Routes = [
  { path: '', component: ClaimSummaryComponent, children: [] },
  { path: 'policy', component: PolicyDocumentsComponent },
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ClaimSummaryRoutingModule { }
