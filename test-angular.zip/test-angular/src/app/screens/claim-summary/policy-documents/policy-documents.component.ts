import { Component, OnInit, Input } from '@angular/core';
import { MatDialog} from '@angular/material';
import { ClientService } from 'src/app/services/client.service';
import { CommonTransformerService } from 'src/app/util/common-transformer.service';
import { environment } from 'src/environments/environment';
import { LinkPolicyDocumentsDialog } from 'src/app/shared/ui/link-policy-documents/link-policy-documents.component';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-policy-documents',
  templateUrl: './policy-documents.component.html',
  styleUrls: ['./policy-documents.component.scss']
})
export class PolicyDocumentsComponent implements OnInit {

  public claimNumber: string;
  public policyNumber: string;
  public documentSrc: string = null;
  public linkedDocuments: any[];
  public dataSource: any;
  public showProgressBar: boolean = false;
  public displayedColumns: string[] = ['docName', 'docType', 'updatedDate', 'more'];

  constructor(public clientService: ClientService, public commonTransformerService: CommonTransformerService,
    public dialog: MatDialog,  protected route: ActivatedRoute, public router: Router) {
      this.route
      .queryParams
      .subscribe(params => {
        this.claimNumber = params['claimNumber'];
        this.policyNumber = params['policyNumber'];
      });
    }

  ngOnInit() {
    this.fetchData();
  }

  fetchData() {
    if (this.claimNumber) {
      this.showProgressBar = true;
      this.clientService.setUrl(environment.policyDocumentsUrl + 'claim/' + this.claimNumber);
      this.clientService.getClientData().subscribe(response => {
        this.linkedDocuments = response.policyDocData;
        this.dataSource = this.linkedDocuments;
        this.showProgressBar = false;
      });
    }
  }

  dateFormatChange(date) {
    return this.commonTransformerService.dateObjectFormatChange(date);
  }

  linkDocuments() {
    if (this.policyNumber) {
      const data = {
        'linkedDocuments': this.linkedDocuments,
        'documentUrl': environment.documentUrl + 'POLICYNUMBER/' + this.policyNumber,
        'claimNumber': this.claimNumber,
        'policyNumber': this.policyNumber
      };
      const dialogRef = this.dialog.open(LinkPolicyDocumentsDialog, {
        width: '70%',
        maxWidth: '1110px',
        height: '90%',
        maxHeight: '720px',
        data,
        autoFocus: false
      });
      dialogRef.afterClosed().subscribe(linked => {
        if (linked) {
          this.commonTransformerService.showMessage('All changes saved.');
          this.fetchData();
        }
      });
    }
  }

  linkDocument(document) {
    const type = document.docType == 'P' ? 'E' : 'P';
    const attr = {
      'policyDocDatas': []
    };
    const data = {
      'claimNumber': this.claimNumber,
      'policyNumber': this.policyNumber,
      'docId': document.docId,
      'docType':  type,
      'docName': document.docName,
      'id': document.id,
      'action': 'LINK'
    };
    attr.policyDocDatas.push(data);
    this.clientService.setUrl(environment.policyDocumentsUrl);
    this.clientService.linkDocuments(attr).subscribe(response => {
      document.docType = type;
      this.commonTransformerService.showMessage(document.docName + ' has been linked as ' + (type == 'P' ? 'policy document' : 'endorsement') + '.');
    });
  }
  
  delinkDocument(document) {
    const attr = {
      'policyDocDatas': []
    };
    const data = {
      'claimNumber': this.claimNumber,
      'policyNumber': this.policyNumber,
      'docId': document.docId,
      'docType':  document.docType,
      'docName': document.docName,
      'id': document.id,
      'action': 'DELINK'
    };
    attr.policyDocDatas.push(data);
    this.clientService.setUrl(environment.policyDocumentsUrl);
    this.clientService.linkDocuments(attr).subscribe(response => {
      this.commonTransformerService.showMessage(document.docName + ' has been delinked.');
      this.linkedDocuments = this.linkedDocuments.filter(doc => doc.id != document.id);
      this.dataSource = this.linkedDocuments;
    });
  }

  loadDocument(element) {
    this.documentSrc = environment.streamingServlet + '?docId=' + element.doc_id + '&appName=NATIVE&openInline=Y ';
  }

  launchDocument() {
    window.open(this.documentSrc);
  }
}
