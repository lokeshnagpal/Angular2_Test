import { Component, OnInit, Input } from '@angular/core';
import { BaseComponent } from './../../../shared/ui/base/base.component';
import { Subscription } from 'rxjs';
import { ClaimSummaryService } from './../claim-summary.service';
import { MatSnackBar } from '@angular/material';
@Component({
  selector: 'app-financial-summary',
  templateUrl: './financial-summary.component.html',
  styleUrls: ['./financial-summary.component.scss']
})
export class FinancialSummaryComponent implements OnInit {

  public subscription: Subscription;
  public financeData: any;
  @Input('isDisabled') isDisabled: boolean;
  @Input('isExpand') isExpand: boolean;
  public obj: any;
  constructor(public service: ClaimSummaryService,private baseComponent:BaseComponent,private snackBar: MatSnackBar) {
   
  }

  ngOnInit() {
    this.subscribeToData();
  }


  subscribeToData(){
    this.subscription= this.baseComponent.getClaimSummaryDetail.subscribe(res => {  
    if(Object.keys(res.financials).length != 0){ 
      if (res.financials.summary.background == undefined) {
        res.financials.summary.background = ['#58b8a4', '#21efb4', '#aaaaaa', '#999999', '#666666'];
      }
      this.financeData = res.financials;  
      this.financeData.summary.name = "Finance_Info"
     }
    });
    }


    ngOnDestroy(){
      this.subscription.unsubscribe();
    }
}
