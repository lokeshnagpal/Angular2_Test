import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FinancialGraphComponent } from './financial-graph.component';

describe('FinancialGraphComponent', () => {
  let component: FinancialGraphComponent;
  let fixture: ComponentFixture<FinancialGraphComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FinancialGraphComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FinancialGraphComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
