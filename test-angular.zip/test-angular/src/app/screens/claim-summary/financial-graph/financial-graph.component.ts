import { Component, OnInit, Input, ViewChild, ElementRef } from '@angular/core';
import { ApplicationStateService } from 'src/app/util/application.state.service';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { CommonTransformerService } from 'src/app/util/common-transformer.service';

@Component({
  selector: 'app-financial-graph',
  templateUrl: './financial-graph.component.html',
  styleUrls: ['./financial-graph.component.scss']
})
export class FinancialGraphComponent implements OnInit {

  @Input() financeData;
  @ViewChild('total', {static: true}) totalRef: ElementRef;
  @ViewChild('payment1', {static: true}) payment1Ref: ElementRef;
  @ViewChild('payment2', {static: true}) payment2Ref: ElementRef;
  @ViewChild('reserve1', {static: true}) reserve1Ref: ElementRef;
  @ViewChild('reserve2', {static: true}) reserve2Ref: ElementRef;
  @ViewChild('others', {static: true}) othersRef: ElementRef;

  public data: any;
  public currency: string = 'USD ';
  public totalWidth: number = 350;
  
  constructor(private applicationStateService: ApplicationStateService, protected commonTransformerService: CommonTransformerService) { }

  ngOnInit() {
    this.parseData();
    this.onResolutionChange();
  }

  parseData() {
    if (this.financeData) {
      this.currency = this.financeData.summary.currency ? this.financeData.summary.currency : 'USD';
      this.data = {
        'Total Incurred': { 'value': 0 },
        'Total Payment': { 'parts': [], 'value': 0 },
        'Total Reserve': { 'parts': [], 'value': 0 },
        'Others': { 'value': 0 }
      };
      this.financeData.summary.labels.forEach((label, index) => {
        if (label.toLowerCase() == 'total incurred') {
          this.data['Total Incurred'].value = this.roundOffAmount(this.financeData.summary.values[index]);
        } else if (label.toLowerCase().includes('paid') || label.toLowerCase().includes('payment')) {
          this.data['Total Payment'].parts.push({
            'label': label,
            'value': this.roundOffAmount(this.financeData.summary.values[index])
          });
          this.data['Total Payment'].value += this.roundOffAmount(this.financeData.summary.values[index]);
        } else if (label.toLowerCase().includes('reserve')) {
          this.data['Total Reserve'].parts.push({
            'label': label,
            'value': this.roundOffAmount(this.financeData.summary.values[index])
          });
          this.data['Total Reserve'].value += this.roundOffAmount(this.financeData.summary.values[index]);
        } else if (label.toLowerCase().includes('other')) {
          this.data['Others'].value = this.roundOffAmount(this.financeData.summary.values[index]);
        }
      });
      this.calcTotalWidth(this.applicationStateService.getWidth());
    }
  }

  roundOffAmount(amount) {
    amount = parseFloat(amount);
    amount = Math.round(amount * 100) / 100;
    return amount;
  }

  calcTotalWidth(resolution) {
    const prevWidth = this.totalWidth;
    if (resolution < 1024) {
      this.totalWidth = resolution - 250;
    } else {
      this.totalWidth = Math.floor(resolution / 2 - 280);
    }
    if (prevWidth != this.totalWidth) {
      this.calcWidth();
    }
  }

  calcWidth() {
    this.totalRef.nativeElement.style.width = this.totalWidth + 'px';
    let margin = 0;
    let width = Math.round(Math.abs(this.data['Total Payment'].parts[0].value) / Math.abs(this.data['Total Incurred'].value) * this.totalWidth);
    width = width ? ((width + margin) > this.totalWidth ? (this.totalWidth - margin) : width) : 0;
    this.payment1Ref.nativeElement.style.width = width + 'px';
    this.payment1Ref.nativeElement.style.background = 'rgba(60, 90, 253, 1)';
    margin += width;
    margin = margin >= this.totalWidth ? margin - width : margin;
    width = Math.round(Math.abs(this.data['Total Payment'].parts[1].value) / Math.abs(this.data['Total Incurred'].value) * this.totalWidth);
    width = width ? ((width + margin) > this.totalWidth ? (this.totalWidth - margin) : width) : 0;
    this.payment2Ref.nativeElement.style.width = width + 'px';
    this.payment2Ref.nativeElement.style.background = 'rgba(60, 90, 253, 0.6)';
    margin += width;
    margin = margin >= this.totalWidth ? margin - width : margin;
    width = Math.round(Math.abs(this.data['Total Reserve'].parts[0].value) / Math.abs(this.data['Total Incurred'].value) * this.totalWidth);    
    width = width ? ((width + margin) > this.totalWidth ? (this.totalWidth - margin) : width) : 0;
    margin = margin + width > this.totalWidth ? this.totalWidth - width : margin;
    this.reserve1Ref.nativeElement.style.width = width + 'px';
    this.reserve1Ref.nativeElement.style.marginLeft = margin + 'px';
    this.reserve1Ref.nativeElement.style.background = 'rgba(140, 158, 255, 1)';
    margin += width;
    margin = margin >= this.totalWidth ? margin - width : margin;
    width = Math.round(Math.abs(this.data['Total Reserve'].parts[1].value) / Math.abs(this.data['Total Incurred'].value) * this.totalWidth);    
    width = width ? ((width + margin) > this.totalWidth ? (this.totalWidth - margin) : width) : 0;
    this.reserve2Ref.nativeElement.style.width = width + 'px';
    this.reserve2Ref.nativeElement.style.background = 'rgba(140, 158, 255, 0.6)';
    margin += width;
    margin = margin >= this.totalWidth ? margin - width : margin;
    width = Math.round(Math.abs(this.data['Others'].value) / Math.abs(this.data['Total Incurred'].value) * this.totalWidth);
    width = width ? ((width + margin) > this.totalWidth ? (this.totalWidth - margin) : width) : 0;
    margin = margin + width > this.totalWidth ? this.totalWidth - width : margin;
    margin = margin >= this.totalWidth ? margin - width : margin;
    this.othersRef.nativeElement.style.width = width + 'px';
    this.othersRef.nativeElement.style.marginLeft = margin + 'px';
    this.othersRef.nativeElement.style.background = 'rgba(179, 135, 255, 1)';
  }

  getTooltip(row, position?) {
    if (this.data) {
      if (position) {
        return this.data[row].parts[position - 1].label + ': ' + this.commonTransformerService.parseMoney(this.data[row].parts[position - 1].value, this.currency);
      }
      return row + ': ' + this.commonTransformerService.parseMoney(this.data[row].value, this.currency);
    }
    return '';
  }

  onResolutionChange() {
    this.applicationStateService.subscribeToResolution().pipe(debounceTime(50), distinctUntilChanged())
      .subscribe(resolution => {
        this.calcTotalWidth(resolution);
      });
  }
}
