import { ClientService } from './../../services/client.service';
import { BaseHttpService } from './../../services/base-http-service';


import { map } from 'rxjs/operators';
import { environment } from './../../../environments/environment';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of, from, Subject } from 'rxjs';
import { Http } from '@angular/http';
import { Constants } from './../../util/application.constants';
import { CommonTransformerService } from 'src/app/util/common-transformer.service';

@Injectable({
  providedIn: 'root',

})
export class ClaimSummaryService extends BaseHttpService {
  public headerData: any = [];
  public contentData: any = [];

  public headerTopLeftItem: any;
  public headerBottomLeftItem: any;
  public headerTopRightItem: any;
  public headerBottomRightItem: any;
  public leftTopObj: any = {}
  private claimSumaryData: any;
  public desktopData: any = [];
  public policyInformationData: any = [];
  public claimSummaryQueryParameter:any={};
  public claimNumber:any;
  constructor(public httpClient: HttpClient, private commonTransformerService: CommonTransformerService,private clientService:ClientService) {
    super(httpClient);
  }

  getClaimDetails(url,claimNumber,region?) {
    this.claimNumber=claimNumber;
    let requestObject = {
      "claimNumber": claimNumber,
      // "region": region
      // "openDiary": "true",
      // "closedDiary": "false",
      // "taskNumber": "BR_26857.2"
    }
  this.setClaimSummaryQueryParameter(requestObject)
  //  url=url+claimNumber+'/'+region;
  url=url+claimNumber;
    return super.httpGet(url);
  }

  public updateClaimSummary(url,obj,item){
    let requestObject:any={};
    if(item=='CO-INS'){
      requestObject.coinsurance=obj,
      requestObject.claimDesc=null
    }
    else if(item=='CLAIM-DESC'){
      requestObject.coinsurance=null,
      requestObject.claimDesc=obj
    }
    
    if(this.claimNumber!=undefined){
      requestObject.claimNumber=this.claimNumber; 
    }
    else{
      requestObject.claimNumber=this.clientService.getClaimNumber();
    }
      
     return  super.httpPost(url, requestObject);
  }

public setClaimSummaryQueryParameter(obj){
  this.claimSummaryQueryParameter=obj;
}

public getClaimSummaryQueryParameter(){
  return this.claimSummaryQueryParameter
}

  public setClaimSummaryData(res) {
    this.claimSumaryData = res;
  }
  public getClaimSummaryData() {
    return this.claimSumaryData;
  }

  public headerDataConverter(claimSummaryDetails) {

    for(let item of claimSummaryDetails){
      this.headerData = [];
      switch(item.name){
         case Constants.CLAIM_NUMBER:
          this.headerLeftTop(item);
          break;

          case Constants.CLAIM_HANDLER:
          this.headerLeftBottom(item);
          break;

          case Constants.CLAIM_STATUS:
          this.headerRightTop(item);
          break;
          
          case Constants.DATE_OF_LOSS:
          this.headerRightBottom(item);
          break;
      }

      // this.headerLeftTop(item);
      // this.headerLeftBottom(item);
      // this.headerRightTop(item);
      // this.headerRightBottom(item);
  
      let headerObj = {
        headerTopLeftItem: this.headerTopLeftItem,
        leftBottomItems: this.headerBottomLeftItem,
        rightTopItems: this.headerTopRightItem,
        rightBottomItems: this.headerBottomRightItem
      }
  
      this.headerData.push(headerObj);
    }
    
    return this.headerData
  }

  public headerLeftTop(item) {
    this.leftTopObj["name"] =item.name
    this.leftTopObj["value"] = item.value
    this.headerTopLeftItem = this.leftTopObj
  }

  public headerLeftBottom(item) {
    let leftBottomObj = {}
    leftBottomObj["name"] = item.name
    leftBottomObj["value"] = item.value
    this.headerBottomLeftItem = leftBottomObj;
  }

  public headerRightTop(item) {
    let rightTopObj = {}
    rightTopObj["name"] = item.name
    rightTopObj["value"] = item.value
    this.headerTopRightItem = rightTopObj;
  }

  public headerRightBottom(item) {
    let rightBottomObj = {}
    rightBottomObj["name"] =item.name
    rightBottomObj["value"] = this.commonTransformerService.dateFormatChange(item.dateValue);
    this.headerBottomRightItem = rightBottomObj;
  }

  public mobileOverviewListData(claimSummaryDetails) {
   
    this.contentData=[];
    
    for(let item of claimSummaryDetails){
     let obj:any={};
      switch(item.name){
         case Constants.CLAIM_STATUS:
          obj={
            'name': item.name,
             'value': item.value
          }
          this.contentData.push(obj)
          break;

          case Constants.CLAIM_HANDLER:
           obj={
            'name': item.name,
             'value': item.value
          }
          this.contentData.push(obj)
          break;

          case Constants.CLAIM_EXAMINER:
          obj={
            'name': item.name,
             'value': item.value
          }
          this.contentData.push(obj)
          break;
          
          case Constants.LOSS_CAUSE:
          obj={
            'name': item.name,
             'value': item.value
          }
          this.contentData.push(obj)
          break;
      }
    
    }
    return this.contentData;
  }

  

  // public policyData(item) {
  //   this.policyInformationData = {
  //     headerAttributes: [
  //       {
  //         "name": Constants.POLICY_NAME,
  //         // "value": item.name,
  //         "value":'McDonalds Corporation'
  //       },
  //       {
  //         "description": Constants.POLICY_DESC,
  //         // "value": item.description
  //         "value":"Marsh USA Inc - 135126"
  //       }
  //     ],
  //     bodyAttributes: [
  //       {
  //         "name": Constants.POLICY_ID,
  //         // "value": item.id,
  //         "value":"111363.3.01072017"
  //       },
  //       {
  //         "name": Constants.POLICY_PREMIUM,
  //         // "value": item.premium,
  //          "value":"$20,000"
  //       }, {
  //         "name": Constants.POLICY_STATUS,
  //         // "value": item.status,
  //         "value":"Active"
  //       },
  //       {
  //         "name": Constants.POLICY_OPEN_CLAIMS,
  //         // "value": item.openClaims,
  //         "value":4
  //       },
  //       {
  //         'policyDate': {
  //           "InceptionLabel": Constants.POLICY_INCEPTION_DATE,
  //           "InceptionValue": this.commonTransformerService.dateFormatChange(item.inceptionDate),     
  //           "ExpirationLabel": Constants.POLICY_EXPIRATION,
  //           "ExpirationValue": this.commonTransformerService.dateFormatChange(item.expirationDate)
          
  //         }
  //       }
  //     ]
  //   }
  //   return this.policyInformationData
  // }



  convertMultipleArrayToSingle(data) {
    let labelValueArray: any = [];
    let obj: any = {}
    for (let i = 0; i < data.summary.labels.length; i++) {
      obj = {
        id:data.summary.id[i],
        // label: data.summary.labels[i],
        // value: data.summary.values[i],
        name: data.summary.labels[i],
        value: data.summary.values[i],
        background: data.summary.background[i]
      }
      labelValueArray.push(obj);
    }
    return labelValueArray;
  }

  saveClaimDescription(result){
    // return super.httpPost(result);
  }
}
