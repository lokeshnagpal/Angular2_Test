import { Tab,TabMenuAction } from './../../../shared/ui/model/tabs-with-actions';

import { BaseComponent } from './../../../shared/ui/base/base.component';
import { ClientService } from './../../../services/client.service';
import { environment } from './../../../../environments/environment';
import { ClaimSummaryService } from './../claim-summary.service';
import { Component, OnInit, HostListener } from '@angular/core';
import { ActivatedRoute, Router, Routes } from '@angular/router';
import { Subscription } from 'rxjs';
import { ApplicationStateService } from './../../../util/application.state.service';
import { MatSnackBar } from '@angular/material';
import { CommonTransformerService } from 'src/app/util/common-transformer.service';




@Component({
  selector: 'app-claim-summary',
  templateUrl: './claim-summary.component.html',
  styleUrls: ['./claim-summary.component.scss']
})


export class ClaimSummaryComponent  {

  /*  Navigation screen configuration for the Screen */
 tabOptions:Tab[] =[{
  displayTitle:"CLAIM SUMMARY",
   navigationLink: "claimSummary"
  }
  // {
  //   displayTitle:"CLAIM DETAILS",
  //    navigationLink: "claimDetails"
  // },
  // {
  //   displayTitle:"FINANCIAL",
  //   navigationLink: "financial"
  //  },
  // {
  //   displayTitle:"DIARY DATES",
  //    navigationLink: "diary"
  // },
  // {
  //   displayTitle:"HISTORY",
  //   navigationLink: "history"
  //  },
  //  {
  //   displayTitle:"DOCUMENTS",
  //   navigationLink: "documents"
  //  }
  
  ];

 tabMenuActions:TabMenuAction[] =[{
  // displayTitle:"LARGE LOSS REPORT  (LLR)",
  // navigationLink:"llr"
  // },
  // {
  //   displayTitle:"LARGE LOSS EVENT NOTIFICATION (LLEN)",
  //   navigationLink:"llen"
  // }
  displayTitle:"ROUND TABLE",
  navigationLink:"llr"
  },
 
  ];
  

  public isDisabled: boolean;
  public isExpand: boolean;
  public claimSummaryUrl: string;
  public success: boolean = false;
  public showProgressBar:boolean=true;
  public claimNumber: any;
  public policyNumber: any;
  private region: any;  
  public pageName: any;

  public subscription: Subscription;

  constructor(private ct: CommonTransformerService, protected route: ActivatedRoute,
    private service: ClaimSummaryService, public applicationStateService: ApplicationStateService,
    private snackBar: MatSnackBar, private clientService: ClientService,private baseComponent:BaseComponent,public router: Router) {
      this.claimSummaryUrl = environment.getClaimSummaryUrl;
    this.route
    .queryParams
    .subscribe(params => {
      this.claimNumber = params['claimNumber'];     
    });   
    // this.tabOptions = this.buildNavItems(this.router.config)
  }

  ngOnInit() {    
   //INITIALIZE THE TABS REQUIRED

  //  this.tabOptions = (
  //   this.route.routeConfig && this.route.routeConfig.children ?
  //   this.buildNavItems(this.route.routeConfig.children) :
  //   []
  // ); 


    if (!this.applicationStateService.getIsDesktopResolution()) {
      this.isDisabled = false;
      this.isExpand = false;
    } else {
      this.isDisabled = true;
      this.isExpand = true;
    }
     
    this.service.getClaimDetails(this.claimSummaryUrl,this.claimNumber).subscribe(response=>       
    {
        if(Object.keys(response).length != 0){
          this.success = true;   
          this.showProgressBar=false;     
          this.baseComponent._setClaimSummary(response);
          this.policyNumber = response.policyInformation.policyId;
        }
           
      });  
  }  



  
  

  /* Method to handle the tab click */
  handleTabClick(event:any){
  // console.log(event);
    this.pageName=event.navigationLink;
  // console.log(this.pageName)
  switch (this.pageName) {
    case "claimSummary":
    this.router.navigate(["/claimSummary"], {relativeTo: this.route
      
    });
      break;
      case "diary":
    this.router.navigate(["/diary"], {
      queryParams: { "claimNumber": this.claimNumber, tab: this.pageName },
    });
      break;
    //   case "financial":
    // this.router.navigate(["/financial"], {relativeTo: this.route});
    //   break;
    //   case "claimDetails":
    // this.router.navigate(["/claimDetails"]);
    //   break;
    
    //   case "history":
    // this.router.navigate(["/history"], {relativeTo: this.route});
    //   break;
    //   case "documents":
    // this.router.navigate(["/documents"], {relativeTo: this.route});
    //   break;
    
  }
  }
}
