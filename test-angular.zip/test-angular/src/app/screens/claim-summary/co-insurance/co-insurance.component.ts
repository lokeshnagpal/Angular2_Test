import { Component, OnInit, Output, Input, ChangeDetectorRef, EventEmitter } from '@angular/core';
import { BaseComponent } from './../../../shared/ui/base/base.component';
import { Subscription } from 'rxjs';
import { ClaimSummaryService } from './../claim-summary.service';
import { SliderDialogComponent } from './../../../shared/ui/sliderDialog/sliderDialog.component';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatSnackBar } from '@angular/material';
import { environment } from './../../../../environments/environment';

@Component({
  selector: 'app-co-insurance',
  templateUrl: './co-insurance.component.html',
  styleUrls: ['./co-insurance.component.scss']
})
export class CoInsuranceComponent implements OnInit {
  public subscription: Subscription;
  public coInsData: any = [];
  public url: any;
  @Input('isDisabled') isDisabled: boolean;
  @Input('isExpand') isExpand: boolean;
  public background: any = ['#283693', '#3C5AFD', '#8C9EFF', '#B387FF', '#9576CE', '#6520FF', '#0291EB', '#3FC4FF', '#B3E5FC', '#C6CAEA'];

  constructor(private service: ClaimSummaryService, public dialog: MatDialog,
    private ref: ChangeDetectorRef, private baseComponent: BaseComponent, private snackBar: MatSnackBar) {
    this.url = environment.saveClaimSummaryUrl;
    // super();
  }


  ngOnInit() {
    this.subscribeToData();
  }
  subscribeToData() {

    this.subscription = this.baseComponent._getClaimSummary().subscribe(res => {

      if (res.coinsurance!=undefined) {       
         this.transformcoInsuranceObject(res);              
      }     
      this.coInsData = res.coinsurance;
      this.coInsData.summary.name="CoInsurance_Info"   
    });


  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  //open dialog to edit coinsurance chart data
  editChart() {
    let dialogRef;
    let labelValueArray: any = this.service.convertMultipleArrayToSingle(this.coInsData) 
    dialogRef = this.dialog.open(SliderDialogComponent, {
      width: '669px', height: 'auto', maxHeight: '500px',
      panelClass: 'coinsurance-dialog-panel',
      data: {
        labelValue: labelValueArray, summary: this.coInsData.summary
      }
    })
    dialogRef.afterClosed().subscribe(result => {
      if (result != null && result != "") {
        for (let obj of result.labelValue) {
          delete obj.background
        }
        this.coInsData = result;
        this.service.updateClaimSummary(this.url, result.labelValue, 'CO-INS').subscribe(response => {
     
        });
    
      }
    });
  }
  transformcoInsuranceObject(obj) {
 
      if (obj.coinsurance.summary == undefined) {
        obj.coinsurance.summary = {};
        obj.coinsurance.summary.chartType = "Donut";
        obj.coinsurance.summary.values = [];
        obj.coinsurance.summary.labels = [];
        obj.coinsurance.summary.id = [];
        obj.coinsurance.summary.background = this.background;
        for (let i = 0; i < obj.coinsurance.length; i++) {
          obj.coinsurance.summary.values[i] = obj.coinsurance[i].value;
          obj.coinsurance.summary.labels[i] = obj.coinsurance[i].name;
          obj.coinsurance.summary.id[i] = obj.coinsurance[i].id;
        }
      }
  }
}
