import { FileNoteDialog } from './component/file-note-dialog/file-note-dialog.component';

import { DiaryEditButtonComponent } from './component/diary-edit-button/diary-edit-button.component';
import { DiaryDialog } from './component/diary-dialog/diary-dialog.component';
import { SharedModule } from './../../shared/shared.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DiaryRoutingModule } from './diary-routing.module';
import { DiaryComponent } from './component/diary/diary.component';
import { DiaryFileNoteListComponent } from './component/diary-file-note-list/diary-file-note-list.component';
import { DiaryDetailComponent } from './component/diary-detail/diary-detail.component';
import { NgRedux, NgReduxModule } from '@angular-redux/store';
import { DiaryContainerComponent } from './diary-container/diary-container.component';
import { DiaryMobileComponent } from './component/diary-mobile/diary-mobile.component';
import { DiaryDesktopComponent } from './component/diary-desktop/diary-desktop.component';
import { FileNoteMobileComponent } from './component/file-note-mobile/file-note-mobile.component';
import { DiaryOverviewMobileComponent } from './component/diary-overview-mobile/diary-overview-mobile.component';
import { FroalaEditorModule, FroalaViewModule } from 'angular-froala-wysiwyg';
import { GroupCommentDesktopComponent } from 'src/app/screens/diary/component/group-comment-desktop/group-comment-desktop.component';
import { AddFileNoteComponent } from './component/add-file-note/add-file-note.component';
import { DiaryDashboardComponent } from './component/diary-dashboard/diary-dashboard.component';
import { EditFileNoteMobileComponent } from './component/edit-file-note-mobile/edit-file-note-mobile.component';
import { ClaimSummaryCardDesktopComponent } from './component/claim-summary-card-desktop/claim-summary-card-desktop.component';
import { DiaryDashboardMobileComponent } from './component/diary-dashboard-mobile/diary-dashboard-mobile.component';
import { FileNoteFilterComponent } from './component/file-note-filter/file-note-filter.component';
import { DiaryDashboardFilterComponent } from './component/diary-dashboard-filter/diary-dashboard-filter.component';
// import { IAppState, rootReducer, INITIAL_STATE } from './../../../app/store/store';
import{CalendarComponent} from './component/calendar/calendar.component'
import {DatePipe} from '@angular/common';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';

@NgModule({
  declarations: [DiaryComponent, DiaryFileNoteListComponent, FileNoteMobileComponent, DiaryDetailComponent, DiaryDialog,
    FileNoteDialog, DiaryEditButtonComponent, DiaryContainerComponent, DiaryMobileComponent, DiaryDesktopComponent,
    DiaryOverviewMobileComponent, GroupCommentDesktopComponent, AddFileNoteComponent, DiaryDashboardComponent,
    ClaimSummaryCardDesktopComponent, EditFileNoteMobileComponent, DiaryDashboardMobileComponent, FileNoteFilterComponent,
    DiaryDashboardFilterComponent,CalendarComponent],
 imports: [
    CommonModule,
    SharedModule,
    DiaryRoutingModule,
    InfiniteScrollModule,
  FroalaEditorModule.forRoot(), FroalaViewModule.forRoot()
  ],
  providers: [DatePipe],
  
  entryComponents: [
    DiaryDialog, FileNoteDialog
  ],

})
export class DiaryModule {


 }
