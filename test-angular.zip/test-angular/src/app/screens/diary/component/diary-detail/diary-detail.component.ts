import { DiaryDialog } from './../diary-dialog/diary-dialog.component';
import { ClientService } from './../../../../services/client.service';
import { environment } from './../../../../../environments/environment';
import { DiaryService } from './../../diary.service';
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatSnackBar } from '@angular/material';
import { CommonTransformerService } from 'src/app/util/common-transformer.service';

@Component({
  selector: 'app-diary-detail',
  templateUrl: './diary-detail.component.html',
  styleUrls: ['./diary-detail.component.scss']
})
export class DiaryDetailComponent implements OnInit {

  public convertedDueDate:any;

  @Input() taskAttributes;

  constructor(private service: DiaryService, public dialog: MatDialog, private clientService: ClientService,
    public snackBar: MatSnackBar,private commonTransformerService: CommonTransformerService) {
  }

  ngOnInit() {

  }

  ngOnChanges(){
      if(this.taskAttributes){
      for(let attribute of this.taskAttributes){
        if(attribute.dbColumnName=="DUE_DATE"){
         this.convertedDueDate=this.commonTransformerService.dateFormatChange(attribute.dbdateValue);
        }
      }
    }

  }

}
