import { Component, OnInit, Output, Input,EventEmitter } from '@angular/core';
import { FormsModule } from '@angular/forms'
import { Router, ActivatedRoute } from '@angular/router';
import { MatIconRegistry } from '@angular/material/icon';
import { DatePipe } from '@angular/common';
import { ClientService } from 'src/app/services/client.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-calendar',
  templateUrl: './calendar.component.html',
  styleUrls: ['./calendar.component.scss']
})
export class CalendarComponent implements OnInit {

  public currentDate = new Date()    //today's date
  private yearType:string;     //leap year or not
  public months: string[] = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  public days: string[] = ["SUNDAY", "MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY"];
  public year:number = this.currentDate.getFullYear();     //fetching year
  private currentMonth:string = this.months[this.currentDate.getMonth()];
  private currentYear:number = this.currentDate.getFullYear();
  public month:string = this.months[this.currentDate.getMonth()];
  public day:number = this.currentDate.getDate();
  private numOfDays:number;   //number of days in a particular month 
  public nameOfToday:string = this.days[this.currentDate.getDay()];    //name of the week today
  public nameOfDay:string;    //weekday name on a first date of a month
  public tiles = [];   // contains data for each tile
  private tileNumber:number; //iterator for months values
  private newYearValue:number;  //new values of year according to zellar algorithms
  private newMonthValue:number;
  private checkTile:number; //variable to check how many tiles are left in the starting
  public serviceArray = []  //contains the data comming from service but in a format that can be used in frontend
  public allData:string;  //stores the as it is comming from backend
  public attr:any;
  private start = 0;
  private end = 41;
  public overdueCount:number;
  public sidenavDate:number
  public extraEvents:any;
  @Output() showDashboard = new EventEmitter<boolean>();
  @Input() columnId: any;

  constructor(private datePipe: DatePipe, private clientService: ClientService, private router: Router) { }

  ngOnInit() {
    this.numOfDays = 0;
    this.initializeTiles();
    if (this.columnId) {
      this.runNeededFunctions();
    }
  }

  //consolidating functions that need to be called every time we load the page 
  private runNeededFunctions() {
    this.viewMonthCalendar(this.month, this.year)
    this.nextMonthDates();
    this.previousMonthDates()
    this.attr = {
      "sectionCode": "DIARY_LIST_VIEW_TABLE",
      "sortColumnId": this.columnId,
      "sortDirection ": "ASC",
      "filterCriteria": {},
      'customFilterId': '0',
      'isGenericSearch': true
    }
    this.attr.filterCriteria[this.columnId] = this.tiles[this.start].dateRepresenting + "," + this.tiles[this.end].dateRepresenting;
    this.clientService.setUrl(environment.searchUrl)
    this.clientService.getDiaryTableData(this.attr).subscribe(response => {
      this.allData = response.json();
      this.serviceDataToComponentData(this.allData)
      this.dataMapping()
    })
  }

  //initially allocating memory to all the tiles
  private initializeTiles() {
    for (var i = 0; i < 42; i++) {
      this.tiles[i] =
        {
          tileNumberinTile: i,
          date: null,
          month: null,
          year: null,
          dateRepresenting: null,
          events: [],
          isToday: false,
          noOfEvents: null
        }
    }
  }

  private serviceDataToComponentData(serviceData) {
    this.serviceArray = serviceData.data.map(eachData => {
      return {
        "insured": eachData.find(data => data.dbColumnName === 'INSURED').value,
        "claimNumber": eachData.find(data => data.dbColumnName === 'CLAIM_NUMBER').value,
        "taskNumber": eachData.find(data => data.dbColumnName === 'TASK_NUM').value,
        "dueDate": (eachData.find(data => data.dbColumnName === 'DUE_DATE').value).substring(0, 8),
        "status": eachData.find(data => data.dbColumnName === 'STATUS').value,
        "priority": eachData.find(data => data.dbColumnName === 'PRIORITY_DIARY').value,
        "newStatus": ""
      }
    })
  }


  //mapping the data recieved from service to the events array of respective tiles
  private dataMapping() {
    this.overdueCount = 0;
    for (var i = 0; i < 42 && this.serviceArray.length !== 0; i++) {
      for (var j = 0; j < this.serviceArray.length; j++) {   //need to optimise this function.. knows how but not able to do it.. errors are coming
        if (this.tiles[i].dateRepresenting === this.serviceArray[j].dueDate) {
          if (this.serviceArray[j].status == "Closed") {
            this.serviceArray[j].newStatus = "Closed"
          } else {
            if (this.serviceArray[j].dueDate < this.transformDate(this.currentDate)) {
              this.serviceArray[j].newStatus = "overdue"
              this.overdueCount += 1;
              this.tiles[i].events.push(this.serviceArray[j])
            }
            else {
              this.serviceArray[j].newStatus = "upcoming"
              this.tiles[i].events.push(this.serviceArray[j])
            }
          }
          // this.tiles[i].events.push(this.serviceArray[j]) 
        }
        else {
          for (var t = 0; t < j; t++) {
            this.serviceArray.shift();
          }
          break;
        }
      }
    }
  }

  //transforms date into the same format as recieved from service, used in datamapping to change status
  private transformDate(date) {
    return (this.datePipe.transform(date, "yyyyMMdd"));
  }

  //checks if a year is an leap year or not   
  private isLeapYear(year) {
    if ((year % 4) !== 0)
      this.yearType = "Non leap year"
    else {
      if ((year % 100) == 0 && (year % 400) !== 0) {
        this.yearType = "Non leap year"
      }
      else
        this.yearType = "Leap year"
    }
  }


  //stores the number of days in a month to the variable numOfDays   
  private numberOfDays(month,year): number {
    switch (month) {
      case "Apr":
      case "Jun":
      case "Sep":
      case "Nov": {
        return 30;
      }
      case "Feb": {
        this.isLeapYear(year);
        if (this.yearType === "Leap year") {
          return 29;
        }
        else {
          return 28;
        }
      }
      default: {
        return 31
      }
    }
  }

  //allocates new value to the newMonthValue and newYearValue variable according to zellar            
  private newValue(month, year) {
    switch (month) {
      case "Jan": {
        this.newMonthValue = 11;
        this.newYearValue = year - 1;
      }
      case "Feb": {
        this.newMonthValue = 11;
        this.newYearValue = year - 1;
      }
      default: {
        this.newYearValue = year;
        this.newMonthValue = (this.months.indexOf(month)) - 1;
      }
    }
  }

  //function to find out the name of weekday on a particular date, here i am useing it to find the day on 1st date of every month
  private nameOnSpecificDate(day, month, year) {
    this.newValue(month, year)
    var zellar = day + Math.floor(((13 * this.newMonthValue) - 1) / 5)+ (this.newYearValue % 100) + Math.floor((this.newYearValue % 100) / 4) +
     Math.floor((this.newYearValue / 100) / 4) - 2 * Math.floor(this.newYearValue / 100);
    if (zellar >= 0)
      var rem = (zellar % 7)
    else {
      if (zellar % 7 === 0)
        var rem = 0
      else
        var rem = (zellar % 7) + 7
    }
    this.nameOfDay = this.days[rem]
  }

  //this  function is called when we click  previous arrow, basically changes the month and calls  viewMonthCalendar function
  public prevMonth() {
    if (this.month === "Jan") {
      this.month = this.months[11];
      this.year = this.year - 1;
    }
    else {
      this.month = this.months[this.months.indexOf(this.month) - 1]
      this.year = this.year;
    }
    this.runNeededFunctions()
  }

  //this  function is called when we click  next arrow, basically changes the month and calls  viewMonthCalendar function
  public nextMonth() {
    if (this.month === "Dec") {
      this.month = this.months[0];
      this.year = this.year + 1;
    }
    else {
      this.month = this.months[this.months.indexOf(this.month) + 1]
      this.year = this.year;
    }
    this.runNeededFunctions()
  }

  // this function mainly allocats the date of a particular month to tiles initially generated which are shown in frontend by 2-way binding
  private viewMonthCalendar(month, year) {
    this.initializeTiles();
    this.nameOnSpecificDate(1, month, year)
    this.numOfDays = this.numberOfDays(month,year)
    this.tileNumber = this.days.indexOf(this.nameOfDay);
    this.checkTile = this.tileNumber;
    for (var i = 1; i < (this.numOfDays + 1); i++) {
      this.tiles[this.tileNumber].date = i;
      this.tiles[this.tileNumber].month = this.month;
      this.tiles[this.tileNumber].year = this.year;
      this.dateRepresentation(this.tileNumber, i);
      //  this.eventDataInsertion(this.tileNumber)
      this.tiles[this.tileNumber].noOfEvents = this.tiles[this.tileNumber].events.length;
      this.tileNumber = this.tileNumber + 1;
    }
  }

  //converts the date in the format of yyyymmdd      ********************************************
  private dateRepresentation(tileNumber, i) {
    if (i < 10 || this.months.indexOf(this.tiles[tileNumber].month) < 9) {
      if (i >= 10 && this.months.indexOf(this.tiles[tileNumber].month) < 9) {
        this.tiles[tileNumber].dateRepresenting = this.year + "0" + (this.months.indexOf(this.tiles[tileNumber].month) + 1) + "" + i;
      }
      else if (i < 10 && this.months.indexOf(this.tiles[tileNumber].month) < 9) {
        this.tiles[tileNumber].dateRepresenting = this.year + "0" + (this.months.indexOf(this.tiles[tileNumber].month) + 1) + "0" + i;
      }
      else {
        this.tiles[tileNumber].dateRepresenting = this.year + "" + (this.months.indexOf(this.tiles[tileNumber].month) + 1) + "0" + i;
      }
    }
    else {
      this.tiles[tileNumber].dateRepresenting = this.year + "" + (this.months.indexOf(this.tiles[tileNumber].month) + 1) + "" + i;
    }
    if (this.day === i && this.tiles[tileNumber].month === this.currentMonth && this.tiles[tileNumber].year === this.currentYear) {
      this.tiles[tileNumber].isToday = true;
    }
    else {
      this.tiles[tileNumber].isToday = false;
    }
  }

  //function that gives previous months dates that should be shown in current month due to empty tiles
  private previousMonthDates() {
    var t = this.numberOfDays(this.months[this.months.indexOf(this.month) - 1],this.year)
    for (var i = (this.checkTile - 1); i >= 0; i--) {
      this.tiles[i].date = t;
      if (this.month === "Jan") {
        this.tiles[i].month = this.months[11];
        this.tiles[i].year = this.year - 1
      }
      else {
        this.tiles[i].month = this.months[(this.months.indexOf(this.month)) - 1]
        this.tiles[i].year = this.year
      }
      this.dateRepresentation(i, t)
      t = t - 1;
    }
  }

  //function that gives next months dates that should be shown in current month due to empty tiles
  private nextMonthDates() {
    var leftTile = this.tileNumber
    for (var i = 1; i < (43 - leftTile); i++) {
      this.tiles[this.tileNumber].date = i;
      if (this.month != "Dec") {
        this.tiles[this.tileNumber].month = this.months[(this.months.indexOf(this.month)) + 1]
        this.tiles[this.tileNumber].year = this.year
      }
      else {
        this.tiles[this.tileNumber].month = this.months[0]
        this.tiles[this.tileNumber].year = this.year + 1;
      }
      this.dateRepresentation(this.tileNumber, i)
      // this.eventDataInsertion(this.tileNumber)
      this.tileNumber = this.tileNumber + 1;
    }
  }
  public eventTooptip(event) {
    return (event.insured + " " + event.taskNumber)
  }
  public moreEvents(events, date, month, year) {
    this.nameOnSpecificDate(date, month, year)
    this.sidenavDate = date;
    this.extraEvents = events;
  }
  public displayDashboard() {
    this.showDashboard.emit(false)
  }
}