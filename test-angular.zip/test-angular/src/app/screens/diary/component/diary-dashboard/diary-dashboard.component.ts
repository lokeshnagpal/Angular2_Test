import { Component, OnInit, ChangeDetectorRef, Input, ViewChild, AfterViewInit, ElementRef, HostListener, Renderer2} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { SelectionModel } from '@angular/cdk/collections';
import { MatTableDataSource, MatDialog, MatSnackBar, MatMenu, MatTable} from '@angular/material';
import { ClientService } from 'src/app/services/client.service';
import { environment } from 'src/environments/environment';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { ApplicationStateService } from 'src/app/util/application.state.service';
import { DiaryComponent } from '../diary/diary.component';
import { DiaryService } from '../../diary.service';
import { CommonTransformerService } from 'src/app/util/common-transformer.service';
import { SearchUserDialog } from 'src/app/shared/ui/search-user-dialog/search-user-dialog.component';

@Component({
  selector: 'app-diary-dashboard',
  templateUrl: './diary-dashboard.component.html',
  styleUrls: ['./diary-dashboard.component.scss']
})
export class DiaryDashboardComponent extends DiaryComponent implements OnInit, AfterViewInit {

  public dataSource: any;
  public displayedColumns: string[] = [];
  public selection: any;
  public DIARY_DATA: any;
  public DIARY_DATA_UNTOUCHED: any;
  public SORT_DATA: any = [];
  public FILTER_DATA: any;
  public recordCount: any;
  public count: any;
  public sectionDetails: any;
  public option = 'sort';
  public isSorted: any = false;
  public isFiltered: any = false;
  public sortArray: any = [];
  public filterObject: any;
  public categories: any;
  public diaryStatus: any;
  public stats: any;
  public showProgressBar = false;
  public indicators: any = [];
  public isFilterDataLoaded = false;
  public filteredColumns: string[] = [];
  public initialTotalCount: any;
  public lastComment = '';
  public commentClicked = false;
  public columnIndex: any;
  public stickyColumn: any;
  public configColumnName: any = [];
  public actionColumnSticky = false;
   public commentLoaded = true;
  public targetComment: any;
  public showCalendar = false;
  public assigneeObj: any;
  public clearConfig = false;
  public disableSave = true;
  public settings: any;
  public tableSettings: string[];
  public resetSidenav = false;
  public savedSettings: any[] = [];
  public currentSetting: string = 'default';
  public dueDateId: string;
  public isIE: boolean = false;
  @ViewChild('sidenav', {static: false}) sidenav: any;

  constructor(public clientService: ClientService, private router: Router, public applicationStateService: ApplicationStateService,
    public service: DiaryService, public commonTransformerService: CommonTransformerService, public route: ActivatedRoute,
    public dialog: MatDialog, public ref: ChangeDetectorRef, public snackBar: MatSnackBar, private renderer: Renderer2) {
    super(service, route, clientService, dialog, ref, snackBar, commonTransformerService);
    this.tableSettings = ['Filter', 'Sort', 'Configure Columns'];
    this.isIE = this.applicationStateService.isBrowserIE();
  }

  ngOnInit() {
    this.showProgressBar = true;
    this.getSavedSettings(null, true);
  }

  ngAfterViewInit() {
    this.closeSideNav = () => {
      this.actionColumnSticky = false;
      this.sidenav.close();
    };
  }

  initComponent(init?) {
    if (init) {
      this.initDashboard(true);
    } else {
      const attr = {
        'sectionCode': 'DIARY_LIST_VIEW_TABLE',
        'startRow': 1,
        'endRow': 30,
        'customFilterId': '0',
        'isGenericSearch': true,
        'sortColumnId': this.dueDateId,
        'sortDirection': 'DESC'
      };
      this.clientService.setUrl(environment.searchUrl);
      this.clientService.getDiaryTableData(attr).subscribe(response => {
        this.DIARY_DATA = response.json();
        this.DIARY_DATA_UNTOUCHED = { ...this.DIARY_DATA };
        this.initDashboard();
      });
    }
  }

  initDashboard(load?) {
    this.selection = new SelectionModel(true, []);
    if (!load) {
      this.dataSource = new MatTableDataSource(this.DIARY_DATA.data);
      this.recordCount = this.DIARY_DATA.recordCount;
      this.initialTotalCount = this.recordCount;
      this.count = this.recordCount < 30 ? this.recordCount : 30;
      this.sectionDetails = this.DIARY_DATA.sectionDetails;
      this.buildSort();
      this.buildFilter();
      this.getStatistics();
    } else {
      this.buildSort();
      this.buildFilter();
      this.loadSetting(true);
    }
  }
  getSectionDetails(init?) {
    this.clientService.setUrl(environment.lookupUrl + '/section/DIARY_LIST_VIEW_TABLE');
    this.clientService.getClientData().subscribe(response => {
      const tempSections = [];
      response.attributes.forEach(attribute => {
        const section = {
          'attrSize': attribute.attrSize,
          'columnLabel': attribute.name,
          'columnName': attribute.dbColumnName,
          'columnType': attribute.type,
          'hidden': attribute.hidden,
          'mandatory': attribute.mandatory,
          'sectionAttrId': attribute.secAttrMapId
        };
        tempSections.push(section);
      });
      this.sectionDetails = tempSections;
      const columns = [];
      this.configColumnName = [];
      this.sectionDetails.forEach(header => {
        if (!header.hidden) {
          if (header.mandatory) {
            columns.push(header.columnName);
          }
          this.configColumnName.push({...header});
        }
        if (header.columnName == 'DUE_DATE') {
          this.dueDateId = header.sectionAttrId;
        }
      });
      this.displayedColumns = ['select', ...columns];
      this.initComponent(init);
    });
  }
  getStatistics(statsAttr?) {
    const attr = statsAttr ? statsAttr : { 'sectionCode': 'DIARY_LIST_VIEW_TABLE' };
    this.clientService.setUrl(environment.statsUrl);
    this.clientService.postClientData(attr).subscribe(response => {
      this.stats = response.statistics;
      this.showProgressBar = false;
    });
  }
  viewMore() {
    this.apply('none', (this.count + 60));
  }
  getSavedSettings(name?, init?) {
    this.clientService.setUrl(environment.lookupUrl + '/CUSTOM_FILTER_DATA/Custom_Filters_Diaries/');
    this.clientService.getClientData().subscribe(response => {
      this.savedSettings = [{'id': 'default', 'name': 'Default Settings'}, ...response];
      if (name) {
        this.savedSettings.forEach(setting => {
          if (setting.name == name) {
            this.currentSetting = setting.id;
          }
        });
      }
      if (init) {
        if (this.savedSettings && this.savedSettings.length > 1) {
          this.savedSettings.forEach(setting => {
            if (setting.isDefault) {
              this.currentSetting = setting.id;
            }
          });
          if (this.currentSetting != 'default') {
            this.getSectionDetails(true);
          } else {
            this.getSectionDetails();
          }
        } else {
          this.getSectionDetails();
        }
      }
    });
  }

  loadSetting(init?) {
    if (this.currentSetting && this.currentSetting != 'default') {
      const setting = this.savedSettings.find(setting => setting.id == this.currentSetting);
      if (setting) {
        const attr = {
          'filterName': setting.name,
          'action': 'LOAD',
          'currentTab': 'CODiaries'
        };
        if (!init) {
          this.setAsDefaultSetting();
        }
        this.clientService.setUrl(environment.customSettingsUrl);
        this.clientService.postClientData(attr).subscribe(response => {
          this.applyConfigureColumns(response);
          this.applySettings(response.userFilters);
        });
      }
    } else if (this.currentSetting && this.currentSetting == 'default') {
      if (!init) {
        this.setAsDefaultSetting();
      }
      this.applyConfigureColumns();
      const settings = [];
      this.applySettings(settings);
    }
  }

  setAsDefaultSetting() {
    let name = 'Default Diary Filter';
    if (this.currentSetting && this.currentSetting.length > 0 && this.currentSetting != 'default') {
      const setting = this.savedSettings.find(setting => setting.id == this.currentSetting);
      if (setting) {
        name = setting.name;
      }
    }
    let attr = {
      'filterName':  name,
      'action':  'SAVE_DEFAULT',
      'currentTab': 'CODiaries'
    };
    this.clientService.setUrl(environment.customSettingsUrl);
    this.clientService.postClientData(attr).subscribe(response => {
      console.log(name + ' set as default setting.');
    });
  }

  applyConfigureColumns(response?) {
    if (response && response.searchCriteria && response.searchCriteria.columnPreferences && response.searchCriteria.columnPreferences.userColumnSelected && response.searchCriteria.columnPreferences.userColumnSelected.length > 0) {
      const columnsToDisplay = response.searchCriteria.columnPreferences.userColumnSelected;
      const columns = ['select'];
      columnsToDisplay.forEach(column => {
        const columnObj = this.sectionDetails.find(section => section.sectionAttrId == column.code);
        if (columnObj) {
          columns.push(columnObj.columnName);
        }
      });
      const event = {
        columns
      };
      this.onConfigureColumns(event, true);
    } else {
      const columns = [];
      this.sectionDetails.forEach(header => {
        if (!header.hidden) {
          if (header.mandatory) {
            columns.push(header.columnName);
          }
        }
      });
      const event = {
        columns: ['select', ...columns]
      };
      this.onConfigureColumns(event, true);
    }
  }

  deleteSetting(setting) {
    const settings = this.savedSettings.filter(userSetting => userSetting.id != setting.id);
    this.savedSettings = [...settings];
    this.showMessage(setting.name + ' has been deleted.', 2000);
    this.setAsDefaultSetting();
  }
  openAssignSelectionDialog() {
    if (this.selection._selected && this.selection._selected.length > 0) {
      if (this.assigneeObj === undefined) {
        this.assigneeObj = {
          'sectionId': 150,
          'alias': 'HEADERCOLUMNS',
          'query': ''
        };
        this.sectionDetails.forEach(section => {
          if (section.columnName === 'ASSIGNEDTO') {
            this.assigneeObj.group = section.sectionAttrId + '#~#' + section.columnName + '#~#' + section.columnType;
          }
        });
      }
      const data = {
        header: 'Assign Selected to',
        url: environment.lookupUrl + '/USERGROUP/ACTIVE_USERS/',
        select: 'ASSIGN',
        cancel: 'CANCEL'
      };
      const dialogRef = this.dialog.open(SearchUserDialog, {
        width: '30%',
        minWidth: '480px',
        height: '65%',
        data,
        autoFocus: false
      });
      dialogRef.afterClosed().subscribe(result => {
        if (result) {
          this.assignSelection(result);
        }
      });
    } else {
      this.showMessage('Select atleast one row to assign.', 2000);
    }
  }
  assignSelection(assignee) {
    const taskNumbers = [];
    this.selection._selected.forEach(row => {
      row.forEach(cell => {
        if (cell.dbColumnName === 'TASK_NUM') {
          taskNumbers.push(cell.value);
        }
      });
    });
    const attr = {
      taskNumbers,
      action: 'ASSIGN',
      assignee: assignee.id.toUpperCase()
    };
    if (taskNumbers.length > 0) {
      this.clientService.setUrl(environment.taskServiceUrl + 'bulk');
      this.clientService.postClientData(attr).subscribe(response => {
        this.selection = new SelectionModel(true, []);
        this.showMessage('Selected Diaries are assigned to ' + assignee.name, 3000);
        this.apply();
      });
    }
  }
  closeSelection() {
    const taskNumbers = [];
    this.selection._selected.forEach(row => {
      row.forEach(cell => {
        if (cell.dbColumnName === 'TASK_NUM') {
          taskNumbers.push(cell.value);
        }
      });
    });
    const attr = {
      taskNumbers,
      action: 'CLOSE'
    };
    if (taskNumbers.length > 0) {
      this.clientService.setUrl(environment.taskServiceUrl + 'bulk');
      this.clientService.postClientData(attr).subscribe(response => {
        this.selection = new SelectionModel(true, []);
        this.showMessage('Selected Diaries are closed', 3000);
        this.apply();
      });
    }
  }
  redirectToClaim(event, claimNumber, diaryId?, diaryStatus?, region?) {
    event.stopPropagation();
    if (diaryId && diaryStatus) {
      // window.open(environment.environmentUrl + '#diary:/ClaimNum=' + claimNumber + '&redirect=true&diaryId=' + diaryId);
      this.router.navigate([''], { queryParams: { claimNumber, redirect: true, diaryId, diaryStatus } });
    } else {
      if (region) {
        if (region === 'BRAZIL') {
          window.open( environment.environmentUrl + '#activityCorsoBR:/ClaimNum=' + claimNumber + '/REGION=' + region, '_blank');
        } else {
          window.open( environment.environmentUrl + '#activity:/ClaimNum=' + claimNumber + '/REGION=' + region, '_blank');
        }
      }
    }
  }
  findRowValue(column, row) {
    const foundCell =  row.find(cell => {
      return column === cell.dbColumnName;
    });
    return foundCell.value;
  }
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }
  masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.dataSource.data.forEach(row => this.selection.select(row));
  }
  checkboxLabel(row ? ): string {
    if (!row) {
      return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.position + 1}`;
  }
  parseColumn(header, index, column) {
    let parsed = this.findRowValue(header.columnName, column);
    const columnType = this.sectionDetails[index].columnType;
    if (columnType == 'CLICKABLECOLUMN') {
      const claimNumber = this.findRowValue('CLAIM_NUMBER', column);
      parsed = claimNumber;
    } else if (header.columnName == 'DUE_DATE') {
      const date = new Date(parsed.substring(0, 4), (parsed.substring(4, 6) - 1), parsed.substring(6, 8)).toString().split(' ');
      parsed = date[2] + ' ' + date[1] + ' ' + date[3];
      // parsed = this.commonTransformerService.dateTimeZoneChange(parsed);
      // parsed = this.commonTransformerService.dateObjectFormatChange(parsed);
    } else if (header.columnName == 'INSURED') {
      parsed = '<b>' + parsed + '</b>';
    } else if (header.columnName == 'CLAIM_INDICATORS') {
      if (parsed && parsed.length > 0) {
        parsed = this.parseIndicators(parsed);
      }
    } else if (header.columnName == 'PRIORITY_DIARY') {
      if (parsed.toLowerCase() == 'important' || parsed.toLowerCase() == 'required') {
        parsed = this.getIndicatorHtml('!');
      } else {
        parsed = '';
      }
    }
    return parsed;
  }
  parseIndicators(parsed) {
    const indicators = parsed.split('#~#');
    const indicatorFlags = {
      'IPA': false,
      'Pulse': false,
      'Primary': false,
      'Confidential': false
    };
    indicators.forEach(indicator => {
      const split = indicator.split('=');
      if (split[0] == 'PROGRAM_NUMBER') {
        indicatorFlags['IPA'] = true;
      } else if (split[0] == 'CLIENT_PORTAL_IND' && split[1] == 'Y') {
        indicatorFlags['Pulse'] = true;
      } else if (split[0] == 'MARKET_POSITION' && split[1].includes('Primary')) {
        indicatorFlags['Primary'] = true;
      } else if (split[0] == 'CONFIDENTIALITY' && split[1] == 'Y') {
        indicatorFlags['Confidential'] = true;
      }
    });
    let html = '';
    if (indicatorFlags['IPA']) {
      html = this.getIndicatorHtml('IPA');
    } else if (indicatorFlags['Pulse']) {
      html = this.getIndicatorHtml('PULSE');
    } else if (indicatorFlags['Primary']) {
      html = this.getIndicatorHtml('Primary');
    } else if (indicatorFlags['Confidential']) {
      html = `<span style="background-color: #DCE2FF; margin: 0px 8px 0px 0px; border-radius: 35px; width: auto; padding: 0px 4px 0px 4px"><img style="width: 12px; height: 13px;" src="./assets/outline-remove_red_eye-24px.svg" /></span>`;
    }
    return html;
  }
  getIndicatorHtml(label) {
    return `<span  style="background-color: #DCE2FF; margin: 0px 8px 0px 0px; border-radius: 35px; padding:2px 9px 1px 9px; position: relative; font-family: swissReOtFontRegular; font-size: 12px; color: #333333;">` + label + `</span>`;
  }

  // Methods for Sidenav and its functionalities
  showSidenav(option) {
    this.option = option;
    this.disableSave = true;
  }
  sortEvent(event) {
    this.sortArray = event;
    this.apply('sort');
  }
  filterEvent(event) {
    this.filterObject = event;
    this.apply('filter');
  }
  buildSort() {
    this.sectionDetails.forEach(section => {
      if (!section.hidden && this.displayedColumns.length > 0 && this.displayedColumns.includes(section.columnName)) {
        this.SORT_DATA.push({
          name: section.columnLabel,
          id: section.sectionAttrId,
          order: 'none'
        });
      }
    });
    this.sortArray = [ ...this.SORT_DATA ];
  }
  buildFilter() {
    let filterString = '{ ';
    this.sectionDetails.forEach((section, index) => {
      if (!section.hidden) {
        filterString += '"' + section.columnLabel + '": { "dbColumnName": "' + section.columnName + '", "show": "' + section.mandatory + '", "columnType": "' + section.columnType + '", "sectionAttrId": "' + section.sectionAttrId + '", "value": "", "columnType": "' + section.columnType + '" }';
        if (index < this.sectionDetails.length - 1) {
          filterString += ', ';
        }
      }
    });
    filterString += ' }';
    this.FILTER_DATA = JSON.parse(filterString);
    this.FILTER_DATA['Due Date'].from = '';
    this.FILTER_DATA['Due Date'].to = '';
    this.filterObject = {...this.FILTER_DATA};
  }
  getMandatoryFilters() {
    if (this.displayedColumns && this.displayedColumns.length > 0) {
      this.sectionDetails.forEach(section => {
        if (this.displayedColumns.length > 0 && this.displayedColumns.includes(section.columnName)) {
          this.filterObject[section.columnLabel].show = true;
        } else {
          if (this.filterObject[section.columnLabel]) {
            this.filterObject[section.columnLabel].show = false;
          }
        }
      });
    }
  }
  validateSettings(event) {
    this.settings = event;
    if (event.name && event.name.length > 0 && event.selected && event.selected.length > 0) {
      let isUnique = true;
      this.savedSettings.forEach(setting => {
        if (setting.name == event.name || event.name == 'Default Diary Filter') {
          isUnique = false;
        }
      });
      if (isUnique) {
        this.disableSave = false;
      } else {
        this.disableSave = true;
      }
    } else {
      this.disableSave = true;
    }
  }
  save(option) {
    if (option == 'saveSettings') {
      this.saveSettings();
    }
  }
  saveSettings() {
    this.resetSidenav = true;
    const sort = this.settings.selected.includes('Sort');
    const filter = this.settings.selected.includes('Filter');
    const searchCriteria = this.generateRequestAttr(sort, filter, 30).diaryAttr;
    let attr = {
      'filterName':  this.settings.name,
      searchCriteria,
      'action':  'SAVE',    // action can be SAVE – Save or Update And DELETE - Delete
      'currentTab': 'CODiaries'
    };
    if (this.settings.selected.includes('Configure Columns')) {
      const columns = [];
      this.displayedColumns.forEach(column => {
        if (column != 'select') {
          const columnObj = this.sectionDetails.find(section => section.columnName == column);
          if (columnObj) {
            columns.push({
              'code': columnObj.sectionAttrId,
              'name': columnObj.columnLabel
            });
          }
        }
      });
      const appendColumns = {
        'columnPreferences': {
          'userColumnSelected': columns
        },
        'sectionId': 150
      };
      attr.searchCriteria = {...attr.searchCriteria, ...appendColumns};
    }
    this.clientService.setUrl(environment.customSettingsUrl);
    this.clientService.postClientData(attr).subscribe(response => {
      this.showMessage('Settings saved as ' + this.settings.name, 2000);
      this.getSavedSettings(this.settings.name);
    });
  }
  resettedSidenav(event, option) {
    if (event) {
      this.resetSidenav = false;
      this.ref.detectChanges();
    }
  }
  clear(option) {
    if (option == 'sort') {
      this.clearSorting();
    } else if (option == 'filter') {
      this.clearFiltering();
    } else if (option == 'configColumn') {
      this.clearConfigure();
    }
  }
  clearSorting() {
    this.isSorted = false;
    this.sortArray = [...this.SORT_DATA];
    this.sortArray.forEach(column => column.order = 'none' );
    if (this.isFiltered == false) {
      this.apply(null);
    } else {
      this.apply('filter');
    }
  }
  clearFiltering() {
    this.isFiltered = false;
    this.filterObject = this.FILTER_DATA;
    this.filteredColumns = [];
    for (const column in this.filterObject) {
      if (column == 'Due Date') {
        this.filterObject[column].from = '';
        this.filterObject[column].to = '';
      }
      this.filterObject[column].value = '';
    }

    if (this.isSorted == false) {
      this.apply(null);
    } else {
      this.apply('sort');
    }
  }
  public clearConfigure() {
    this.clearConfig = true;
  }
  public clearedConfigure(event) {
    this.clearConfig = false;
    this.ref.detectChanges();
  }
  parseStats(separator?) {
    let parsed = '';
    if (separator) {
      parsed += '|  ';
    }
    if (this.stats.OPEN_DIARY_COUNT || this.stats.OPEN_DIARY_COUNT == 0) {
      parsed += this.stats.OPEN_DIARY_COUNT + ' Open';
    }
    if (this.stats.ALREADY_DUE_COUNT || this.stats.ALREADY_DUE_COUNT == 0) {
      parsed += '  |  ' + this.stats.ALREADY_DUE_COUNT + ' Overdue';
    }
    if (this.stats.DUE_TODAY_COUNT || this.stats.DUE_TODAY_COUNT == 0) {
      parsed += '  |  ' + this.stats.DUE_TODAY_COUNT + ' Due Today';
    }
    return parsed;
  }
  generateRequestAttr(sort, filter, endRow?) {
    const statsAttr = {
      'sectionCode': 'DIARY_LIST_VIEW_TABLE',
      'subFilterCriteria': {},
      'filterCriteria': {}
    };
    const attr = {
      'sectionCode': 'DIARY_LIST_VIEW_TABLE',
      'startRow': 1,
      'endRow':  (endRow ? endRow : ( this.initialTotalCount > 30 ? 30 : this.initialTotalCount )),
      'subFilterCriteria': {},
      'filterCriteria': {},
      'customFilterId': '0',
      'isGenericSearch': true
    };
    this.filteredColumns = [];
    if (sort) {
      this.isSorted = true;
      const tempSortArray = [...this.sortArray.filter( column => {
        if (column.order != 'none') {
          const section = this.sectionDetails.find(section => section.columnLabel == column.name);
          if (section && this.displayedColumns.includes(section.columnName)) {
            return true;
          }
          return false;
        } else {
          return false;
        }
      })];
      if (tempSortArray.length == 0) {
        this.isSorted = false;
      } else {
        let sortColumnId = '';
        tempSortArray.forEach((sortItem, index) => {
          if (index != 0) {
            sortColumnId += '#^#';
          }
          sortColumnId += sortItem.id + ',' + sortItem.order.toUpperCase();
        });
        attr['sortColumnId'] =  sortColumnId;
        attr['sortDirection'] = tempSortArray[0].order.toUpperCase();
      }
    }
    if (filter) {
      this.filteredColumns = [];
      this.isFiltered = true;
      let hasSubFilter = false;
      let hasDate = false;
      let isEmpty = true;
      for (const item in this.filterObject) {
        if (this.filterObject[item].dbColumnName == 'DUE_DATE') {
          if ((this.filterObject[item].from && this.filterObject[item].from != '') || (this.filterObject[item].to && this.filterObject[item].to != '')) {
            hasDate = true;
          }
        } else {
          if (this.filterObject[item].value && this.filterObject[item].value != '' && this.filterObject[item].value != 'None') {
            isEmpty = false;
            attr['subFilterCriteria'][this.filterObject[item].sectionAttrId] = this.filterObject[item].value;
            statsAttr['subFilterCriteria'][this.filterObject[item].dbColumnName] = this.filterObject[item].value;
            hasSubFilter = true;
            this.filteredColumns.push(item);
          }
        }
      }
      this.isFiltered = !isEmpty || hasDate;
      if (hasDate) {
        attr['filterCriteria'][this.filterObject['Due Date'].sectionAttrId] = this.getDateValue(this.filterObject['Due Date'].from ? this.filterObject['Due Date'].from.toString() : '') + `,`  + this.getDateValue(this.filterObject['Due Date'].to ? this.filterObject['Due Date'].to.toString() : '');
        this.filteredColumns.push('Due Date');
        statsAttr['filterCriteria'][this.filterObject['Due Date'].dbColumnName] = this.getDateValue(this.filterObject['Due Date'].from ? this.filterObject['Due Date'].from.toString() : '') + `,`  + this.getDateValue(this.filterObject['Due Date'].to ? this.filterObject['Due Date'].to.toString() : '');
      }
    }
    if (!this.isSorted) {
      attr['sortColumnId'] = this.dueDateId;
      attr['sortDirection'] = 'DESC';
    }
    return {
      'diaryAttr': attr,
      'statsAttr': statsAttr
    };
  }
  apply(option?, endRow?, loadSettings?) {
    const requestAttrs = this.generateRequestAttr(option == 'sort' || this.isSorted, option == 'filter' || this.isFiltered, endRow);
    this.clientService.setUrl(environment.searchUrl);
    this.showProgressBar = true;
    this.clientService.getDiaryTableData(requestAttrs.diaryAttr).subscribe(response => {
      this.dataSource = new MatTableDataSource(response.json().data);
      this.recordCount = response.json().recordCount;
      if (!this.DIARY_DATA) {        
        this.DIARY_DATA = response.json();
        this.DIARY_DATA_UNTOUCHED = { ...this.DIARY_DATA };
      }
      if (!this.initialTotalCount || (this.initialTotalCount && this.recordCount > this.initialTotalCount)) {
        this.initialTotalCount = this.recordCount;
      }
      this.count = this.recordCount <= this.count ? this.recordCount : 30;
      if (requestAttrs.statsAttr != null) {
        this.getStatistics(requestAttrs.statsAttr);
      } else {
        this.getStatistics();
      }
      if (endRow) {
        this.count = endRow < this.recordCount ? endRow : this.recordCount;
      }
    });
    if (!loadSettings) {
      if (this.isSorted || this.isFiltered) {
        this.currentSetting = '';
      } else {
        this.currentSetting = 'default';
        this.setAsDefaultSetting();
      }
    }
  }
  applySettings(userSettings) {
    this.isSorted = false;
    this.isFiltered = false;
    this.buildSort();
    for (const column in this.filterObject) {
      if (column == 'Due Date') {
        this.filterObject[column].from = '';
        this.filterObject[column].to = '';
      }
      this.filterObject[column].value = '';
    }

    const sortOrder = [];
    userSettings.forEach(setting => {
      if (setting.sorting) {
        const temp = this.sortArray.find(column => column.name == setting.attributeLabel);
        if (temp && setting.sortingOrder.sortingAsc || setting.sortingOrder.sortingDesc) {
          sortOrder.push(setting.attributeLabel);
          this.isSorted = true;
          if (setting.sortingOrder.sortingAsc) {
            temp.order = 'asc';
          } else {
            temp.order = 'desc';
          }
        }
      }
      if (setting.filter) {
        if (setting.dbColumnName != 'DUE_DATE' && setting.filterValue) {
          this.filterObject[setting.attributeLabel].value = setting.filterValue;
          this.isFiltered = true;
        }
      }
      if (setting.dbColumnName == 'DUE_DATE' && setting.filterValue) {
        const dates = setting.filterValue.split(',');
        if (dates[0].length > 0) {
          this.filterObject[setting.attributeLabel].from = this.commonTransformerService.dateToObjectFormatChange(dates[0]);
        }
        if (dates[1].length > 0) {
          this.filterObject[setting.attributeLabel].to = this.commonTransformerService.dateToObjectFormatChange(dates[1]);
        }
        this.isFiltered = true;
      }
    });
    const sorted = []
    const unsorted = [];
    sortOrder.forEach(item => {
      const found = this.sortArray.find(column => item == column.name);
      if (found) {
        sorted.push(found);
      }
    });
    this.sectionDetails.forEach(section => {
      const foundSort = this.sortArray.find(item => item.id == section.sectionAttrId);
      if (foundSort) {
        if (!sortOrder.includes(foundSort.name)) {
          unsorted.push(foundSort);
        }
      }
    });
    this.sortArray = [...sorted, ...unsorted];
    this.apply(null, 30, true);
  }
  
  public getDateValue(date: string) {
    if (date && date.length > 0) {
      return this.commonTransformerService.dateInServiceFormat(date);
    } else {
      return '';
    }
  }

  public onConfigureColumns(event: any, loadSetting?) {
    this.displayedColumns = [...event.columns];
    this.getMandatoryFilters();
    this.buildSort();
    this.configColumnName.forEach(column  => {
      column.mandatory = false;
    });
    const temp = [];
    this.displayedColumns.forEach(column => {
      const found = this.configColumnName.find(header => header.columnName == column);
      if (found) {
        found.mandatory = true;
        temp.push(found);
      }
    });
    if (loadSetting) {
      this.configColumnName.forEach(header => {
        if (header.mandatory == false) {
          temp.push(header);
        }
      });
      this.configColumnName = [...temp];
    }
  }

  public closeSideNav(event: any) {
    if (event == 'sideNavClose') {
      this.actionColumnSticky = false;
    }
    }

 public actionColumn(event: any) {
if (event == 'actionColumnSticky') {
  this.actionColumnSticky = true;
} else if (event == 'actionColumnNonSticky') {
  this.actionColumnSticky = false;
}
 }

  // calls the service fucntion to fetch the latest comment associated to a particular diary
  public showComment(event, diaryId) {
    event.stopPropagation();
    this.lastComment = '';
    this.commentClicked = true;
    this.commentLoaded = false;
    this.clientService.setUrl(environment.taskServiceUrl + diaryId + '/comments/latest');
    this.clientService.getClientData().subscribe(response => {
      this.lastComment = response.comments[0].comment;
      this.commentLoaded = true;
    });
    return true;
  }
  displayCalendar() {
    this.showCalendar = true;
  }
  displayDashboard(data) {
    this.showCalendar = data;
  }
}
