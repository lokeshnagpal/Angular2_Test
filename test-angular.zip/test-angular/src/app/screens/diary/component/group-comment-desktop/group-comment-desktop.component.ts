import { Component, OnInit } from '@angular/core';
import { CommonTransformerService } from 'src/app/util/common-transformer.service';
import { Input } from '@angular/core';

@Component({
  selector: 'app-group-comment-desktop',
  templateUrl: './group-comment-desktop.component.html',
  styleUrls: ['./group-comment-desktop.component.scss']
})
export class GroupCommentDesktopComponent implements OnInit {


  public isExpand:boolean = false;
  
    @Input () taskComments;
    
    constructor(private commonTransformerService: CommonTransformerService) { 
       
    }
  
    ngOnInit() {
  
      
    }

}
