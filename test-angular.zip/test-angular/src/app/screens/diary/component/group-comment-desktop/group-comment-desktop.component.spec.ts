import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GroupCommentDesktopComponent } from './group-comment-desktop.component';

describe('GroupCommentDesktopComponent', () => {
  let component: GroupCommentDesktopComponent;
  let fixture: ComponentFixture<GroupCommentDesktopComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GroupCommentDesktopComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GroupCommentDesktopComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
