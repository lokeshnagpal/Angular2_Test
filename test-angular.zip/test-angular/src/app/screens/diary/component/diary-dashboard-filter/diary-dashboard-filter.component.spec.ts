import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DiaryDashboardFilterComponent } from './diary-dashboard-filter.component';

describe('DiaryDashboardFilterComponent', () => {
  let component: DiaryDashboardFilterComponent;
  let fixture: ComponentFixture<DiaryDashboardFilterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DiaryDashboardFilterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DiaryDashboardFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
