import { Component, OnInit, Input, Output, EventEmitter, SimpleChanges } from '@angular/core';
import { ClientService } from 'src/app/services/client.service';
import { environment } from 'src/environments/environment';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';

@Component({
  selector: 'app-diary-dashboard-filter',
  templateUrl: './diary-dashboard-filter.component.html',
  styleUrls: ['./diary-dashboard-filter.component.scss']
})
export class DiaryDashboardFilterComponent implements OnInit {

  @Input() option;
  @Input() recordCount;
  @Input() initialTotalCount;
  @Input() sortArray;
  @Input() filterObjectInput;
  @Input() filteredColumnsInput;
  @Output() sortEvent = new EventEmitter();
  @Output() filterEvent = new EventEmitter();

  public indicators: any[] = [];
  public INDICATORS: any[] = [];
  public isFilterDataLoaded = false;
  public filterUrl: string = '';
  public filterAttr: any;
  public filterObject: any = {};
  public filtersArray: string[] = [];
  public filteredColumns: string[] = [];

  constructor(public clientService: ClientService) { }

  ngOnInit() {
    this.buildIndicatorArray();
    this.filterUrl = environment.getFilterValuesUrl;
    this.filterAttr = {
      'sectionId': 150,
      'startRow': 1,
      'endRow': 30,
      'alias': 'HEADERCOLUMNS',
      'group': '',
      'query': '',
      'filterCriteria' : {},
      'filterType': 'suggest',
      "customFilterId": "0"
    };
    this.filteredColumns = [ ...this.filteredColumnsInput ];
    this.filterObject = { ...this.filterObjectInput };
  }
  ngOnChanges(changes: SimpleChanges) {
    if (changes.filteredColumnsInput) {
      this.filteredColumns = [ ...this.filteredColumnsInput ];
      if (this.filteredColumns.length > 0 && !this.filteredColumns.includes('Indicators') && this.INDICATORS.length > 0) {
        this.indicators = [ ...this.INDICATORS ];
      }
    }
    if (changes.filterObjectInput) {
      this.filterObject = { ...this.filterObjectInput };
    }
  }
  buildIndicatorArray() {
    const indicatorArray = [
      {name: 'Confidential', dbName: 'CONFIDENTIALITY'},
      {name: 'IPA', dbName: 'PROGRAM_NUMBER'},
      {name: 'ITC', dbName: 'ITC'},
      {name: 'Payment Order', dbName: 'PAYMENT_ORDER'},
      {name: 'Primary', dbName: 'MARKET_POSITION'},
      {name: 'Pulse', dbName: 'CLIENT_PORTAL_IND'}
    ];
    indicatorArray.forEach( indicator => {
      this.INDICATORS.push({
        name: indicator.name,
        dbName: indicator.dbName,
        selected: false
      });
    });
    this.indicators = [ ...this.INDICATORS ];
  }
  apply(option) {
    if (option == 'sort') {
     this.sortEvent.emit(this.sortArray);
    } else if (option == 'filter') {
      this.filterEvent.emit(this.filterObject);
    }
  }
  selectIndicator(indicator) {
    let selected = '';
    this.indicators.forEach(item => {
      if (item.dbName === indicator.dbName) {
        item.selected = !item.selected;
        if (item.selected) {
          selected = item.dbName;
        }
      } else {
        item.selected = false;
      }
    });
    this.filterObject['Indicators'].value = selected;
    this.applyFilter(selected, 'Indicators');
    this.apply('filter');
  }
  removeFilter(filter) {
    if (filter == 'Indicators') {
      this.indicators.forEach( indicator => {
        indicator.selected = false;
      });
    }
    this.filterObject[filter].value = '';
    if (filter == 'Due Date') {
      this.filterObject[filter].from = '';
      this.filterObject[filter].to = '';
    }
    this.filteredColumns = this.filteredColumns.filter(column => column != filter);
    this.apply('filter');
  }
  loadFilterAttributes() {
    if (!this.isFilterDataLoaded) {
      this.isFilterDataLoaded = true;
      this.buildFiltersArray();
    }
    return true;
  }
  buildFilterAttr(filterObject) {
    const attr = { ...this.filterAttr };
    attr.group = filterObject.sectionAttrId + '#~#' + filterObject.dbColumnName + '#~#' + filterObject.columnType;
    return attr;
  }
  buildFiltersArray() {
    this.filtersArray = [];
    for (const filter in this.filterObject) {
      if (this.filterObject[filter].show == true || this.filterObject[filter].show == 'true') {
        if (this.filterObject[filter].columnType == 'TEXTCOLUMN' || this.filterObject[filter].columnType == 'CLICKABLECOLUMN') {
          if (!(this.filterObject[filter].dbColumnName == 'DUE_DATE' || this.filterObject[filter].dbColumnName == 'CATEGORY_DIARY' || this.filterObject[filter].dbColumnName == 'CLAIM_INDICATORS')) {
            this.filtersArray.push(filter);
          }
        }
      }
    }
  }
  selectOption(filter, value) {
    this.filterObject[filter].value = value;
    this.apply('filter');
  }
  dropSortOrder(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.sortArray, event.previousIndex, event.currentIndex);
  }
  applyFilter(event, filter) {
    this.filterObject[filter].value = event.name ? event.name : event;
    if ((!event || !event.name || event.name == '') && filter != 'Due Date') {
      this.filteredColumns = this.filteredColumns.filter(column => column != filter);
    } else {
      if (!this.filteredColumns.includes(filter)) {
        this.filteredColumns.push(filter);
      }
    }
    this.apply(this.option);
  }
}
