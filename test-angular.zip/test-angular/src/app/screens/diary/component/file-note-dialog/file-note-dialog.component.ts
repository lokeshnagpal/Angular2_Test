import { DiaryService } from 'src/app/screens/diary/diary.service';
import { environment } from './../../../../../environments/environment';
import { ClientService } from './../../../../services/client.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA } from '@angular/material';
import { Component, OnInit, Inject, ChangeDetectorRef } from '@angular/core';


@Component({
    selector: 'file-note-dialog',
    templateUrl: './file-note-dialog.component.html',
    styleUrls: ['./file-note-dialog.component.scss'],
})

export class FileNoteDialog implements OnInit {

    public attributes: any;
    public lookupUrl: any;
    public optionValue: any;
    public attributeHolder: any = [];
    public lookupVal = [];
    public fileNoteForm: FormGroup;
    public category: any;
    public display: any;

    constructor(@Inject(MAT_DIALOG_DATA) public data: any, public fb: FormBuilder, private clientService: ClientService, 
    private ref: ChangeDetectorRef, private service: DiaryService){
        this.lookupUrl = environment.lookupUrl;
    }

ngOnInit(){
    this.attributes = this.data.attributeData;
    this.fileNoteForm = this.createForm(this.attributes);
    for (const index in this.attributes) {
        this.getLookupData(this.attributes[index], this.attributes[index].dbColumnName);
    }
    this.attributeHolder = [];
    this.service.setFileNoteAttrValue(this.attributeHolder);
}

// public logParamteres() {
//     console.log('Category', this.category);
//     console.log('Display In', this.display);
//     this.setAttributes();
// }

public createForm(obj) {
    const group = this.fb.group({});
    obj.forEach(control => group.addControl(control.dbColumnName, this.createControl(control)));
    return group;
}

public createControl(config) {
    const { isDisabled } = config;
    let value;
    let validation;
    const item = config;
    if (config.mandatory) {
        validation = Validators.required;
    }
    const control = this.fb.control({ 'value': value, 'disabled': isDisabled }, validation);
    // control.valueChanges.subscribe(res => {
    //     this.formControlChange(control, config);
    // });
    return control;
}

public addAttribute(attribute, option) {
    const referenceObj: any = {
        code: option.id,
        refDataId: option.refDataId,
        name: option.name
    };
    const diaryObj = {
        attrId: attribute.attrId,
        referenceDataValue: referenceObj,
        dbColumnName: attribute.dbColumnName,
        type: attribute.type,
        value: option.name
    };
    this.attributeHolder.push(diaryObj);
    this.service.setFileNoteAttrValue(this.attributeHolder);
}

public setAttributes() {
    if (this.category) {
        this.addAttribute(this.attributes[0], this.category);
    }
    // if (this.display.everywhere == false) {
    //     for (const option of this.display.options) {
    //         if(option && option['checked'] == true) {
    //             this.addAttribute(this.attributes[0], option['option']);
    //         }
    //     }
    // }
}

public getLookupData(data, controlName) {
    this.lookupVal = [];
    let urlForLookup = this.lookupUrl + '/' + data.source + '/' + data.group + '/';
    
    if (data.referenceDataValue && data.referenceDataValue.id && data.value == data.referenceDataValue.name){
        urlForLookup = urlForLookup + data.referenceDataValue.id;
    }
    this.clientService.setUrl(urlForLookup);
    this.clientService.getClientData().subscribe(response => {
        data.attributeOptions = response;
        if (data.name == 'Category') {
            this.buildDisplay();
        }
    });
}

public buildDisplay() {
    const options = [];
    for (const option of this.attributes[0].attributeOptions) {
        options.push({
            option,
            checked: false
        });
    }
    this.display = { options , everywhere: false };
}

public toggleAll(value, options) {
    for (const option of options) {
        option.checked = value;
    }
    this.setAttributes();
}

//     // method triggered when change in form control
//     public formControlChange(ctrl, attr){
//         if (attr.type == 'LOOKUP'){
//             this.getFilteredLookup(ctrl, attr);
//             this.addLookupData();
//         }
//     }
// //method to assign the selected value ij aatributes
//     public addLookupData(){
//         this.attributeHolder = [];
//         for (const attribute of this.attributes) {
//                 if (attribute.type == 'LOOKUP') {
//                     const referenceObj: any = {
//                         refDataId: '',
//                         name: '',
//                         code: ''
//                     };
//                    const lookupVal = this.fileNoteForm.controls[attribute.dbColumnName].value;
//                     if (lookupVal && lookupVal != '') {
//                             const itemFound = attribute.attributeOptions.find(val => val.name == lookupVal);
//                             if (itemFound) {
//                             referenceObj['code'] = itemFound.id ;
//                             referenceObj['refDataId'] = itemFound.refDataId ;
//                             referenceObj['name'] = itemFound.name ;
//                         }
//                         else{
//                             if (attribute.referenceDataValue && attribute.referenceDataValue.name == lookupVal){
//                                 referenceObj['code'] = attribute.referenceDataValue.id ;
//                                 referenceObj['refDataId'] = attribute.referenceDataValue.refDataId ;
//                                 referenceObj['name'] = attribute.referenceDataValue.name ;
//                             }
//                         }
//                     }
//                     const diaryObj = {
//                         attrId: attribute.attrId,
//                         referenceDataValue: referenceObj,
//                         dbColumnName: attribute.dbColumnName,
//                         type: attribute.type,
//                         value: lookupVal
//                     };
//                     this.attributeHolder.push(diaryObj);
//                 }
//         }
//         this.service.setFileNoteAttrValue(this.attributeHolder);
//     }

//     //method triggered when lookup input change
//     public getFilteredLookup(ctrl, attr){
//         const this = this;
//         this.optionValue = ctrl.value;
//         let urlForLookup = this.lookupUrl + '/' + attr.source + '/' + attr.group + '/'; 
//         if (attr.referenceDataValue && attr.referenceDataValue.id && ctrl.value == attr.referenceDataValue.name){
//             urlForLookup = urlForLookup + attr.referenceDataValue.id;
//         }else{
//             delete attr['referenceDataValue'];
//             urlForLookup = urlForLookup +  ctrl.value;
//         }
//         this.clientService.setUrl(urlForLookup);
//         this.clientService.getClientData().subscribe(response => {
//                attr.attributeOptions = response;
//         }); 
//         console.log("attributes", this.attributes);
//     }

//     public checkLookupSelectedValue(lokupAttr, ctrl, lookupData){
//             if (lookupData.attributeOptions && lookupData.attributeOptions.length >= 0){
//                 const selLookupval = lookupData.attributeOptions.find(x => x.name == ctrl.value);
//                 if (!selLookupval && !lookupData.referenceDataValue){
//                     ctrl.setValue('');
//                 }             
//          }
//     }

//     public lookupOptionSelected(valSelected, config){
//         this.fileNoteForm.controls[config.dbColumnName].setValue(valSelected.option.value);
//         config['referenceDataValue'] = config.attributeOptions.find(x => x.name == valSelected.option.value);
//     }
}