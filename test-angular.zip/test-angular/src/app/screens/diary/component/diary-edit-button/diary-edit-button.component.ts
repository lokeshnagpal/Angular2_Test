import { DiaryDialog } from './../diary-dialog/diary-dialog.component';
import { ClientService } from './../../../../services/client.service';
import { environment } from './../../../../../environments/environment';
import { DiaryService } from './../../diary.service';
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatSnackBar } from '@angular/material';

@Component({
  selector: 'diary-edit-button',
  templateUrl: './diary-edit-button.component.html',
  styleUrls: ['./diary-edit-button.component.scss']
})
export class DiaryEditButtonComponent implements OnInit {

  @Output() doEditDiary: EventEmitter<any> = new EventEmitter();
  @Output() doCloseDiary: EventEmitter<any> = new EventEmitter();

  constructor(private service: DiaryService, public dialog: MatDialog, private clientService: ClientService,
    public snackBar: MatSnackBar) {
  }

  ngOnInit() {
  }

  public editDiary() {
    this.doEditDiary.emit(this.service.getTaskNumber());
  }

  public closeDiary() {
    this.doCloseDiary.emit(this.service.getTaskNumber());
  }
}
