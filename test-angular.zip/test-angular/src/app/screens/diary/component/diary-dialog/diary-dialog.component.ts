import { ApplicationStateService } from 'src/app/util/application.state.service';
import { Constants } from './../../../../util/application.constants';
import { DiaryService } from './../../diary.service';
import { ClientService } from './../../../../services/client.service';
import { environment } from './../../../../../environments/environment';
import { Component, Input, Output, OnInit, Inject, EventEmitter,ChangeDetectorRef,ViewChild,ElementRef} from '@angular/core'
import { MAT_DIALOG_DATA, MatDialogRef, MatSnackBar,MatAutocompleteTrigger } from '@angular/material';
import { map, startWith } from 'rxjs/operators';
import { FormControl, FormGroup, FormBuilder, Validators ,ValidatorFn} from '@angular/forms';
import { CommonTransformerService } from 'src/app/util/common-transformer.service';

@Component({
    selector: 'diary-dialog',
    templateUrl: './diary-dialog.component.html',
    styleUrls: ['./diary-dialog.component.scss'],
})

export class DiaryDialog implements OnInit {

    public diaryDialogForm: FormGroup;
    public diaryDialogAttributes: any;
    public lookupUrl: any;
    public saveTakDetailUrl:any;
    public emailNotify: boolean = false;
    public lookupVal = [];
    public attributeHolder: any = [];
    private referenceDataValue=[];
    public headerName:any;
    public buttonName:any;
    public minDate=new Date();
    public maxDate:any;
    public optionValue:any;
    public comments:any=[];
    public diaryReqObject:any;
    public enableForm:boolean=true;
    public lookupSelectedValue:any;

    @ViewChild('autoCompleteBlur', {static: false}) autoCompleteBlur: ElementRef;

    constructor( @Inject(MAT_DIALOG_DATA) public data: any, public fb: FormBuilder, private clientService: ClientService, private ref: ChangeDetectorRef,
    private service: DiaryService,public snackBar: MatSnackBar,@Inject(MatDialogRef) public dialogRef: MatDialogRef<DiaryDialog>,
    private commonTransformerService: CommonTransformerService,public applicationStateService: ApplicationStateService) {
        this.lookupUrl = environment.lookupUrl;
        this.saveTakDetailUrl=environment.taskServiceUrl;
    }

    ngOnInit() {
        this.maxDate = new Date(this.minDate);
        this.maxDate.setDate(this.minDate.getDate()+365);
        this.diaryDialogAttributes = this.data.attributes;
        this.showAttributes();
        this.headerName=this.data.headerName;
        this.buttonName=this.data.buttonName;
        this.diaryDialogForm = this.createForm(this.diaryDialogAttributes);
    }


    public createForm(obj) {
        const group = this.fb.group({});
        obj.forEach(control => group.addControl(control.dbColumnName, this.createControl(control)));
        return group;
    }

    public createControl(config) {
        const { isDisabled } = config;
        let value;
        let validation;
        let item = config;
        if (config.mandatory) {
            validation = Validators.required;
        }
        if(item.type=='DATEBOX' && item.dbColumnName==config.dbColumnName && item.dbdateValue){
            let dateValue = this.commonTransformerService.getDatepickerFormat(item.dbdateValue);
           value= new Date(dateValue);
         }
        else if(item.type=='LOOKUP' && item.dbColumnName==config.dbColumnName && item.referenceDataValue){
            if(item.dbColumnName=="ASSIGNEE"){
                value = item.referenceDataValue.id+" "+"-"+" "+item.referenceDataValue.name;
            } else {
                value = item.referenceDataValue.name;
            }
         } else if(item.type=='LOOKUP' && item.dbColumnName==config.dbColumnName && !item.referenceDataValue) {
             value = item.value;
         }
        let control = this.fb.control({ 'value': value, 'disabled': isDisabled }, validation);
        control.valueChanges.subscribe(res => {
            this.diaryFormControlChange(control, config);
        })

        return control;
    }

    //open the clicked lookup and hide the other
    public openSelectedLookup(controlName){
        if(this.enableForm && this.applicationStateService.getDeviceName()=="Mobile"){
            for(let item of this.diaryDialogAttributes){
                if(item.dbColumnName==controlName){
                    item["visible"]=true;
                }
                else{
                    item["visible"]=false;
                }
            }
        }
    }

    public getLookupData(data, controlName) {
        this.enableForm=true;
        this.lookupVal = [];
        let urlForLookup = this.lookupUrl + '/' + data.source + '/' + data.group + '/';
        if(data.referenceDataValue && data.referenceDataValue.id && data.value == data.referenceDataValue.name){
            urlForLookup = urlForLookup+ data.referenceDataValue.id;
        }
        this.clientService.setUrl(urlForLookup);
        this.clientService.getClientData().subscribe(response => {
            this.addAttrId(data,response);
        })       
    }

    // method triggered when change in form control
    public diaryFormControlChange(ctrl, attr){
        if(attr.type == 'LOOKUP'){
            this.getFilteredLookup(ctrl,attr);
        }
    }

    public getUrlForLookup(columnName) {
        let attr;
        this.diaryDialogAttributes.forEach(attribute => {
            if (attribute.dbColumnName==columnName) {
               attr = attribute;
            }
        });
        if (attr) {
            const urlForLookup = this.lookupUrl + '/' + attr.source + '/' + attr.group + '/' ;
            return urlForLookup;
        }
        return null;
    }

    //method triggered when lookup input change
    public getFilteredLookup(ctrl,attr){
        this.optionValue=ctrl.value;
        let urlForLookup = this.lookupUrl + '/' + attr.source + '/' + attr.group + '/' 
        if(attr.referenceDataValue && attr.referenceDataValue.id && ctrl.value == attr.referenceDataValue.name){
            urlForLookup = urlForLookup+ attr.referenceDataValue.id;
        }else{
            delete attr['referenceDataValue']
            urlForLookup = urlForLookup+  ctrl.value;
        }
        this.clientService.setUrl(urlForLookup);
        this.clientService.getClientData().subscribe(response => {
            this.addAttrId(attr,response);
        }) 
    }

    public setControlValue(event, columnName) {
        this.diaryDialogForm.controls[columnName].setValue(event.name);
        const dialogAttribute = this.diaryDialogAttributes.find(attribute => attribute.dbColumnName == columnName);
        if (dialogAttribute) {
            dialogAttribute.referenceDataValue = {
                'name': event.name
            };
        }
    }

    public checkLookupSelectedValue(lookupColName,ctrl,lookupData){
        let selLookupval;
        if(ctrl.value && !this.lookupSelectedValue){
            if(lookupData.attributeOptions && lookupData.attributeOptions.length>=0){      
                    let selLookupval=lookupData.attributeOptions.find(x=>x.name==ctrl.value);
                    if( !lookupData.referenceDataValue){
                            if(lookupData.attributeOptions.length==0){
                                ctrl.setValue('');
                            }
                    }   
                }
         }
         else if(this.lookupSelectedValue){
            if(lookupData.attributeOptions && lookupData.attributeOptions.length>=0){      
                let selLookupval=lookupData.attributeOptions.find(x=>x.name==this.lookupSelectedValue);
                if(!selLookupval && !lookupData.referenceDataValue){
                    ctrl.setValue('');
                }   
            }
         }
         this.lookupSelectedValue='';
    }

    public lookupOptionSelected(valSelected,config){
        this.enableForm=false;
        this.diaryDialogForm.controls[config.dbColumnName].setValue(valSelected.option.value);
        this.lookupSelectedValue=valSelected.option.value;
        if(config.dbColumnName=="ASSIGNEE"){
            config['referenceDataValue'] = config.attributeOptions.find(x => x.displayNameId == valSelected.option.value);
        }
        else{
            config['referenceDataValue'] = config.attributeOptions.find(x => x.name == valSelected.option.value);
        }
        if(this.applicationStateService.getDeviceName()=="Mobile")
        {
            this.showAttributes();
            this.autoCompleteBlur.nativeElement.blur();
        }         
    }

    public closeDiary(){
        this.dialogRef.close();
    }

    //show attributes when option selected in mobile view
    public showAttributes(){
          for(let item of this.diaryDialogAttributes){
            item["visible"]=true;
}
    }

    //append id with name for assignee lookup
    public addAttrId(attr,response){
        if(attr.dbColumnName=="ASSIGNEE"){
            attr.attributeOptions = response;
            for(let item of  attr.attributeOptions){
                item["displayNameId"]=item.id+" "+"-"+" "+item.name;
            }
        }
        else{
            attr.attributeOptions = response;
        }  
    }

    public createDiary() {
        this.attributeHolder = [];
        let ctrlInvalidList: any = [];
        let lookupVal:any;
        this.comments=[];
        let taskNumber = this.data.taskNumber;
        let tabId=this.data.tabId;
        let tabName=this.data.tabName;
        let claimNumber=this.data.claimNumber;
        for(let ctrl in this.diaryDialogForm.controls){
            this.diaryDialogForm.controls[ctrl].markAsTouched();
           if (this.diaryDialogForm.controls[ctrl].invalid) {
            let config = this.diaryDialogAttributes.find(x => x.dbColumnName == ctrl);
                if (config && !config.readOnly) {
                    ctrlInvalidList.push(this.diaryDialogForm.controls[ctrl]);
                }
            }
        }
        for (let attributes of this.diaryDialogAttributes) {
            if (attributes.readOnly == false) {
                if (attributes.type == "LOOKUP") {
                    let referenceObj: any = {
                        refDataId: '',
                        name: '',
                        code:''
                    }
                    if(attributes.dbColumnName=="ASSIGNEE"){
                      let value=this.diaryDialogForm.controls[attributes.dbColumnName].value;
                      if(value){
                       let  index=value.indexOf('-');
                        lookupVal=value.slice(index+2,value.length);
                      }                                   
                    }
                    else{
                        lookupVal = this.diaryDialogForm.controls[attributes.dbColumnName].value;
                    }
                   if (lookupVal && lookupVal != '') {
                            let itemFound = attributes.attributeOptions.find(val =>val.name == lookupVal);
                            if (itemFound) {
                            referenceObj["code"] = itemFound.id ;
                            referenceObj["refDataId"] = itemFound.refDataId ;
                            referenceObj["name"] = itemFound.name ;
                        }
                        else{
                            if(attributes.referenceDataValue && attributes.referenceDataValue.name==lookupVal){
                                referenceObj["code"] = attributes.referenceDataValue.id ;
                                referenceObj["refDataId"] = attributes.referenceDataValue.refDataId ;
                                referenceObj["name"] = attributes.referenceDataValue.name ;
                            }
                        }
                    }
                    let diaryObj = {
                        attrId: attributes.attrId,
                        referenceDataValue: referenceObj,
                        dbColumnName: attributes.dbColumnName,
                        type: attributes.type,
                        value: lookupVal,
                        sectionCode: attributes.sectionCode
                    }
                    this.attributeHolder.push(diaryObj);
                }
                else if (attributes.type == "DATEBOX") {
                    let convertedDate;
                    let val = this.diaryDialogForm.controls[attributes.dbColumnName].value;
                    if (val) {
                        convertedDate = this.commonTransformerService.dateInServiceFormat(val);
                    }
                    let diaryObj = {
                        attrId: attributes.attrId,
                        dbColumnName: attributes.dbColumnName,
                        type: attributes.type,
                        dateValue: convertedDate,
                        sectionCode: attributes.sectionCode
                    }
                    this.attributeHolder.push(diaryObj);
                }

            }

        }
        if (ctrlInvalidList.length <= 0) {
        let tabObj={
            'code':tabId,
            'name':tabName
        }
        if(taskNumber){
            this.diaryReqObject= {
                'taskNumber': taskNumber,
                'claimNumber':claimNumber,
                'attributes': this.attributeHolder,
                'type':tabObj
            }
        }
        else{
            let defaultComment={
                "comment":Constants.DIARY_DEFAULT_COMMENT
            }
            this.comments.push(defaultComment);
            this.diaryReqObject= {
                'taskNumber': taskNumber,
                'claimNumber':claimNumber,
                'attributes': this.attributeHolder,
                "comments":this.comments,
                'type':tabObj
            }
        }
        this.clientService.setUrl(this.saveTakDetailUrl);
        this.clientService.postClientData(this.diaryReqObject).subscribe(response => {
            if(taskNumber){
                this.showMessage("Diary Date Saved Successfully", 3000);
            }
        else {
            this.showMessage("Diary Date Created Successfully", 3000);
        }
          this.dialogRef.close("Diary Created");
        }, err => {
            this.dialogRef.close();
            this.showError(err, 3000) ;
        });
    }
    }

    public  showMessage(errorMessage: string, durationValue: number) {
        this.commonTransformerService.showMessage(errorMessage, durationValue);
    }

    public  showError(error, durationValue: number) {
        this.commonTransformerService.showError(error, durationValue);
    }
}
