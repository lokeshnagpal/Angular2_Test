import { Constants } from './../../../../util/application.constants';
import { Subscription, Subject } from 'rxjs';
import { environment } from './../../../../../environments/environment';
import { MatDialog, MatSnackBar } from '@angular/material';
import { ClientService } from './../../../../services/client.service';
import { ActivatedRoute } from '@angular/router';
import { DiaryService } from './../../diary.service';
import { DiaryFileNoteListComponent } from './../diary-file-note-list/diary-file-note-list.component';
import { Component, OnInit, Input, Output, EventEmitter, ChangeDetectorRef } from '@angular/core';
import { ApplicationStateService } from 'src/app/util/application.state.service';
import { DiaryComponent } from './../diary/diary.component';
import { CommonTransformerService } from 'src/app/util/common-transformer.service';
import { debounceTime } from 'rxjs/operators';

@Component({
  selector: 'app-file-note-mobile',
  templateUrl: './file-note-mobile.component.html',
  styleUrls: ['./file-note-mobile.component.scss']
})
export class FileNoteMobileComponent extends DiaryComponent implements OnInit {

  @Input() selTabIndex;
  @Input() tabData
  @Input() postComments;
  @Input() claimNumber;
  @Input() newComment;
  @Input() fileNoteType;
  // @Output() updatepostCommEvent:EventEmitter<any>=new EventEmitter();

  public taskComments;
  public loadTaskComments:any;
  public showFooterAction:boolean=false;
  public fileNoteObservable:Subscription;
  public footerCommentsName=Constants.FILE_NOTES_FOOTER_COMM;  
  public fileNoteSectionCode = Constants.FILE_NOTE_SECTION_CODE;
  public editComment: any;
  public showEdit = false;
  public description: any;
  public category: any;
  public display: any;
  public taskId: any;
  public status: any;
  public comments = [];
  public showAddNote=false;
  public taskUrl:String;
  public height:number;
  private subject: Subject<string> = new Subject();
  
  constructor(public service: DiaryService, public route: ActivatedRoute, public clientService: ClientService, public dialog: MatDialog,
    public ref: ChangeDetectorRef, public snackBar: MatSnackBar, public applicationStateService: ApplicationStateService, public commonTransformerService: CommonTransformerService) {
      super(service, route, clientService, dialog, ref, snackBar, commonTransformerService);
       this.loadTaskDetails=environment.loadTaskDetails;
       this.taskUrl=environment.taskServiceUrl;
       this.fileNoteObservable= this.service.getFileNoteComment().subscribe(res=>{
        this.getFileNotesData(res);        
      });
    }
  
    ngOnInit() {
      this.subject.pipe(debounceTime(50)).subscribe(() => {
        console.log('scrolled');
      });
    }
    onScroll() {
      this.subject.next();
    }

    ngOnChanges(){

      if (this.newComment) {
        if (this.newComment.taskId) {
          this.taskComments = this.taskComments.filter(taskComment => taskComment.taskId != this.newComment.taskId);
        }
        this.taskComments = [this.newComment.taskComment, ...this.taskComments];
      }
      if(this.fileNoteType == 'drafts') {
        this.status = "D";
      } else {
        this.status = "S"
      }

      if(this.selTabIndex == 1 && this.tabData){
        this.getFileNotesData(this.tabData)
      }
    }

   public  getFileNotesData(event){
          let tabObj={
          'code':event.tabId,
          'name':event.tabName
      }
          let requestObject:any={
            "claimNumber":this.claimNumber,
            "type":tabObj,
            "status": this.status
          }
        this.clientService.setUrl(this.loadTaskDetails);
        this.clientService.setCardReqDetails(this.clientService.getCardReqDetails().cardName);
        this.clientService.postClientData(requestObject).subscribe(response => {
       this.taskComments=response;
       for(let item of this.taskComments){
        let fileNoteComm=item.comments[0].comment;
        if(fileNoteComm){
          let showInitialComm=fileNoteComm.substring(0,480);
          item.comments[0].addComment=showInitialComm;
          item.comments[0].isDisabled=true;
        }
        else{
          item.comments[0].addComment='';
        }
      }
      });  
}

  // public postCommEvent(event){
  //   this.updatepostCommEvent.emit(event);
  //  }

   public expandComment(commList){
    commList.addComment=commList.comment;
    commList.isDisabled=false;
   }

   public showLessComment(comm){
     comm.addComment=comm.comment.substring(0,480);
     comm.isDisabled=true;
   }

    ngOnDestroy(){
     this.fileNoteObservable.unsubscribe();
   }

   toggleView($event) {
   if(this.applicationStateService.getDeviceName()=='Mobile'){
     this.height=180;
    }
     else{this.height=280;

     }
    if ($event.target.parentNode.parentNode.offsetHeight >this.height) {
      if(this.applicationStateService.getDeviceName()=='Mobile'){
      $event.target.parentNode.parentNode.style.height = '180px';
      }else{
        $event.target.parentNode.parentNode.style.height = '280px';
      }
      $event.target.innerHTML = 'VIEW MORE';
      // $event.target.parentNode.parentNode.parentNode.childNodes[0].style.height = '200px';
    } else {
      $event.target.parentNode.parentNode.style.height = 'auto';
      $event.target.innerHTML = 'VIEW LESS';
      // $event.target.parentNode.parentNode.parentNode.childNodes[0].style.height = ($event.target.parentNode.parentNode.offsetHeight - 40) + 'px';
    }
  // }
  // if("applicationStateService.getDeviceName()=='Tablet'"){
  //   if ($event.target.parentNode.parentNode.offsetHeight >280) {
  //     $event.target.parentNode.parentNode.style.height = '280px';
  //     $event.target.innerHTML = 'VIEW MORE';
  //     // $event.target.parentNode.parentNode.parentNode.childNodes[0].style.height = '200px';
  //   } else {
  //     $event.target.parentNode.parentNode.style.height = 'auto';
  //     $event.target.innerHTML = 'VIEW LESS';
  //     // $event.target.parentNode.parentNode.parentNode.childNodes[0].style.height = ($event.target.parentNode.parentNode.offsetHeight - 40) + 'px';
  //   }
  // }

  }

  public parseDisplayedIn(displayedIn) {
    if (displayedIn) {
      const split = displayedIn.split('#~#');
      const parsed = [];
      split.forEach((display, index) => {
        if (index % 2 == 1) {
          if (display.toUpperCase() == 'everywhere'.toUpperCase()) {
            return [];
          }
          parsed.push(display);
        }
      });
      return parsed;
    } else {
      return [];
    }
  }

  public closeAddNote(event) {
    this.showEdit = false;
    if (event.description) {
      this.description = event.description;
      this.display = event.display;
      this.taskId = event.taskId;
      this.category =  event.category;
      this.status = event.status;
      this.postFileNoteComm();
    } else {
      this.description = '';
    }
  }

  //method to post the file note comment
  public postFileNoteComm() {
    let comments = this.description;
    this.comments = [];
    let editedContent = comments.replace(/(<p>|<\/p>)/g, '');
    let fileAttribute = this.service.getFileNoteAttrValue();
    if (editedContent) {
      let obj = {
        'comment': editedContent,
      }
      this.comments.push(obj);
      let tabObj = {
       'code': this.tabData.tabId,
       'name': this.tabData.tabName
      }
      let displayedIn = '';
      if (this.display.everywhere.checked == false) {
        this.display.options.forEach(option => {
          if (option.checked) {
            if (displayedIn == '') {
              displayedIn += option.option.id + '#~#' + option.option.name;
            } else {
              displayedIn += '#~#' + option.option.id + '#~#' + option.option.name;
            }
          }
        });
      } else {
        displayedIn = this.display.everywhere.option.id + '#~#' + this.display.everywhere.option.name;
      }
      let requestObject: any = {
        'claimNumber': this.claimNumber,
        'comments': this.comments,
        'attributes': fileAttribute,
        'type': tabObj,
        'displayedIn': displayedIn,
        'taskId': this.taskId,
        'status': this.status
      }
      this.clientService.setUrl(environment.taskServiceUrl);
      this.clientService.postClientData(requestObject).subscribe(response => {
        this.service.setFileNoteComment(this.tabData);
        this.newComment = {
          taskComment: response,
          taskId: this.taskId,
          status: this.status
        };
      });
    }
  }

  public editFileNote(comment) {
    this.clientService.setUrl(this.taskUrl +"?taskType="+ this.fileNoteSectionCode +"&region="+this.region);
    this.clientService.getClientData().subscribe(res => {
      let attributes = res.attributes;
      this.editComment = {
        editorValue: comment.comments[comment.comments.length - 1].comment,
        editorTemplate: {
          editorLabel: 'Description',
          cancel: 'CANCEL',
          save: 'POST'
        },
        attributeData: attributes,
        category: comment.category,
        display: comment.displayedIn,
        updatedDate: comment.updatedDate ? comment.updatedDate : comment.createdDate,
        edit: true,
        taskId: comment.taskId,
        status: this.status
      };
    });
    this.showEdit = true;
  }

  public addFileNote() {
    this.showEdit = true;
    this.clientService.setUrl(this.taskUrl +"?taskType="+ this.fileNoteSectionCode +"&region="+this.region);
    this.clientService.getClientData().subscribe(res => {
      const attributes = res.attributes;
      this.editComment = {
          editorValue: '',
          editorTemplate: {
            editorLabel: 'Description',
            cancel: 'CANCEL',
            save: 'POST'
          },
          attributeData: attributes,
          category: '',
          displayedIn: '',
          edit: false,
          taskId: null,
          status: this.status
      };
    });
}
}
