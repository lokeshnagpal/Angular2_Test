import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FileNoteMobileComponent } from './file-note-mobile.component';

describe('FileNoteMobileComponent', () => {
  let component: FileNoteMobileComponent;
  let fixture: ComponentFixture<FileNoteMobileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FileNoteMobileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FileNoteMobileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
