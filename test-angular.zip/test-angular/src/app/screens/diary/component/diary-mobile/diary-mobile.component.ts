import { environment } from './../../../../../environments/environment';
import { CommonTransformerService } from './../../../../util/common-transformer.service';
import { MatDialog, MatSnackBar } from '@angular/material';
import { ClientService } from './../../../../services/client.service';
import { ActivatedRoute, Router } from '@angular/router';
import { DiaryService } from './../../diary.service';
import { DiaryComponent } from './../diary/diary.component';
import { Component, OnInit, ChangeDetectorRef } from '@angular/core';

@Component({
  selector: 'app-diary-mobile',
  templateUrl: './diary-mobile.component.html',
  styleUrls: ['./diary-mobile.component.scss']
})
export class DiaryMobileComponent extends DiaryComponent implements OnInit {
  
  public  panelOpenState = false;
  public show="posted";
  public fetchDiary = true;

  constructor(public service: DiaryService, public route: ActivatedRoute, public clientService: ClientService, public dialog: MatDialog,
    public ref: ChangeDetectorRef, public snackBar: MatSnackBar,public commonTransformerService: CommonTransformerService) {

    super(service, route, clientService, dialog, ref, snackBar, commonTransformerService);
  }

  ngOnInit() {
    
  }

  public doMobDiaryAction(event) {
    if (event == "allDiary") {
      this.showDiaryListAction();
    } else if (event == "closeDiary") {
     this.callCloseDiary(this.service.getTaskNumber());
    } else if (event == "editDiary"){
      this.editDiaryAction(this.service.getTaskNumber());
    }else if(event=="nextOpenDiary"){
     this.showNextOpenDiary();
    }
  }

  getSelectedDiary() {
    if (this.fetchDiary && this.openDiaryRowItems && this.openDiaryRowItems.length>0 && this.diaryId) {
      this.openDiaryOverview(this.diaryId, true);
      this.fetchDiary = false;
    }
    return true;
  }
}
