import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DiaryMobileComponent } from './diary-mobile.component';

describe('DiaryMobileComponent', () => {
  let component: DiaryMobileComponent;
  let fixture: ComponentFixture<DiaryMobileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DiaryMobileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DiaryMobileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
