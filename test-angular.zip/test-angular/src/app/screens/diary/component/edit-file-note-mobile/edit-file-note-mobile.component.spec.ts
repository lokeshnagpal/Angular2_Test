import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditFileNoteMobileComponent } from './edit-file-note-mobile.component';

describe('EditFileNoteMobileComponent', () => {
  let component: EditFileNoteMobileComponent;
  let fixture: ComponentFixture<EditFileNoteMobileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditFileNoteMobileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditFileNoteMobileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
