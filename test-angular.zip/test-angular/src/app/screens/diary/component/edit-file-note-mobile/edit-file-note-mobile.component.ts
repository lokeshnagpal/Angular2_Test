import { Component, OnInit, Input,EventEmitter, Output, ChangeDetectorRef } from '@angular/core';
import { environment } from './../../../../../environments/environment';
import { DiaryService } from './../../diary.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ClientService } from 'src/app/services/client.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-edit-file-note-mobile',
  templateUrl: './edit-file-note-mobile.component.html',
  styleUrls: ['./edit-file-note-mobile.component.scss']
})
export class EditFileNoteMobileComponent implements OnInit {

  
  public attributes: any;
  public lookupUrl: any;
  public optionValue: any;
  public attributeHolder: any = [];
  public lookupVal = [];
  public fileNoteForm: FormGroup;
  public category: any;
  public display: any;
  public status: any;
  public initFlagCategory: any;
  public initFlagDisplay: any;
  public showTooltip = false;
  public data:any;
  public updatedDate:any;
  
  public claimDescriptionData: any;
  public editorTemplateData: any;

  @Input() public set commentData(data: any) {
    this.data = data;
    if (data) {
      this.initComponent();
    }
  }

  @Output() public editorEvent = new EventEmitter();
  constructor(public fb: FormBuilder, private clientService: ClientService,
  private ref: ChangeDetectorRef, private service: DiaryService, private route: ActivatedRoute) {
    this.lookupUrl = environment.lookupUrl;
  }

  ngOnInit() {
    this.initFlagCategory = 2;
    this.initFlagDisplay = true;
   
  }
  initComponent() {
   this.claimDescriptionData =this.data.editorValue;
    this.editorTemplateData = this.data.editorTemplate;
    this.attributes = this.data.attributeData;
    this.updatedDate=this.data.updatedDate;
    this.fileNoteForm = this.createForm(this.attributes);
    for (const index in this.attributes) {
        this.getLookupData(this.attributes[index], this.attributes[index].dbColumnName);
    }
    this.attributeHolder = [];
    this.service.setFileNoteAttrValue(this.attributeHolder);
  }
  public createForm(obj) {
    const group = this.fb.group({});
    obj.forEach(control => group.addControl(control.dbColumnName, this.createControl(control)));
    return group;
  }
  public createControl(config) {
    const { isDisabled } = config;
    let value;
    let validation;
    const item = config;
    if (config.mandatory) {
        validation = Validators.required;
    }
    const control = this.fb.control({ 'value': value, 'disabled': isDisabled }, validation);
    control.valueChanges.subscribe(res => {
      this.formControlChange(control, config);
    });
    return control;
  }
  public getLookupData(data, controlName) {
    this.lookupVal = [];
    let urlForLookup = this.lookupUrl + '/' + data.source + '/' + data.group + '/';
    if (data.referenceDataValue && data.referenceDataValue.id && data.value == data.referenceDataValue.name){
        urlForLookup = urlForLookup + data.referenceDataValue.id;
    }
    this.clientService.setUrl(urlForLookup);
    this.clientService.setCardReqDetails(this.clientService.getCardReqDetails().cardName);
    this.clientService.getClientData().subscribe(response => {
        data.attributeOptions = response;
        if (this.initFlagDisplay== true) {
          this.buildAttributes();
        }
        if (this.data.edit && this.initFlagCategory > 0 && data.name == 'Category') {
          this.initFlagCategory--;
          this.fileNoteForm.controls[data.dbColumnName].setValue(this.data.category);
        }
    });
  }
  public buildAttributes() {
    const url = environment.lookupUrl + '/REFDATA/FILE_NOTE_DISPLAYED_IN/';
    this.clientService.setUrl(url);
    this.clientService.getFileNoteDisplayData().subscribe(response => {
      const options = [];
      let all;
      response.forEach(option => {
        if (option.id == 'EVERYWHERE') {
          all = option;
        } else {
          options.push({
              option,
              checked: false
          });
        }
      });
      this.display = { options , everywhere: { option: all, checked: false} };
      this.initFlagDisplay = false;
      if ( this.data.edit) {
        this.setDisplayedIn(this.data.display);
      }
    });
  }
  public setDisplayedIn(displayedIn) {
    if (displayedIn && displayedIn.length > 0) {
      const split = displayedIn.split('#~#');
      this.display.options.forEach((option, index) => {
        split.forEach((display, i) => {
          if (i % 2 == 1) {
            if (display.toUpperCase() == 'everywhere'.toUpperCase()) {
              this.display.everywhere.checked = true;
              this.toggleAll(this.display.everywhere.checked, this.display.options);
              return;
            } else if (display.toUpperCase() == option.option.name.toUpperCase()) {
              this.display.options[index].checked = true;
            }
          }
        });
      });
    }
  }
  public toggleAll(value, options) {
    for (const option of options) {
        option.checked = value;
    }
  }
  fireEvent(description: any) {
    this.editorEvent.emit({
      description,
      display: this.display,
      taskId: this.data.taskId,
      category: this.category,
      status: this.status
    });
  }
  postDraft() {
    this.status = "S";
    this.fireEvent(this.claimDescriptionData);
  }
  cancelDraft() {
    this.fireEvent(null);
  }
  hasDisplay() {
    let checked = false;
    if (this.display && this.display.options) {
      if (this.display.everywhere.checked) {
        checked = true;
      } else {
        this.display.options.forEach(option => {
          if (option.checked) {
            checked = true;
          }
        });
      }
    }
    return checked;
  }

  public formControlChange(ctrl, attr){
    if (attr.type == 'LOOKUP'){
        this.getFilteredLookup(ctrl, attr);
        this.addLookupData();
    }
}
public addLookupData(){
  this.attributeHolder = [];
  for (const attribute of this.attributes) {
          if (attribute.type == 'LOOKUP') {
              const referenceObj: any = {
                  refDataId: '',
                  name: '',
                  code: ''
              };
              const lookupVal = this.fileNoteForm.controls[attribute.dbColumnName].value;
              if (lookupVal && lookupVal != '') {
                      const itemFound = attribute.attributeOptions.find(val => val.name == lookupVal);
                      if (itemFound) {
                      referenceObj['code'] = itemFound.id ;
                      referenceObj['refDataId'] = itemFound.refDataId ;
                      referenceObj['name'] = itemFound.name ;
                  }
                  else{
                      if (attribute.referenceDataValue && attribute.referenceDataValue.name == lookupVal){
                          referenceObj['code'] = attribute.referenceDataValue.id ;
                          referenceObj['refDataId'] = attribute.referenceDataValue.refDataId ;
                          referenceObj['name'] = attribute.referenceDataValue.name ;
                      }
                  }
              }
              this.category = referenceObj['name'];
              const diaryObj = {
                  attrId: attribute.attrId,
                  referenceDataValue: referenceObj,
                  dbColumnName: attribute.dbColumnName,
                  type: attribute.type,
                  value: lookupVal
              };
              this.attributeHolder.push(diaryObj);
          }
  }
  this.service.setFileNoteAttrValue(this.attributeHolder);
}

//method triggered when lookup input change
public getFilteredLookup(ctrl, attr){
  this.optionValue = ctrl.value;
  let urlForLookup = this.lookupUrl + '/' + attr.source + '/' + attr.group + '/'; 
  if (attr.referenceDataValue && attr.referenceDataValue.id && ctrl.value == attr.referenceDataValue.name){
      urlForLookup = urlForLookup + attr.referenceDataValue.id;
  }else{
      delete attr['referenceDataValue'];
      urlForLookup = urlForLookup +  ctrl.value;
  }
  this.clientService.setUrl(urlForLookup);
  this.clientService.getClientData().subscribe(response => {
          attr.attributeOptions = response;
  }); 
}

public checkLookupSelectedValue(lokupAttr, ctrl, lookupData){
      if (lookupData.attributeOptions && lookupData.attributeOptions.length >= 0){
          const selLookupval = lookupData.attributeOptions.find(x => x.name == ctrl.value);
          if (!selLookupval && !lookupData.referenceDataValue){
              ctrl.setValue('');
          }             
    }
}

public lookupOptionSelected(valSelected, config){
  this.fileNoteForm.controls[config.dbColumnName].setValue(valSelected.option.value);
  config['referenceDataValue'] = config.attributeOptions.find(x => x.name == valSelected.option.value);
}
  ngOnChanges() {
  }
}
