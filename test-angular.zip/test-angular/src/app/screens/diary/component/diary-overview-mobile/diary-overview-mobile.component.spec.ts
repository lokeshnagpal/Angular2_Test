import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DiaryOverviewMobileComponent } from './diary-overview-mobile.component';

describe('DiaryOverviewMobileComponent', () => {
  let component: DiaryOverviewMobileComponent;
  let fixture: ComponentFixture<DiaryOverviewMobileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DiaryOverviewMobileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DiaryOverviewMobileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
