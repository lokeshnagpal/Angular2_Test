import { CommonTransformerService } from 'src/app/util/common-transformer.service';
import { Constants } from './../../../../util/application.constants';
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { DiaryService } from 'src/app/screens/diary/diary.service';

@Component({
  selector: 'app-diary-overview-mobile',
  templateUrl: './diary-overview-mobile.component.html',
  styleUrls: ['./diary-overview-mobile.component.scss']
})
export class DiaryOverviewMobileComponent implements OnInit {

  @Input() rowItemsValue;
  @Input() taskAttributes;
  @Input() taskComments;
  @Input() postComments;
  @Input() diaryDetails;
  @Input() activeDiaryName;
@Output() mobDiaryAction:EventEmitter<any>=new EventEmitter();
@Output() updatepostCommEvent:EventEmitter<any>=new EventEmitter();

  public footerActionName=Constants.MORE_ACTIONS;
  public footerCommentsName=Constants.DIARY_DATES_FOOTER_COMM;
  public showFooterAction:boolean=true;
  public taskNumber:any;
  public selectedRowItem:any;
   public rowWidth:any="100%";
   public noComments:boolean=false;
   public commentsDetails:any;
   public groupCommList:any=[];
   public moreOptionsList;
 constructor(public service : DiaryService,private commonTransformerService: CommonTransformerService) { 
 }

  ngOnInit() {
    this.initiateChange();
    this.moreOptionsList=  [
      {name: "All Diaries in Claim",
       icon: {name:"arrow_back",
      type:'icon'},
       action:"allDiary",
       show:true
      },
      {name: "Edit Diary",
      icon: {name:"edit",
    type:"icon"},
      action:"editDiary",
      show: (this.activeDiaryName=='openDiary'? true:false)
     },
     {name: "Close Diary",
     icon: {name:"close",
    type:'icon'},
     action: "closeDiary",
     show: (this.activeDiaryName=='openDiary'? true:false)
    },
    {name: "Go to my next Open Diary",
    icon: {name:"skip_next",
  type:'icon'},
    action:"nextOpenDiary",
    show:true,
   }
    ]

  }

  ngOnChanges(){
    this.initiateChange();
    this.groupCommList=[];
    this.commentsDetails=null;
    if(this.taskComments!=null){
      if(this.taskComments && this.taskComments.length>0){
        if( ! this.taskComments[0].attributes && this.taskComments[0].taskComments && this.taskComments[0].taskComments.length && this.taskComments[0].taskComments.length>0){
          this.commentsDetails=this.taskComments[0].taskComments;
          this.noComments=false;
        }
        else{
          this.noComments=true;
        }

      }
      else{
        this.noComments=true;
      }
        for(let item of this.taskComments){
          if(item.attributes){
            let rowGroupObj=this.service.setMobRowGroupObj(item.attributes);
            let convertedObj=this.service.objConverter(rowGroupObj);
             let commGroup=item.taskComments;
             let groupCommObj={
               groupObj:convertedObj,
               groupComm:commGroup
             }
             this.groupCommList.push(groupCommObj);
          }
          }
      
    }

  }

  public initiateChange(){
    this.taskNumber = this.service.getTaskNumber();
    if(this.rowItemsValue){
      this.service.setRowitemCount(this.rowItemsValue.length);
      let taskAttr=this.diaryDetails.find(x=>x.taskNumber==this.taskNumber);
      if(taskAttr){
        let newRowObj=this.service.setMobRowObj(taskAttr);
        let convertedObj=this.service.objConverter(newRowObj);
        this.selectedRowItem = convertedObj;
      }   
    }
  }

  public mobDiaryEvent(event){
      this.mobDiaryAction.emit(event);
  }

  public postCommEvent(event){
 this.updatepostCommEvent.emit(event);
}
}
