import { Subscription, Subject } from 'rxjs';
import { environment } from './../../../../../environments/environment';
import { ClientService } from './../../../../services/client.service';
import { DiaryService } from './../../diary.service';
import { Constants } from './../../../../util/application.constants';
import { Component, OnInit, Input , Output, EventEmitter, SimpleChanges} from '@angular/core';
import { ApplicationStateService } from 'src/app/util/application.state.service';
import { debounceTime, mergeMap } from 'rxjs/operators';

@Component({
  selector: 'app-diary-file-note-list',
  templateUrl: './diary-file-note-list.component.html',
  styleUrls: ['./diary-file-note-list.component.scss']
})
export class DiaryFileNoteListComponent implements OnInit {

  public loadTaskDetails: string;
  public taskComments: any = [];
  public loadTaskComments: any;
  public getNoteComm: Subscription;
  public initFlag = true;
  public totalCount = 0;
  public filterCount = 0;
  public isLoading = false;
  public expandAll = false;
  public fileNoteSectionCode = Constants.FILE_NOTE_SECTION_CODE;
  public isIE: boolean = false;
  private subject: Subject<string> = new Subject();
  public start: number = 1;
  public more: boolean = true;
  public prev: any;

  @Input() fileNoteActiveItem;
  @Input() tabIndex;
  @Input() tabData;
  @Input() claimNumber;
  @Input() newComment;
  @Input() status;
  @Input() filter;
  @Output() public editNoteEvent = new EventEmitter();
  @Output() public filterCountEvent = new EventEmitter();

  constructor(public service: DiaryService, public clientService: ClientService, public applicationStateService: ApplicationStateService) {
    this.loadTaskDetails = environment.loadTaskDetails;
    this.isIE = this.applicationStateService.isBrowserIE();
  }
  ngOnInit() {
    this.subject.pipe(debounceTime(50),
    mergeMap(() => {
      return this.fetchData(this.tabData, this.filter);
    })).subscribe(response => {
      this.postFetchingData(response, this.filter);
    });
  }

  onScroll() {
    if(this.more){
    this.subject.next();
    }
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.newComment) {
      if (this.newComment && (this.newComment.status == this.status || (this.newComment.removeDraft && this.status == 'D'))) {
        if (this.newComment.taskId) {
          this.taskComments = this.taskComments.filter(taskComment => taskComment.taskId != this.newComment.taskId);
        }
        if (this.newComment.removeDraft && this.status == 'D') {
          if (this.filter) {
            this.filterCount--;
          }
          this.totalCount--;
        } else {
          const temp = {...this.newComment.taskComment};
          temp.expanded = this.expandAll;
          this.taskComments = [temp, ...this.taskComments];
          if (this.filter) {
            this.filterCount++;
          }
          this.totalCount++;
        }
        this.filterCountUpdate();
      }
    }
    if ((this.initFlag || changes.fileNoteActiveItem || changes.filter) && (this.tabIndex == 1 || this.tabIndex == 2) && this.tabData) {
      if (this.filter) {
        this.getFileNotesData(this.tabData, this.filter);
      } else {
        this.getFileNotesData(this.tabData);
      }
    }
  }
  public fetchData(event, filter?) {
    this.isLoading = true;
    let tabObj = {
      'code': event.tabId,
      'name': event.tabName
    }
    const count = filter ? this.filterCount : this.totalCount;
    if (!(filter == this.prev || (!filter && !this.prev))) {
      this.start = 1;
    }
    let requestObject: any = {
      'claimNumber': this.claimNumber,
      'type': tabObj,
      'status': this.status,
      "startIndex": this.start , 
      "pageSize": 10,
    };
    this.start = this.start + 10;
    if (filter) {
      requestObject['filterCriteria'] = filter['filterCriteria'];
    }
    this.clientService.setUrl(this.loadTaskDetails);
    this.clientService.setCardReqDetails(this.clientService.getCardReqDetails().cardName);
    return this.clientService.postClientData(requestObject);
  }
  
   public  getFileNotesData(event, filter?) {
    this.fetchData(event, filter).subscribe(response => {
      this.postFetchingData(response, filter);
    });
  }

  public postFetchingData(response, filter?) { 
    // response should be replaced with response.data
    if (filter == this.prev || (!filter && !this.prev)) {
      this.taskComments = [...this.taskComments, ...response];
    } else {
      this.taskComments = [...response];
    }
    this.prev = filter;
    this.taskComments.forEach(taskComment => {
      taskComment.expanded = this.expandAll;
    });
    this.isLoading = false;
    // Set totalCount/filterCount & count to value from response
    let count;
    if(this.taskComments.length>0){
    count = this.taskComments[0].count;
    }
    else{
      count=0
    }
    if (this.filter) {
      this.filterCount = count;
    } else {
      this.totalCount = count;
    }
    this.more = count >= this.start;
    this.filterCountUpdate();
    this.initFlag = false;
  }
  public parseDisplayedIn(displayedIn) {
    if (displayedIn) {
      const split = displayedIn.split('#~#');
      const parsed = [];
      split.forEach((display, index) => {
        if (index % 2 == 1) {
          if (display.toUpperCase() == 'everywhere'.toUpperCase()) {
            return [];
          }
          parsed.push(display);
        }
      });
      return parsed;
    } else {
      return [];
    }
  }
  public filterCountUpdate() {
    this.filterCountEvent.emit({
      total: this.totalCount,
      filtered: this.filterCount,
      status: this.status
    });
  }
  public editFileNote(comment) {
    comment.status = this.status;
    this.editNoteEvent.emit(comment);
  }
  toggleView(taskComment) {
    if (taskComment.expanded) {
      this.expandAll = false;
    }
    taskComment.expanded = !taskComment.expanded;
  }
  expandComments() {
    this.taskComments.forEach(comment => {
      comment.expanded = this.expandAll;
    });
  }
}
