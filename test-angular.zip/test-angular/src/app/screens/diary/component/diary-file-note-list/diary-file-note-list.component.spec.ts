import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DiaryFileNoteListComponent } from './diary-file-note-list.component';

describe('DiaryFileNoteListComponent', () => {
  let component: DiaryFileNoteListComponent;
  let fixture: ComponentFixture<DiaryFileNoteListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DiaryFileNoteListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DiaryFileNoteListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
