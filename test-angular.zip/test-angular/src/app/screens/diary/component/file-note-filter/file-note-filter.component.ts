import { Component, OnInit, Input, Output, EventEmitter, SimpleChanges } from '@angular/core';
import { ClientService } from 'src/app/services/client.service';
import { CommonTransformerService } from 'src/app/util/common-transformer.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-file-note-filter',
  templateUrl: './file-note-filter.component.html',
  styleUrls: ['./file-note-filter.component.scss']
})
export class FileNoteFilterComponent implements OnInit {

  @Input() fileNoteActiveItem;
  @Input() filterObject;
  @Input() clearFilter;
  @Input() displayArray;
  @Output() public filterFileNoteEvent = new EventEmitter();
  @Output() public isFilteredEvent = new EventEmitter();
  @Output() public displayArrayEvent = new EventEmitter();
  
  public DISPLAY_ARRAY_DATA: any;
  public isFiltered = false;
  public filterDateObject = {
    from: '',
    to: ''
  };
  public filterRequestObject = {
    search: '',
    from: '',
    to: '',
    display: ''
  };

  constructor(public clientService: ClientService, public commonTransformerService: CommonTransformerService) { }

  ngOnInit() {
    this.fetchAttributes();
  }
  ngOnChanges(changes: SimpleChanges): void {
    if (changes.clearFilter) {
      if (this.clearFilter) {
        this.clearFilters();
      }
    }
  }
  
  fetchAttributes() {
    const url = environment.lookupUrl + '/REFDATA/FILE_NOTE_DISPLAYED_IN/';
    this.clientService.setUrl(url);
    this.clientService.getFileNoteDisplayData().subscribe(response => {
      const options = [];
      let all;
      response.forEach(option => {
        if (option.id == 'EVERYWHERE') {
          all = option;
        } else {
          options.push({
              option,
              checked: false
          });
        }
      });
      this.DISPLAY_ARRAY_DATA = { options , everywhere: { option: all, checked: false} };
      if (this.displayArray == null) {
        this.displayArray = this.DISPLAY_ARRAY_DATA;
      }
    });
  }
  fireFilterEvent() {
    if (this.filterObject == null) {
      this.filterObject = { "filterCriteria": null };
    }
    this.filterFileNoteEvent.emit(this.filterObject);
  }
  fireIsFilteredEvent() {
    this.isFilteredEvent.emit(this.isFiltered);
  }
  fireDisplayArray() {
    this.displayArrayEvent.emit(this.displayArray);
  }
  public filterFileNotes() {
    this.filterRequestObject.display = this.getDisplayValue(this.displayArray);
    this.fireDisplayArray();
    this.filterRequestObject.from = this.filterDateObject.from ? this.commonTransformerService.dateInServiceFormat(this.filterDateObject.from.toString()) : this.filterDateObject.from;
    this.filterRequestObject.to = this.filterDateObject.to ? this.commonTransformerService.dateInServiceFormat(this.filterDateObject.to.toString()) : this.filterDateObject.to;
    this.isFiltered = false;
    let isEmpty = true;
    for (const filter in this.filterRequestObject) {
      if (this.filterRequestObject[filter] != '' && filter != 'from' && filter != 'to') {
        isEmpty = false;
        break;
      }
    }
    const hasDate = this.filterRequestObject.from && this.filterRequestObject.to && this.filterRequestObject.from.length > 0 && this.filterRequestObject.to.length > 0;
    this.isFiltered = !isEmpty || hasDate;
    this.fireIsFilteredEvent();
    if (this.isFiltered) {
      this.filterObject = {
        "filterCriteria": {
          "DISPLAYED_IN": this.filterRequestObject.display ? this.filterRequestObject.display : null,
          "CREATED_DT_FROM": hasDate ? this.filterRequestObject.from : null,
          "CREATED_DT_TO": hasDate ? this.filterRequestObject.to : null,
          "FILE_NOTE_COMMENTS": this.filterRequestObject.search ? this.filterRequestObject.search : null
        }
      };
    } else {
      this.filterObject = { "filterCriteria": null };
    }
    this.fireFilterEvent();
  }
  clearFilters() {
    const dateObject = {
      from: '',
      to: ''
    };
    const requestObject = {
      search: '',
      from: '',
      to: '',
      display: ''
    };
    this.displayArray = this.DISPLAY_ARRAY_DATA;
    this.displayArray.everywhere.checked = false;
    this.displayArray.options.forEach(option => option.checked = false);
    this.fireDisplayArray();
    this.filterDateObject = dateObject;
    this.filterRequestObject = requestObject;
    this.isFiltered = false;
    this.fireIsFilteredEvent();
    this.filterObject = null;
    this.fireFilterEvent();
  }
  getDisplayValue(display) {
    let displayedIn = '';
    if (display.everywhere.checked == false) {
      display.options.forEach(option => {
        if (option.checked) {
          if (displayedIn == '') {
            displayedIn += option.option.id + '#~#' + option.option.name;
          } else {
            displayedIn += '#~#' + option.option.id + '#~#' + option.option.name;
          }
        }
      });
    } else {
      displayedIn = display.everywhere.option.id + '#~#' + display.everywhere.option.name;
    }
    return displayedIn;
  }
  toggleAll(value, options) {
    for (const option of options) {
        option.checked = value;
    }
  }
}
