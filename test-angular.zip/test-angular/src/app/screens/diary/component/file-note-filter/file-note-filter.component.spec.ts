import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FileNoteFilterComponent } from './file-note-filter.component';

describe('FileNoteFilterComponent', () => {
  let component: FileNoteFilterComponent;
  let fixture: ComponentFixture<FileNoteFilterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FileNoteFilterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FileNoteFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
