import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClaimSummaryCardDesktopComponent } from './claim-summary-card-desktop.component';

describe('ClaimSummaryCardDesktopComponent', () => {
  let component: ClaimSummaryCardDesktopComponent;
  let fixture: ComponentFixture<ClaimSummaryCardDesktopComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClaimSummaryCardDesktopComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClaimSummaryCardDesktopComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
