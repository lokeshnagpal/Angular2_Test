import { Component, OnInit, Input } from '@angular/core';
import { CommonTransformerService } from 'src/app/util/common-transformer.service';
import { ClientService } from 'src/app/services/client.service';

@Component({
  selector: 'app-claim-summary-card-desktop',
  templateUrl: './claim-summary-card-desktop.component.html',
  styleUrls: ['./claim-summary-card-desktop.component.scss']
})
export class ClaimSummaryCardDesktopComponent implements OnInit {

  @Input() desktopOverviewData;

  constructor(private commonTransformerService: CommonTransformerService, private service: ClientService) {
  }

  ngOnInit() {
  }
}
