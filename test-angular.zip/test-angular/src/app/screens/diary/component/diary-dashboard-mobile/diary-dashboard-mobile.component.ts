import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ClientService } from 'src/app/services/client.service';
import { environment } from 'src/environments/environment';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { ApplicationStateService } from 'src/app/util/application.state.service';
import { DiaryService } from '../../diary.service';
import { DiaryComponent } from '../diary/diary.component';
import { MatDialog, MatSnackBar } from '@angular/material';
import { CommonTransformerService } from 'src/app/util/common-transformer.service';

@Component({
  selector: 'app-diary-dashboard-mobile',
  templateUrl: './diary-dashboard-mobile.component.html',
  styleUrls: ['./diary-dashboard-mobile.component.scss']
})
export class DiaryDashboardMobileComponent extends DiaryComponent implements OnInit {

  public dataSource: any = [];
  public displayedColumns: string[];
  public displayedAttributes: string[];
  public DIARY_DATA: any;
  public SORT_DATA: any = [];
  public FILTER_DATA: any;
  public recordCount: any;
  public count: any;
  public sectionDetails: any;
  public option = 'sort';
  public isSorted: any = false;
  public isFiltered: any = false;
  public sortArray: any = [];
  public filterObject: any;
  public tempSortArray: any = [];
  public tempFilterObject: any;
  public categories: any;
  public stats: any;
  public showProgressBar = false;
  public indicators: any = [];
  public isFilterDataLoaded = false;
  public filteredColumns: any = [];
  public isOpen = false;
  public initialTotalCount: any;
  public settings: any;
  public tableSettings: string[];
  public resetSidenav = false;
  public savedSettings: any[] = [];
  public currentSetting: string = 'default';
  public disableSave: boolean = true;
  public tempSetting: any;
  public isIE: boolean = false;
  public dueDateId;

  constructor(public clientService: ClientService, private router: Router, public applicationStateService: ApplicationStateService,
    public service: DiaryService, public commonTransformerService: CommonTransformerService, public route: ActivatedRoute,
    public dialog: MatDialog, public ref: ChangeDetectorRef,  public snackBar: MatSnackBar) {
      super(service, route, clientService, dialog, ref, snackBar, commonTransformerService);
      this.tableSettings = ['Filter', 'Sort'];
      this.isIE = this.applicationStateService.isBrowserIE();
   }

  ngOnInit() {
    this.showProgressBar = true;
    this.getSavedSettings(null, true);
  }
  
  initComponent(init?) {
    if (init) {
      this.initDashboard(true);
    } else {
      const attr = {
        'sectionCode': 'DIARY_LIST_VIEW_TABLE',
        'startRow': 1,
        'endRow': 20,
        'customFilterId': '0',
        'isGenericSearch': true,
        'sortColumnId': this.dueDateId,
        'sortDirection': 'DESC'
      };
      this.clientService.setUrl(environment.searchUrl);
      this.clientService.getDiaryTableData(attr).subscribe(response => {
        this.DIARY_DATA = response.json();
        this.initDashboard();
      });
    }
  }

  initDashboard(load?) {
    if (!load) {
      this.recordCount = this.DIARY_DATA.recordCount;
      this.initialTotalCount = this.recordCount;
      this.count = this.recordCount < 20 ? this.recordCount : 20;
      this.sectionDetails = this.DIARY_DATA.sectionDetails;
      this.buildSort();
      this.buildFilter();
      this.buildIndicatorArray();
      this.dataSource = this.parseData(this.DIARY_DATA.data);
      this.getStatistics();
    } else {
      this.buildSort();
      this.buildFilter();
      this.buildIndicatorArray();
      this.loadSettings(true);
    }
  }
  getSectionDetails(init?) {
    this.clientService.setUrl(environment.lookupUrl + '/section/DIARY_LIST_VIEW_TABLE');
    this.clientService.getClientData().subscribe(response => {
      const tempSections = [];
      response.attributes.forEach(attribute => {
        const section = {
          'attrSize': attribute.attrSize,
          'columnLabel': attribute.name,
          'columnName': attribute.dbColumnName,
          'columnType': attribute.type,
          'hidden': attribute.hidden,
          'mandatory': attribute.mandatory,
          'sectionAttrId': attribute.secAttrMapId
        };
        tempSections.push(section);
      });
      this.sectionDetails = tempSections;
      const columns = [];
      this.sectionDetails.forEach(header => {
        if (!header.hidden) {
          if (header.mandatory) {
            columns.push(header.columnName);
          }
        }
        if (header.columnName == 'DUE_DATE') {
          this.dueDateId = header.sectionAttrId;
        }
      });
      this.displayedColumns = ['select', ...columns];
      this.displayedAttributes = columns.filter(column => column != 'TASK_NUM' && column != 'INSURED' && column != 'DUE_DATE' && column != 'ASSIGNEDTO' && column != 'PRIORITY_DIARY');
      this.initComponent(init);
    });
  }
  parseData(data) {
    const parsedData = [];
    data.forEach(row => {
      const rowData = {};
      row.forEach((rowItem, index) => {
        rowData[rowItem.dbColumnName] = rowItem;
        rowData[rowItem.dbColumnName].columnLabel = this.sectionDetails[index].columnLabel;
      });
      parsedData.push(rowData);
    });
    return parsedData;
  }
  getSavedSettings(name?, init?) {
    this.clientService.setUrl(environment.lookupUrl + '/CUSTOM_FILTER_DATA/Custom_Filters_Diaries/');
    this.clientService.getClientData().subscribe(response => {
      this.savedSettings = [{'id': 'default', 'name': 'Default Settings'}, ...response];
      if (name) {
        this.savedSettings.forEach(setting => {
          if (setting.name == name) {
            this.currentSetting = setting.id;
          }
        });
      }
      if (init) {
        if (this.savedSettings && this.savedSettings.length > 1) {
          this.savedSettings.forEach(setting => {
            if (setting.isDefault) {
              this.currentSetting = setting.id;
            }
          });
          if (this.currentSetting != 'default') {
            this.getSectionDetails(true);
          } else {
            this.getSectionDetails();
          }
        } else {
          this.getSectionDetails();
        }
      }
    });
  }
  buildSort() {
    this.sectionDetails.forEach(section => {
      if (!section.hidden && section.mandatory) {
        this.SORT_DATA.push({
          name: section.columnLabel,
          id: section.sectionAttrId,
          order: 'none'
        });
      }
    });
    this.sortArray = [ ...this.SORT_DATA ];
  }
  buildFilter() {
    let filterString = '{ ';
    this.sectionDetails.forEach((section, index) => {
      if (!section.hidden && section.mandatory) {
        filterString += '"' + section.columnLabel + '": { "dbColumnName": "' + section.columnName + '", "show": "' + section.mandatory + '", "columnType": "' + section.columnType + '", "sectionAttrId": "' + section.sectionAttrId + '", "value": "", "columnType": "' + section.columnType + '" }';
        if (index < this.sectionDetails.length - 1) {
          filterString += ', ';
        }
      }
    });
    filterString += ' }';
    this.FILTER_DATA = JSON.parse(filterString);
    this.FILTER_DATA['Due Date'].from = '';
    this.FILTER_DATA['Due Date'].to = '';
    this.filterObject = { ...this.FILTER_DATA };
  }
  buildIndicatorArray() {
    const indicatorArray = [
      {name: 'Confidential', dbName: 'CONFIDENTIALITY'},
      {name: 'IPA', dbName: 'PROGRAM_NUMBER'},
      {name: 'ITC', dbName: 'ITC'},
      {name: 'Payment Order', dbName: 'PAYMENT_ORDER'},
      {name: 'Primary', dbName: 'MARKET_POSITION'},
      {name: 'Pulse', dbName: 'CLIENT_PORTAL_IND'}
    ];
    indicatorArray.forEach( indicator => {
      this.indicators.push({
        name: indicator.name,
        dbName: indicator.dbName,
        selected: false
      });
    });
  }
  getStatistics(statsAttr?) {
    const attr = statsAttr ? statsAttr : { "sectionCode": "DIARY_LIST_VIEW_TABLE" }
    this.clientService.setUrl(environment.statsUrl);
    this.clientService.postClientData(attr).subscribe(response => {
      this.stats = response.statistics;
      this.showProgressBar = false;
    });
  }
  parseStats(tablet?) {
    let parsed = '';
    if (tablet) {
      parsed += '  |  ';
    }
    if (this.stats.OPEN_DIARY_COUNT || this.stats.OPEN_DIARY_COUNT == 0) {
      parsed += this.stats.OPEN_DIARY_COUNT + ' Open';
    }
    if (this.stats.ALREADY_DUE_COUNT || this.stats.ALREADY_DUE_COUNT == 0) {
      parsed += '  |  ' + this.stats.ALREADY_DUE_COUNT + ' Overdue';
    }
    if (this.stats.DUE_TODAY_COUNT || this.stats.DUE_TODAY_COUNT == 0) {
      parsed += '  |  ' + this.stats.DUE_TODAY_COUNT + ' Due Today';
    }
    return parsed;
  }
  viewMore() {
    this.apply('none', (this.count+20));
  }
  open(option) {
    this.isOpen = true;
    this.option = option;
    if (option == 'saveSettings') {
      this.disableSave = true;
    }
  }
  close(option) {
    this.isOpen = false;
    if (option == 'sort' || option == 'filter') {
      this.apply(option);
    } else if (option == 'saveSettings') {
      this.saveSettings();
    } else if (option == 'loadSettings') {
      this.loadSettings();
    }
  }
  clear(option) {
    if (option == 'sort') {
      this.clearSorting();
    } else if (option == 'filter'){
      this.clearFiltering();
    }
  }
  clearSorting() {
    this.isSorted = false;
    this.sortArray = [...this.SORT_DATA];
    this.sortArray.forEach(option => option.order = 'none');
    if (this.isFiltered == false) {
      this.apply(null);
    } else {
      this.apply('filter');
    }
  }
  clearFiltering() {
    this.isFiltered = false;
    this.filterObject = {...this.FILTER_DATA};
    this.filteredColumns = [];
    for (const column in this.filterObject) {
      if (column == 'Due Date') {
        this.filterObject[column].from = '';
        this.filterObject[column].to = '';
      }
      this.filterObject[column].value = '';
    }

    if (this.isSorted == false) {
      this.apply(null);
    } else {
      this.apply('sort');
    }
  }

  sortEvent(event) {
    this.tempSortArray = event;
  }
  filterEvent(event) {
    this.tempFilterObject = event;
  }

  selectIndicator(indicator) {
    let selected = '';
    this.indicators.forEach(item => {
      if (item.dbName === indicator.dbName) {
        item.selected = !item.selected;
        if (item.selected) {
          selected = item.dbName;
        }
      } else {
        item.selected = false;
      }
    });
    this.filterObject['Indicators'].value = selected;
    this.showFilter('Indicators');
  }
  showFilter(column) {
    if (this.filterObject[column].value == null || this.filterObject[column].value == '' || this.filterObject[column].value == 'None') {
      this.filteredColumns.filter(filter => filter != column);
    } else {
      if (!this.filteredColumns.includes(column)) {
        this.filteredColumns.push(column);
      }
    }
    if (column == 'Due Date') {
      if (this.filterObject[column].from != '' && this.filterObject[column].to != '') {
        if (!this.filteredColumns.includes(column)) {
          this.filteredColumns.push(column);
        }
      } else {
        this.filteredColumns.filter(filter => filter != column);
      }
    }
  }
  
  validateSettings(event) {
    if (this.option == 'saveSettings') {
      this.settings = event;
      if (event.name && event.name.length > 0 && event.selected && event.selected.length > 0) {
        let isUnique = true;
        this.savedSettings.forEach(setting => {
          if (setting.name == event.name || event.name == 'Default Diary Filter') {
            isUnique = false;
          }
        });
        if (isUnique) {
          this.disableSave = false;
        } else {
          this.disableSave = true;
        }
      } else {
        this.disableSave = true;
      }
    }
  }
  loadSettings(init?) {
    if (init) {
      if (this.currentSetting && this.currentSetting != 'default') {
        const setting = this.savedSettings.find(setting => setting.id == this.currentSetting);
        if (setting) {
          const attr = {
            'filterName': setting.name,
            'action': 'LOAD',
            'currentTab': 'CODiaries'
          };
          this.clientService.setUrl(environment.customSettingsUrl);
          this.clientService.postClientData(attr).subscribe(response => {
            this.applySettings(response.userFilters);
          });
        }
      } else if (this.currentSetting && this.currentSetting == 'default') {
        const settings = [];
        this.applySettings(settings);
      }
    } else {
      if (this.tempSetting && this.tempSetting.id != 'default' && this.tempSetting.userSettings) {
        this.applySettings(this.tempSetting.userSettings);
        this.currentSetting = this.tempSetting.id;
      } else if (this.tempSetting && this.tempSetting.id == 'default') {
        const settings = [];
        this.applySettings(settings);
        this.currentSetting = this.tempSetting.id;
      }
      this.setAsDefaultSetting();
    }
  }

  setAsDefaultSetting() {
    let name = 'Default Diary Filter';
    if (this.currentSetting && this.currentSetting.length > 0 && this.currentSetting != 'default') {
      const setting = this.savedSettings.find(setting => setting.id == this.currentSetting);
      if (setting) {
        name = setting.name;
      }
    }
    let attr = {
      'filterName':  name,
      'action':  'SAVE_DEFAULT',
      'currentTab': 'CODiaries'
    };
    this.clientService.setUrl(environment.customSettingsUrl);
    this.clientService.postClientData(attr).subscribe(response => {
      console.log(name + ' set as default setting.');
    });
  }

  applySettings(userSettings) {
    this.isSorted = false;
    this.isFiltered = false;
    this.buildSort();
    this.filteredColumns = [];
    for (const column in this.filterObject) {
      if (column == 'Due Date') {
        this.filterObject[column].from = '';
        this.filterObject[column].to = '';
      }
      this.filterObject[column].value = '';
    }
    const sortOrder = [];
    userSettings.forEach(setting => {
      if (setting.sorting) {
        const temp = this.sortArray.find(column => column.name == setting.attributeLabel);
        if (temp && setting.sortingOrder.sortingAsc || setting.sortingOrder.sortingDesc) {
          sortOrder.push(setting.attributeLabel);
          this.isSorted = true;
          if (setting.sortingOrder.sortingAsc) {
            temp.order = 'asc';
          } else {
            temp.order = 'desc';
          }
        }
      }
      if (setting.filter) {
        if (setting.dbColumnName != 'DUE_DATE' && setting.filterValue) {
          this.filterObject[setting.attributeLabel].value = setting.filterValue;
          this.isFiltered = true;
        }
      }
      if (setting.dbColumnName == 'DUE_DATE' && setting.filterValue) {
        const dates = setting.filterValue.split(',');
        if (dates[0].length > 0) {
          this.filterObject[setting.attributeLabel].from = this.commonTransformerService.dateToObjectFormatChange(dates[0]);
        }
        if (dates[1].length > 0) {
          this.filterObject[setting.attributeLabel].to = this.commonTransformerService.dateToObjectFormatChange(dates[1]);
        }
        this.isFiltered = true;
      }
    });
    const sorted = []
    const unsorted = [];
    sortOrder.forEach(item => {
      const found = this.sortArray.find(column => item == column.name);
      if (found) {
        sorted.push(found);
      }
    });
    this.sectionDetails.forEach(section => {
      const foundSort = this.sortArray.find(item => item.id == section.sectionAttrId);
      if (foundSort) {
        if (!sortOrder.includes(foundSort.name)) {
          unsorted.push(foundSort);
        }
      }
    });
    this.sortArray = [...sorted, ...unsorted];
    this.apply(null, 20, true);
  }
  deleteSetting(setting) {
    const settings = this.savedSettings.filter(userSetting => userSetting.id != setting.id);
    this.savedSettings = [...settings];
    this.showMessage(setting.name + ' has been deleted.', 2000);
    this.setAsDefaultSetting();
  }
  resettedSidenav(event, option) {
    if (event) {
      this.resetSidenav = false;
      this.ref.detectChanges();
    }
  }
  saveSettings() {
    this.resetSidenav = true;
    const sort = this.settings.selected.includes('Sort');
    const filter = this.settings.selected.includes('Filter');
    const searchCriteria = this.generateRequestAttr(sort, filter, 20).diaryAttr;
    const attr = {
      'filterName':  this.settings.name,
      searchCriteria,
      'action':  'SAVE',    // action can be SAVE – Save or Update And DELETE - Delete
      'currentTab': 'CODiaries'
    };
    this.clientService.setUrl(environment.customSettingsUrl);
    this.clientService.postClientData(attr).subscribe(response => {
      this.showMessage('Settings saved as ' + this.settings.name, 2000);
      this.getSavedSettings(this.settings.name);
    });
  }
  
  generateRequestAttr(sort, filter, endRow?) {
    const statsAttr = {
      'sectionCode': 'DIARY_LIST_VIEW_TABLE',
      'subFilterCriteria': {},
      'filterCriteria': {}
    };
    const attr = {
      'sectionCode': 'DIARY_LIST_VIEW_TABLE',
      'startRow': 1,
      'endRow':  (endRow ? endRow : ( this.initialTotalCount > 20 ? 20 : this.initialTotalCount )),
      'subFilterCriteria': {},
      'filterCriteria': {},
      'customFilterId': '0',
      'isGenericSearch': true
    };
    if (sort) {
      if (this.tempSortArray && this.tempSortArray.length > 0 && this.option == 'sort') {
        this.sortArray = [ ...this.tempSortArray];
        this.tempSortArray = [];
      }
      this.isSorted = true;
      const tempSortArray = this.sortArray.filter( column => {
        if (column.order != 'none') {
          return true;
        } else {
          return false;
        }
      });
      if (tempSortArray.length == 0) {
        this.isSorted = false;
      } else {
        let sortColumnId = '';
        tempSortArray.forEach((sortItem, index) => {
          if (index != 0) {
            sortColumnId += '#^#';
          }
          sortColumnId += sortItem.id + ',' + sortItem.order.toUpperCase();
        });
        attr['sortColumnId'] =  sortColumnId;
        attr['sortDirection'] = tempSortArray[0].order.toUpperCase();
      }
    }
    if (filter) {
      if (this.tempFilterObject && this.option == 'filter') {
        this.filterObject = { ...this.tempFilterObject };
        this.tempFilterObject = null;
      }
      this.filteredColumns = [];
      this.isFiltered = true;
      let hasSubFilter = false;
      let hasDate = false;
      let isEmpty = true;
      for (const item in this.filterObject) {
        if (this.filterObject[item].dbColumnName == 'DUE_DATE') {
          if ((this.filterObject[item].from && this.filterObject[item].from != '') || (this.filterObject[item].to && this.filterObject[item].to != '')) {
            hasDate = true;
          }
        } else {
          if (this.filterObject[item].value && this.filterObject[item].value != '' && this.filterObject[item].value != 'None') {
            isEmpty = false;
            attr['subFilterCriteria'][this.filterObject[item].sectionAttrId] = this.filterObject[item].value;
            statsAttr['subFilterCriteria'][this.filterObject[item].dbColumnName] = this.filterObject[item].value;
            hasSubFilter = true;
            this.filteredColumns.push(item);
          }
        }
      }
      this.isFiltered = !isEmpty || hasDate;
      if (hasDate) {
        attr['filterCriteria'][this.filterObject['Due Date'].sectionAttrId] = this.getDateValue(this.filterObject['Due Date'].from ? this.filterObject['Due Date'].from.toString() : '') + `,`  + this.getDateValue(this.filterObject['Due Date'].to ? this.filterObject['Due Date'].to.toString() : '');
        this.filteredColumns.push('Due Date');
        statsAttr['filterCriteria'][this.filterObject['Due Date'].dbColumnName] = this.getDateValue(this.filterObject['Due Date'].from ? this.filterObject['Due Date'].from.toString() : '') + `,`  + this.getDateValue(this.filterObject['Due Date'].to ? this.filterObject['Due Date'].to.toString() : '');
      }
    }
    if (!this.isSorted) {
      attr['sortColumnId'] = this.dueDateId;
      attr['sortDirection'] = 'DESC';
    }
    return {
      'diaryAttr': attr,
      'statsAttr': statsAttr
    };
  }
  
  apply(option, endRow?, loadSettings?) {
    this.isOpen = false;
    const requestAttrs = this.generateRequestAttr(option == 'sort' || this.isSorted, option == 'filter' || this.isFiltered, endRow);
    this.clientService.setUrl(environment.searchUrl);
    this.showProgressBar = true;
    this.clientService.getDiaryTableData(requestAttrs.diaryAttr).subscribe(response => {
      this.dataSource = this.parseData(response.json().data);
      this.recordCount = response.json().recordCount;
      if (!this.DIARY_DATA) {        
        this.DIARY_DATA = response.json();
      }
      if (!this.initialTotalCount || (this.initialTotalCount && this.recordCount > this.initialTotalCount)) {
        this.initialTotalCount = this.recordCount;
      }
      this.count = this.recordCount <= this.count ? this.recordCount : 20;
      if (requestAttrs.statsAttr != null) {
        this.getStatistics(requestAttrs.statsAttr);
      } else {
        this.getStatistics();
      }
      if(endRow) {
        this.count = endRow < this.recordCount ? endRow : this.recordCount;
      }
    });
    if (!loadSettings) {
      if (this.isSorted || this.isFiltered) {
        this.currentSetting = '';
      } else {
        this.currentSetting = 'default';
        this.setAsDefaultSetting();
      }
    }
  }
  selectOption(filter, value) {
    this.filterObject[filter].value = value;
    this.showFilter(filter);
  }
  showSidenav(option) {
    this.option = option;
  }
  getDateValue(date: string) {
    if (date.length > 0) {
      return this.commonTransformerService.dateInServiceFormat(date);
    } else {
      return date;
    }
  }
  getDateString(date) {
    const parsed = new Date(date.substring(0,4), (date.substring(4,6) -1), date.substring(6,8)).toString().split(' ');
    return parsed[2] + ' ' + parsed[1] + ' ' + parsed[3];
  }
  dropSortOrder(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.sortArray, event.previousIndex, event.currentIndex);
  }
  parseIndicators(parsed) {
    const indicators = parsed.split('#~#');
    const indicatorFlags = {
      "IPA": false,
      "Pulse": false,
      "Primary": false,
      "Confidential": false
    }
    indicators.forEach(indicator => {
      const split = indicator.split('=');
      if (split[0] == 'PROGRAM_NUMBER') {
        indicatorFlags["IPA"] = true;
      } else if (split[0] == 'CLIENT_PORTAL_IND' && split[1] == 'Y') {
        indicatorFlags["Pulse"] = true;
      } else if (split[0] == 'MARKET_POSITION' && split[1].includes('Primary')) {
        indicatorFlags["Primary"] = true;
      } else if (split[0] == 'CONFIDENTIALITY' && split[1] == 'Y') {
        indicatorFlags["Confidential"] = true;
      }
    });
    let html = '';
    if (indicatorFlags["IPA"]) {
      html = this.getIndicatorHtml("IPA");
    } else if (indicatorFlags["Pulse"]) {
      html = this.getIndicatorHtml("PULSE");
    } else if (indicatorFlags["Primary"]) {
      html = this.getIndicatorHtml("Primary");
    } else if (indicatorFlags["Confidential"]) {
      html = `<span style="background-color: #DCE2FF; margin: 0px 8px 0px 0px; border-radius: 35px; width: auto; padding: 0px 4px 0px 4px"><img style="width: 12px; height: 13px;" src="./assets/outline-remove_red_eye-24px.svg" /></span>`;
    }
    return html;
  }
  getIndicatorHtml(label) {
    return `<span  style="background-color: #DCE2FF; margin: 0px 8px 0px 0px; border-radius: 35px; padding: 2px 7px 1px 7px; position: relative; font-family: swissReOtFontRegular; font-size: 10px; color: #333333;">` + label + `</span>`;
  }
  redirectToClaim(claimNumber, diaryId?, diaryStatus?, region?) {
    if (diaryId && diaryStatus) {
      this.router.navigate([''], { queryParams: { claimNumber, redirect: true, diaryId, diaryStatus } });
    } else {
      if (region) {
        if (region === 'BRAZIL') {
          window.open( environment.environmentUrl + '#activityCorsoBR:/ClaimNum=' + claimNumber + '/REGION=' + region, '_blank');
        } else {
          window.open( environment.environmentUrl + '#activity:/ClaimNum=' + claimNumber + '/REGION=' + region, '_blank');
        }
      }
    }
  }
}
