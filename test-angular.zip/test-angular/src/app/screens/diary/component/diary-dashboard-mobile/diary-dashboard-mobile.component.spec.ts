import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DiaryDashboardMobileComponent } from './diary-dashboard-mobile.component';

describe('DiaryDashboardMobileComponent', () => {
  let component: DiaryDashboardMobileComponent;
  let fixture: ComponentFixture<DiaryDashboardMobileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DiaryDashboardMobileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DiaryDashboardMobileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
