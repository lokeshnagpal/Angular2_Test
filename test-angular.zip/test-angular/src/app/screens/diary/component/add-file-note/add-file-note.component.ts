import { Component, OnInit, Input, EventEmitter, Output, ChangeDetectorRef } from '@angular/core';
import { environment } from './../../../../../environments/environment';
import { DiaryService } from './../../diary.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ClientService } from 'src/app/services/client.service';
import { ActivatedRoute } from '@angular/router';
import { MatDialog } from '@angular/material';
import { ConfirmationDialog } from 'src/app/shared/ui/confirmation-dialog/confirmation-dialog.component';

@Component({
  selector: 'app-add-file-note',
  templateUrl: './add-file-note.component.html',
  styleUrls: ['./add-file-note.component.scss']
})
export class AddFileNoteComponent implements OnInit {

  public attributes: any;
  public lookupUrl: any;
  public optionValue: any;
  public attributeHolder: any = [];
  public lookupVal = [];
  public fileNoteForm: FormGroup;
  public category: any;
  public display: any;
  public status: any;
  public initFlagCategory: any;
  public initFlagDisplay: any;
  public showTooltip = false;
  
  public claimDescriptionData: any;
  public editorTemplateData: any;
  public data: any;
  public uploadUrl: string;
  public editorOptions: Object;
  public isUploading = false;
  public isIEOrEdge = false;

  public confirmationData = {
    new: {
      header: 'Discard new file note?',
      content: 'This will discard file note. Do you want to proceed?',
      yes: 'PROCEED',
      no: 'CANCEL'
    },
    edit: {
      header: 'You will loose unsaved changes.',
      content: 'This will discard any changes made to the file note. Do you want to proceed?',
      yes: 'PROCEED',
      no: 'CANCEL'
    }
  };

  @Input() public set editorData(data: any) {
    this.data = data;
    if (data) {
      this.initComponent();
    }
  }
  @Output() public editorEvent = new EventEmitter();

  constructor(public fb: FormBuilder, private clientService: ClientService,
  private ref: ChangeDetectorRef, private service: DiaryService, private route: ActivatedRoute, public dialog: MatDialog) {
    this.lookupUrl = environment.lookupUrl;
    let claimNumber;
    this.route.queryParams.subscribe(params => {
      this.uploadUrl = environment.uploadUrl;
      claimNumber = params['claimNumber'] ;
    });
    this.editorOptions = {
      embedlyKey: 'AA13A5C6D4xC2D2F2C2A29B4A5A8A1B1sg1Ti1LXd2URVJh1DWXG==',
      key: 'AA13A5C6D4xC2D2F2C2A29B4A5A8A1B1sg1Ti1LXd2URVJh1DWXG==' ,
      toolbarButtons: ['bold', 'italic', 'underline', 'strikeThrough','paragraphFormat', 'align', 'formatOL',
                                'formatUL', 'indent', 'outdent', 'undo', 'redo', 'insertTable', 'insertImage'],
      heightMin: 400,
      quickInsertButtons: ['embedly', 'image', 'table', 'ul', 'ol', 'hr'],
      enter: 'ENTER_BR',
      imageUploadParam: 'image_param',
      imageDefaultWidth: 200,
      
          // Set the image upload URL.
          imageUploadURL: environment.uploadUrl + '?CLAIM=' + claimNumber,
      
          // Set request type.
          imageUploadMethod: 'POST',
      
          // Set max image size to 5MB.
          imageMaxSize: 5 * 1024 * 1024,
      
          // Allow to upload PNG and JPG.
          imageAllowedTypes: ['jpeg', 'jpg', 'png'],
          // events: {
          //   'froalaEditor.image.beforeUpload': function (images) {
          //     // Return false if you want to stop the image upload.
          //     console.log('before upload');
          //   },
          //   'froalaEditor.image.uploaded': function (response) {
          //     // Image was uploaded to the server.
          //     console.log('uploaded', response);
          //   },
          //   'froalaEditor.image.inserted': function ($img, response) {
          //     // Image was inserted in the editor.
          //     console.log('inserted', response);
          //   },
          //   'froalaEditor.image.replaced': function ($img, response) {
          //     // Image was replaced in the editor.
          //     console.log('replaced', response);
          //   },
          //   'froalaEditor.image.error': function (error, response) {
          //     // Response contains the original server response to the request if available.
          //     console.log('error', error, response);
          //   }
          // }
    };
  }
  ngOnInit() {
    this.initFlagCategory = 2;
    this.initFlagDisplay = true;
    // this.isIEOrEdge = /msie\s|trident\/|edge\//i.test(window.navigator.userAgent);
  }
  initComponent() {
    this.claimDescriptionData = this.data.editorValue;
    this.editorTemplateData = this.data.editorTemplate;
    this.attributes = this.data.attributeData;
    this.fileNoteForm = this.createForm(this.attributes);
    for (const index in this.attributes) {
        this.getLookupData(this.attributes[index], this.attributes[index].dbColumnName);
    }
    this.attributeHolder = [];
    this.service.setFileNoteAttrValue(this.attributeHolder);
  }
  // public uploadImage(files: FileList) {
  //   this.isUploading = true;
  //   const formData = new FormData(); 
  //   formData.append('file', files.item(0), files.item(0).name); 
  //   this.clientService.setUrl(this.uploadUrl);
  //   this.clientService.testUpload(formData).subscribe(response => {
  //     if ( response.ok==true && response.status == 200 ) {
  //       try {
  //         this.claimDescriptionData += '<img src="'+response.json().link+'" width=200px>';
  //       } catch {
  //         this.isUploading = false;
  //       }
  //     }
  //     this.isUploading = false;
  //   });
  // }
  public createForm(obj) {
    const group = this.fb.group({});
    obj.forEach(control => group.addControl(control.dbColumnName, this.createControl(control)));
    return group;
  }
  public createControl(config) {
    const { isDisabled } = config;
    let value;
    let validation;
    const item = config;
    if (config.mandatory) {
        validation = Validators.required;
    }
    const control = this.fb.control({ 'value': value, 'disabled': isDisabled }, validation);
    control.valueChanges.subscribe(res => {
      this.formControlChange(control, config);
    });
    return control;
  }

  public getLookupData(data, controlName) {
    this.lookupVal = [];
    let urlForLookup = this.lookupUrl + '/' + data.source + '/' + data.group + '/';
    if (data.referenceDataValue && data.referenceDataValue.id && data.value == data.referenceDataValue.name){
        urlForLookup = urlForLookup + data.referenceDataValue.id;
    }
    this.clientService.setUrl(urlForLookup);
    this.clientService.setCardReqDetails(this.clientService.getCardReqDetails().cardName);
    this.clientService.getClientData().subscribe(response => {
        data.attributeOptions = response;
        if (this.initFlagDisplay== true) {
          this.buildAttributes();
        }
        if (this.data.edit && this.initFlagCategory > 0 && data.name == 'Category') {
          this.initFlagCategory--;
          this.fileNoteForm.controls[data.dbColumnName].setValue(this.data.category);
        }
    });
  }
  public buildAttributes() {
    const url = environment.lookupUrl + '/REFDATA/FILE_NOTE_DISPLAYED_IN/';
    this.clientService.setUrl(url);
    this.clientService.getFileNoteDisplayData().subscribe(response => {
      const options = [];
      let all;
      response.forEach(option => {
        if (option.id == 'EVERYWHERE') {
          all = option;
        } else {
          if (option.id === 'INTERNAL') {
            options.push({
                option,
                checked: this.data.edit ? false : true
            });
          } else {
            options.push({
                option,
                checked: false
            });
          }
        }
      });
      this.display = { options , everywhere: { option: all, checked: false} };
      this.initFlagDisplay = false;
      if ( this.data.edit) {
        this.setDisplayedIn(this.data.display);
      }
    });
  }
  public setDisplayedIn(displayedIn) {
    if (displayedIn && displayedIn.length > 0) {
      const split = displayedIn.split('#~#');
      this.display.options.forEach((option, index) => {
        split.forEach((display, i) => {
          if (i % 2 == 1) {
            if (display.toUpperCase() == 'everywhere'.toUpperCase()) {
              this.display.everywhere.checked = true;
              this.toggleAll(this.display.everywhere.checked, this.display.options);
              return;
            } else if (display.toUpperCase() == option.option.name.toUpperCase()) {
              this.display.options[index].checked = true;
            }
          }
        });
      });
    }
  }
  public toggleAll(value, options) {
    for (const option of options) {
        option.checked = value;
    }
  }

  fireEvent(description: any) {
    this.editorEvent.emit({
      description,
      display: this.display,
      taskId: this.data.taskId,
      category: this.category,
      status: this.status
    });
  }
  postDraft() {
    if(this.data.edit && this.data.status && this.data.status == "D") {
      this.status = "SD";
    } else {
      this.status = "S";
    }
    this.fireEvent(this.claimDescriptionData);
  }
  cancelDraft() {
    if (this.claimDescriptionData && this.claimDescriptionData.length > 0) {
      const dialogRef = this.dialog.open(ConfirmationDialog, {
        width: '20%',
        minWidth: '380px',
        panelClass: 'confirmation-panel',
        data: this.data.edit ? this.confirmationData.edit : this.confirmationData.new
      })
      dialogRef.afterClosed().subscribe(result => {
        if (result == 'yes') {
          this.fireEvent(null);
        }
      });
    } else {
      this.fireEvent(null);
    }
  }
  saveDraft() {
    this.status = "D";
    this.fireEvent(this.claimDescriptionData);
  }
  hasDisplay() {
    let checked = false;
    if (this.display && this.display.options) {
      if (this.display.everywhere.checked) {
        checked = true;
      } else {
        this.display.options.forEach(option => {
          if (option.checked) {
            checked = true;
          }
        });
      }
    }
    return checked;
  }
  // method triggered when change in form control
  public formControlChange(ctrl, attr){
      if (attr.type == 'LOOKUP'){
          this.getFilteredLookup(ctrl, attr);
          this.addLookupData();
      }
  }
  //method to assign the selected value ij aatributes
  public addLookupData(){
      this.attributeHolder = [];
      for (const attribute of this.attributes) {
              if (attribute.type == 'LOOKUP') {
                  const referenceObj: any = {
                      refDataId: '',
                      name: '',
                      code: ''
                  };
                  const lookupVal = this.fileNoteForm.controls[attribute.dbColumnName].value;
                  if (lookupVal && lookupVal != '') {
                          const itemFound = attribute.attributeOptions.find(val => val.name == lookupVal);
                          if (itemFound) {
                          referenceObj['code'] = itemFound.id ;
                          referenceObj['refDataId'] = itemFound.refDataId ;
                          referenceObj['name'] = itemFound.name ;
                      }
                      else{
                          if (attribute.referenceDataValue && attribute.referenceDataValue.name == lookupVal){
                              referenceObj['code'] = attribute.referenceDataValue.id ;
                              referenceObj['refDataId'] = attribute.referenceDataValue.refDataId ;
                              referenceObj['name'] = attribute.referenceDataValue.name ;
                          }
                      }
                  }
                  this.category = referenceObj['name'];
                  const diaryObj = {
                      attrId: attribute.attrId,
                      referenceDataValue: referenceObj,
                      dbColumnName: attribute.dbColumnName,
                      type: attribute.type,
                      value: lookupVal
                  };
                  this.attributeHolder.push(diaryObj);
              }
      }
      this.service.setFileNoteAttrValue(this.attributeHolder);
  }

  //method triggered when lookup input change
  public getFilteredLookup(ctrl, attr){
      this.optionValue = ctrl.value;
      let urlForLookup = this.lookupUrl + '/' + attr.source + '/' + attr.group + '/'; 
      if (attr.referenceDataValue && attr.referenceDataValue.id && ctrl.value == attr.referenceDataValue.name){
          urlForLookup = urlForLookup + attr.referenceDataValue.id;
      }else{
          delete attr['referenceDataValue'];
          urlForLookup = urlForLookup +  ctrl.value;
      }
      this.clientService.setUrl(urlForLookup);
      this.clientService.getClientData().subscribe(response => {
              attr.attributeOptions = response;
      }); 
  }

  public checkLookupSelectedValue(lokupAttr, ctrl, lookupData){
          if (lookupData.attributeOptions && lookupData.attributeOptions.length >= 0){
              const selLookupval = lookupData.attributeOptions.find(x => x.name == ctrl.value);
              if( !lookupData.referenceDataValue){
                if(lookupData.attributeOptions.length==0){
                    ctrl.setValue('');
                }
        }              
        }
  }

  public lookupOptionSelected(valSelected, config){
      this.fileNoteForm.controls[config.dbColumnName].setValue(valSelected.option.value);
      config['referenceDataValue'] = config.attributeOptions.find(x => x.name == valSelected.option.value);
  }
}
