import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddFileNoteComponent } from './add-file-note.component';

describe('AddFileNoteComponent', () => {
  let component: AddFileNoteComponent;
  let fixture: ComponentFixture<AddFileNoteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddFileNoteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddFileNoteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
