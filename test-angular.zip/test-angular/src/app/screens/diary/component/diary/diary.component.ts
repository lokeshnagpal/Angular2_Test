import { Constants } from './../../../../util/application.constants';
import { DiaryService } from './../../diary.service';
import { environment } from './../../../../../environments/environment';
import { Component, OnInit, Input, ChangeDetectorRef, HostListener } from '@angular/core';
import { Observable, of, from, Subscription } from 'rxjs';
import { ClientService } from './../../../../services/client.service';
import { ActivatedRoute, Router } from '@angular/router';
import { DiaryDialog } from './../diary-dialog/diary-dialog.component';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatSnackBar } from '@angular/material';
import { CommonTransformerService } from 'src/app/util/common-transformer.service';

@Component({
  selector: 'app-diary',
  templateUrl: './diary.component.html',
  styleUrls: ['./diary.component.scss']
})
export class DiaryComponent implements OnInit {

  public activeItem=Constants.OPEN_DIARY;
  public fileNoteActiveItem = Constants.POSTED;
  public saveItem=Constants.POSTED;
  public activeTabHeight;
  public showButton: boolean = true;
  public show='posted';
  public cardName=Constants.DIARY_DATES;
  public openDiaryRowItems: any=[];
  public closeDiaryRowItems;any=[];
  public loadTaskDetails: string;
  public claimNumber: any;
  public openDiaryAttr: any;
  public openDiaryComm: any;
  public closeDiaryAttr:any;
  public closeDiaryComm:any;
  public taskNumber: any;
  public sectionCode = Constants.DIARY_SECTION_CODE;
  public tabCardHeight: any;
  public tabId;
  public tabName;
  public tabIndex: number;
  public diaryLoadResponse:any=[];
  public rowWidth: any = "100%";
  private dialogAttributes: any;
  private closeTaskUrl: string;
  public claimSummaryTabId:any;
  public claimSummaryTabName:any;
  private showOverview: boolean = false;
  public postComments: boolean = false;
 public claimSummaryTabIndex:number;
 public loadTaskComments:any;
 public commObservable:Subscription;
  public tabData: any = {};
  public diaryDetails:any;
  public showZeroDiaryCard:boolean=false;
  public redirect = false;
  public diaryId: any;
  public taskUrl:any;
  public diaryStatus = 'Open';
  public activeDiaryStatus:String="KICKOFF";
  public taskType=Constants.DIARY_DATES_TAB_ID;
  public region:any;

  constructor(protected service: DiaryService, protected route: ActivatedRoute, protected clientService: ClientService, public dialog: MatDialog,
    protected ref: ChangeDetectorRef, public snackBar: MatSnackBar, public commonTransformerService: CommonTransformerService) {
    this.loadTaskDetails = environment.loadTaskDetails;
    this.loadTaskComments=environment.taskComments;
    this.taskUrl=environment.taskServiceUrl;
    this.closeTaskUrl = environment.taskServiceUrl;
    this.route
      .queryParams
      .subscribe(params => {
        this.claimNumber = params['claimNumber'];
        this.region=params['region']
        this.claimSummaryTabIndex=params['tabIndex'];
        this.redirect = params['redirect'];
        this.diaryId = params['diaryId'];
        this.diaryStatus = params['diaryStatus'];
      });
      this.tabIndex=this.claimSummaryTabIndex;
      if(this.tabIndex){
        this.tabId=Constants.FILE_NOTE_TAB_ID;
        this.tabName=Constants.FILE_NOTE_TAB_NAME;
        this.activeTabHeight=Constants.FILE_NOTE_CLASS;
        this.tabData=this.service.getTabDetails(this.tabId,this.tabName);
        this.service.setFileNoteComment(this.tabData);
        this.showButton=false;
      }
      else{
        this.tabId=Constants.DIARY_DATES_TAB_ID;
        this.tabName=Constants.DIARY_DATES_TAB_NAME;
        this.activeTabHeight=Constants.DIARY_DATE_CLASS;
      }
      this.commObservable= this.service.getCommentObservable().subscribe(taskNumber=>{
        this.clientService.setUrl(this.loadTaskComments +taskNumber+"/comments/");
        this.clientService.getClientData().subscribe(response=>{
          this.openDiaryComm=response.commentsGroup;
        })
      });
      if (this.diaryId && this.diaryStatus) {
        if (this.diaryStatus == 'Closed') {
          this.activeItem = 'Closed Diary';
          this.activeDiaryStatus="CLOSED"
        }
      }
      if (this.claimNumber) {
        this.getDiaryData();
      }
  }

  ngOnInit() {
    if (this.claimNumber) {
      this.getDiaryData();
    }
  }

  public getDiaryData(flag?) {
    this.showZeroDiaryCard=false;
    let tabObj = {
      'code': this.tabId,
      'name': this.tabName
    }
    let requestObject = {
      "claimNumber": this.claimNumber,
      "status": this.activeDiaryStatus,
       "type": tabObj
    }
    this.clientService.setCardReqDetails(this.cardName);
    this.clientService.setUrl(this.loadTaskDetails);
    this.clientService.postClientData(requestObject).subscribe(response => {
      if (response.length > 0) {
        this.diaryDetails = response;
        this.showZeroDiaryCard=false;
          this.openDiaryRowItems=[];
          this.closeDiaryRowItems=[];
          for(let item of this.diaryDetails){
            let objCreated=this.service.setDeskObjFormat(item);
            let convertedObj=this.service.objConverter(objCreated);
            if(this.activeItem==Constants.OPEN_DIARY){
              this.openDiaryRowItems.push(convertedObj);
            }
            else if(this.activeItem==Constants.CLOSED_DIARY){
              this.closeDiaryRowItems.push(convertedObj);
            }
          }
          this.service.setTaskNumber(this.diaryDetails[0].taskNumber);
          this.service.setStatus(this.diaryDetails[0].status);
          this.diaryLoadResponse=response;
        if(this.diaryDetails.length>0){
          if(this.activeItem==Constants.OPEN_DIARY && flag!=false){
            this.openDiaryAttr = this.diaryDetails[0].attributes;
            this.openDiaryComm =  this.diaryDetails[0].commentsGroup;
          }
          else if(this.activeItem==Constants.CLOSED_DIARY && flag!=false){
            this.closeDiaryAttr=this.diaryDetails[0].attributes;
            this. closeDiaryComm=this.diaryDetails[0].commentsGroup;
          }
        }   
      } else {  
        this.showZeroDiaryCard=true;
      }
    });
  }

  public getDiaryAttributes(taskNumber?,flag?){
    var itemFound;
    this.clientService.setCardReqDetails(this.cardName);
 this.clientService.setUrl(this.taskUrl+taskNumber+"?taskType="+this.taskType+"&region="+this.region);
 this.clientService.getClientData().subscribe(response=>{
  if(flag==false){
    this.getDiaryData(false);
  for(let item of this.diaryDetails){
    let objCreated=this.service.setDeskObjFormat(item);
    let convertedObj=this.service.objConverter(objCreated);
    if(this.activeItem==Constants.OPEN_DIARY){
      this.openDiaryRowItems.push(convertedObj);
    }
    else if(this.activeItem==Constants.CLOSED_DIARY){
      this.closeDiaryRowItems.push(convertedObj);
    }
  }
}
  if (response) {
    this.showZeroDiaryCard=false;
    if(response.taskNumber==taskNumber){
      this.service.setTaskNumber(taskNumber);
      this.service.setStatus(response.status);
      if(this.activeItem==Constants.OPEN_DIARY){
          this.openDiaryAttr =  response.attributes;
          this.openDiaryComm = response.commentsGroup;
      }
      else if(this.activeItem==Constants.CLOSED_DIARY){
          this.closeDiaryAttr =  response.attributes;
          this.closeDiaryComm = response.commentsGroup;
      }
    }

  } else {  
    this.showZeroDiaryCard=true;
  }
});
  }

  public getActiveTaskData(taskNumber: any) {
    this.getDiaryAttributes(taskNumber);
    this.service.setTaskNumber(taskNumber);
  }

  public tabChange(event) {
      if (event.tab.textLabel.includes(Constants.FILE_NOTES)) {
        this.showButton = false;
        this.tabIndex = event.index;
        this.tabId = Constants.FILE_NOTE_TAB_ID;
        this.tabName =Constants.FILE_NOTE_TAB_NAME;
        this.activeTabHeight=Constants.FILE_NOTE_CLASS ;  
        this.tabData=this.service.getTabDetails(this.tabId,this.tabName);
      }
      else if ( event.tab.textLabel == Constants.DIARY_DATES) {
        this.tabIndex = event.index;
        this.showButton = true;
        this.activeTabHeight=Constants.DIARY_DATE_CLASS;
        this.tabId =Constants.DIARY_DATES_TAB_ID;
        this.tabName = Constants.DIARY_DATES_TAB_NAME;
        this.getDiaryData();
      } else {
        this.navigateToPage(event.tab);
      }
  }

  public navigateToPage(tab) {
    console.log(tab);
    // switch (tab.textLabel) {
    //   case 'CLAIM SUMMARY':
    //     console.log('here');
    //     this.router.navigate(['claimSummary'], { queryParams: { claimNumber: this.claimNumber } });
    //     break;
    //   default:
    //     this.router.navigate(['diary'], { queryParams: { claimNumber: this.claimNumber } });
    // }
  }
  public diaryActiveItem(item) {
    if (item ==Constants.OPEN_DIARY) {
      this.activeItem = item;
      this.showButton = true;
      this.activeDiaryStatus="KICKOFF";
    }
    else if (item ==Constants.CLOSED_DIARY) {
      this.activeItem = item;
      this.activeDiaryStatus="CLOSED"
      this.showButton = true;
    }
    this.getDiaryData();
  }

  public fileActiveItem(item) {
    if (item ==Constants.POSTED) {
      this.fileNoteActiveItem = item;
    }
    else if (item ==Constants.SAVED_DRAFTS) {
      this.fileNoteActiveItem = item;
    }
    // this.getDiaryData();
  }

  public fileSaveItem(item) {
    if (item ==Constants.POSTED) {
      this.saveItem = item;
      this.show= "posted";
    }
    else if (item ==Constants.SAVED_DRAFTS) {
      this.saveItem = item;
      this.show = "drafts";
    }
    this.getDiaryData();
  }


  public addNew() {
    this.openDiaryDialog("Create New Diary", "CREATE");
  }

  // Edit Diary data for a given task number
  public editDiaryAction(taskNum) {
    this.openDiaryDialog("Edit Diary", "SAVE", taskNum);
  }

  public openDiaryDialog(headerNm: any, buttonNm: any, taskNum?: any) {
    taskNum ? this.clientService.setUrl(this.taskUrl +taskNum+"?taskType="+ this.sectionCode +  "&region="+this.region) : this.clientService.setUrl(this.taskUrl +"?taskType="+ this.sectionCode +  "&region="+this.region);
    this.clientService.getClientData().subscribe(response => {
      this.dialogAttributes = response.attributes;
      let dialogRef;
      dialogRef = this.dialog.open(DiaryDialog, {
        width: '44%',
        panelClass: 'diary-dialog-panel',
        data: {
          attributes: this.dialogAttributes, taskNumber: taskNum ? taskNum : null, tabId: this.tabId, tabName: this.tabName,
          claimNumber: this.claimNumber, headerName: headerNm, buttonName: buttonNm
        }
      })
      dialogRef.afterClosed().subscribe(result => {
        if (result == "Diary Created") {
          if (taskNum) {
            this.getDiaryAttributes(taskNum,false);  //for edit diary
          } else {
            this.getDiaryData(); // for create anew diary
            this.showZeroDiaryCard=false;
          }
        }
      });
    })
  }

  public createNewOpenDiary(){
    this.addNew();
  }

  //Actual close diary service call
  public callCloseDiary(taskNumber) {
    var task=[];
    task.push(taskNumber);
    let requestObject = {
      "taskNumbers": task,
      "action":"CLOSE"
    }
    this.clientService.setUrl(this.closeTaskUrl+'bulk');
    this.clientService.postClientData(requestObject).subscribe(response => {
      this.showMessage("Diary Closed Successfully", 3000);
      if (this.service.getRowitemCount() == 1) {
}
      this.getDiaryData();
      this.showDiaryListAction();
    });
  }

  public openDiaryOverview(rowItemValue, isTaskNumber?) {
    this.showOverview = true;
    const rowTaskNumber = isTaskNumber ? rowItemValue : rowItemValue.leftBottomItems.value;
    this.service.setTaskNumber(rowTaskNumber);
    this.getDiaryAttributes(rowTaskNumber);
  }
  public showDiaryListAction() {
    this.showOverview = false;
    this.getDiaryData();
  }

  public showNextOpenDiary(){
  let openTask=this.service.getTaskNumber();
  let taskIndex=this.diaryLoadResponse.findIndex(x=>x.taskNumber==openTask);
  let nextIndex=taskIndex+1;
  let nextTaskNumber;
  if(nextIndex>this.diaryLoadResponse.length-1){
    nextTaskNumber=this.diaryLoadResponse[0].taskNumber;
  }
  else{
    nextTaskNumber=this.diaryLoadResponse[nextIndex].taskNumber;
  }
  this.getDiaryAttributes(nextTaskNumber);
  this.showOverview=true;
  }

  public cancelPostEvent(event) {
    this.postComments = event;
  }

  public updatepostCommEvent(event) {
    this.postComments = event;
  }

  public showMessage(message: string, durationValue: number) {
    this.commonTransformerService.showMessage(message, durationValue);
  }

  ngOnDestroy(){
    this.commObservable.unsubscribe();
  }
}
