import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DiaryDesktopComponent } from './diary-desktop.component';

describe('DiaryDesktopComponent', () => {
  let component: DiaryDesktopComponent;
  let fixture: ComponentFixture<DiaryDesktopComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DiaryDesktopComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DiaryDesktopComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
