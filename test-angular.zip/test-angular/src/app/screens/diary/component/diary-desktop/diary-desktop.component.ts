import { Constants } from './../../../../util/application.constants';
import { environment } from './../../../../../environments/environment';
import { MatDialog, MatSnackBar } from '@angular/material';
import { ClientService } from './../../../../services/client.service';
import { ActivatedRoute } from '@angular/router';
import { DiaryService } from './../../diary.service';
import { DiaryComponent } from './../diary/diary.component';
import { Component, OnInit, ChangeDetectorRef, ViewChild } from '@angular/core';
import { CommonTransformerService } from 'src/app/util/common-transformer.service';

@Component({
  selector: 'app-diary-desktop',
  templateUrl: './diary-desktop.component.html',
  styleUrls: ['./diary-desktop.component.scss']
})
export class DiaryDesktopComponent extends DiaryComponent implements OnInit {

  public comments = [];
  public taskServiceUrl: string;
  public fileNoteSectionCode = Constants.FILE_NOTE_SECTION_CODE;
  public editorData: any;
  public description: any;
  public showAddNote = false;
  public category: any;
  public display: any;
  public taskId: any;
  public status: any;
  public newComment: any;
  public sidenavOpen = false;
  public filterObjectFileNotes: any;
  public filterObjectSavedDrafts: any;
  public displayArrayFileNotes: any;
  public displayArraySavedDrafts: any;
  public savedDraftsCount = 0;
  public isClaimSummaryLoaded = false;
  public fetchDiary = true;
  public desktopOverviewData: any;
  public clearFilter = false;
  public DISPLAY_ARRAY_DATA: any;
  public filterValuesObject: any = {
    "Posted": {
      filterCount: {},
      isFiltered: false
    },
    "Saved Drafts": {
      filterCount: {},
      isFiltered: false
    }
  };
  public removeDraft = false;

  constructor(public service: DiaryService, public route: ActivatedRoute, public clientService: ClientService,
    public commonTransformerService: CommonTransformerService, public dialog: MatDialog,
    public ref: ChangeDetectorRef, public snackBar: MatSnackBar) {
    super(service, route, clientService, dialog, ref, snackBar, commonTransformerService);
    this.taskServiceUrl = environment.taskServiceUrl;
   }

  ngOnInit() {
    this.fetchClaimSummary();
  }

  public fetchClaimSummary() {
    this.clientService.setUrl(environment.claimOverviewUrl + this.claimNumber);
    this.clientService.getClientData().subscribe(response => {
      this.desktopOverviewData = response;
      if (response.lastFileNote && response.lastFileNote.draftCount) {
        this.savedDraftsCount = response.lastFileNote.draftCount;
      }
      this.isClaimSummaryLoaded = true;
    });
  }
  public filterCountEvent(event) {
    if (event) {
      if (event.status == "S") {
        this.filterValuesObject['Posted'].filterCount = event;
      } else if (event.status == "D") {
        this.filterValuesObject['Saved Drafts'].filterCount = event;
      }
    }
  }
  public addFileNote() {
    this.showAddNote = true;
    this.clientService.setUrl(this.taskUrl +"?taskType="+ this.fileNoteSectionCode +"&region="+this.region);
    this.clientService.getClientData().subscribe(res => {
      const attributes = res.attributes;
      this.editorData = {
          editorValue: '',
          editorTemplate: {
            editorLabel: 'Description',
            cancel: 'CANCEL',
            save: 'POST'
          },
          attributeData: attributes,
          category: '',
          displayedIn: '',
          edit: false,
          taskId: null
      };
    });
  }
  public closeAddNote(event) {
    this.removeDraft = false;
    this.showAddNote = false;
    if (event.description) {
      this.description = event.description;
      this.display = event.display;
      this.taskId = event.taskId;
      this.category =  event.category;
      if (event.status == "SD") {
        this.status = "S";
        this.removeDraft = true;
        this.savedDraftsCount--;
      } else {
        this.status = event.status;
        if (this.status == 'D') {
          this.savedDraftsCount++;
        }
      }
      this.postFileNoteComm();
    } else {
      this.description = '';
    }
  }
  public editFileNote(event) {
    this.showAddNote = true;
    this.clientService.setUrl(this.taskUrl +"?taskType="+ this.fileNoteSectionCode +"&region="+this.region);
    this.clientService.getClientData().subscribe(res => {
      const attributes = res.attributes;
      this.editorData = {
        editorValue: event.comments[event.comments.length - 1].comment,
        editorTemplate: {
          editorLabel: 'Description',
          cancel: 'CANCEL',
          save: 'POST'
        },
        attributeData: attributes,
        category: event.category,
        display: event.displayedIn,
        edit: true,
        taskId: event.taskId,
        status: event.status,
        updatedDate: event.updatedDate ? event.updatedDate : event.createdDate
      };
    });
  }
  filterFileNotes(event) {
    if (this.fileNoteActiveItem == 'Posted') {
      this.filterObjectFileNotes = event;
    } else {
      this.filterObjectSavedDrafts = event;
    }
  }
  setIsFiltered(event) {
    this.filterValuesObject[this.fileNoteActiveItem].isFiltered = event;
    this.clearFilter = false;
    this.ref.detectChanges();
  }
  setDisplayArray(event) {
    if (this.fileNoteActiveItem == 'Posted') {
      this.displayArrayFileNotes = event;
    } else {
      this.displayArraySavedDrafts = event;
    }
  }
  clearFilters() {
    this.clearFilter = true;
  }
  getSelectedDiary() {
    if (this.fetchDiary && this.openDiaryRowItems && this.openDiaryRowItems.length>0 && this.diaryId) {
      this.getActiveTaskData(this.diaryId);
      this.fetchDiary = false;
    }
    return true;
  }
  getDisplayValue(display) {
    let displayedIn = '';
    if (display.everywhere.checked == false) {
      display.options.forEach(option => {
        if (option.checked) {
          if (displayedIn == '') {
            displayedIn += option.option.id + '#~#' + option.option.name;
          } else {
            displayedIn += '#~#' + option.option.id + '#~#' + option.option.name;
          }
        }
      });
    } else {
      displayedIn = display.everywhere.option.id + '#~#' + display.everywhere.option.name;
    }
    return displayedIn;
  }
  //method to post the file note comment
  public postFileNoteComm() {
    let comments = this.description;
    this.comments = [];
    let editedContent = comments.replace(/(<p>|<\/p>)/g, '');
    let fileAttribute = this.service.getFileNoteAttrValue();
    if (editedContent) {
      let obj = {
        'comment': editedContent,
      }
      this.comments.push(obj);
      let tabObj = {
       'code': this.tabData.tabId,
       'name': this.tabData.tabName
      }
      let displayedIn = this.getDisplayValue(this.display);
      let requestObject: any = {
        'claimNumber': this.claimNumber,
        'comments': this.comments,
        'attributes': fileAttribute,
        'type': tabObj,
        'displayedIn': displayedIn,
        'taskId': this.taskId,
        'status': this.status
      }
      this.clientService.setUrl(this.taskServiceUrl);
      this.clientService.postClientData(requestObject).subscribe(response => {
        this.showMessage('File Note saved successfully', 3000)
        this.service.setFileNoteComment(this.tabData);
        this.newComment = {
          taskComment: response,
          taskId: this.taskId,
          status: this.status,
          removeDraft: this.removeDraft
        };
      });
    }
  }
  public  showMessage(message: string, durationValue: number) {
    this.commonTransformerService.showMessage(message, durationValue);
  }
}
