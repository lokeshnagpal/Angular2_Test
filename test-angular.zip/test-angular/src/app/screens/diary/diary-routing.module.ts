import { DiaryContainerComponent } from './diary-container/diary-container.component';
import { DiaryComponent } from './component/diary/diary.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DiaryDashboardComponent } from './component/diary-dashboard/diary-dashboard.component';

const routes: Routes = [

  {
    path: '',
    component: DiaryContainerComponent,
    children: [
    ]
  },
  {
    path: 'dashboard',
    component: DiaryDashboardComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DiaryRoutingModule { }
