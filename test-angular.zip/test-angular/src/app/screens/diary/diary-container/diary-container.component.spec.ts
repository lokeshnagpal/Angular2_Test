import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DiaryContainerComponent } from './diary-container.component';

describe('DiaryContainerComponent', () => {
  let component: DiaryContainerComponent;
  let fixture: ComponentFixture<DiaryContainerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DiaryContainerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DiaryContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
