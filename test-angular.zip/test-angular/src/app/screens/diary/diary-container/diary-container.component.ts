import { ApplicationStateService } from './../../../util/application.state.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-diary-container',
  templateUrl: './diary-container.component.html',
  styleUrls: ['./diary-container.component.scss']
})
export class DiaryContainerComponent implements OnInit {

  constructor(public applicationStateService:ApplicationStateService ) {
    

   }

  ngOnInit() {
  }

}
