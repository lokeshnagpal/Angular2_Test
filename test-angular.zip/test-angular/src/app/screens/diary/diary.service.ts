import { RowItems } from './../../data/RowItem';
import { TaskDetail } from './../../data/TaskDetail';
import { Injectable } from '@angular/core';
import { createEpicMiddleware } from 'redux-observable';
import {Observable,of, from,Subject} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DiaryService {

  private taskDetails:any;
  public leftTopItems :any;
  public leftBottomItems :any;
  public rightTopItems :any;
  public rightBottomItems :any;
  public taskNumber:any;
  public status:any;
  private leftBottomValue=[];
  public leftTopValue=[];
  public fileNoteAttr:any;
  private comment = new Subject<any>();
  private postComment = new Subject<any>();
  private fileNotesComment=new Subject<any>();
  public rowitemcount: any;
  public currentSetting: string = 'default';

  constructor() { 

  }
    
  public getTabDetails(diaryTabId,diaryTabName){
    let diaryTabData = {
          'tabName': diaryTabName, 'tabId': diaryTabId
        }
        return diaryTabData;
  }

  public getCurrentSetting() {
    return this.currentSetting;
  }

  public setCurrentSetting(id) {
    if (id && id.length > 0) {
      this.currentSetting = id;
    }
  }

  public setDeskObjFormat(item){
         let obj1={name:'category',value:item.category,desc:'Claim in Dispute desc',isIcon:false,display:true};
            let obj2={name:'priority',value:item.priority,desc:'Claim desc priority',isIcon:true,display:true};
            let obj3={name:'taskNumber',value:item.taskNumber,desc:'Claim desc',isIcon:false,display:true};
            let obj4={name:'dueDate',value:item.dueDate,desc:'Due date desc',isIcon:false,display:true};
            let obj5={name:'assignee',value:item.assignee,desc:'Full name of the user',isIcon:false,display:true};
        let objFormat={
          item1:obj1,  item2:obj2, item3:obj3, item4:obj4, item5:obj5   
        }
        return objFormat;
  }

  public setMobRowGroupObj(item){
        let obj1={name:'category',value:item[3].value,desc:'Claim desc category',isIcon:false,display:true};
            let obj2={name:'priority',value:item[2].value,desc:' claim priority',isIcon:false,display:false};
            let obj3={name:'Last Updated',value:item[0].dateValue,desc:'Claim desc last updated date',isIcon:false,display:true};
            let obj4={name:'Due Date',value:item[1].dateValue,desc:'Due date desc',isIcon:false,display:true};
            let obj5={name:'assignee',value:item[4].value,desc:'Full name of the user',isIcon:false,display:true};
            let objRowGroupFormat={
              item1:obj1,  item2:obj2, item3:obj3, item4:obj4, item5:obj5   
            }
            return objRowGroupFormat;
  }

  public setMobRowObj(item){
      let obj1={name:'category',value:item.category,desc:'Claim in Dispute desc',isIcon:false,display:true};
      let obj2={name:'priority',value:item.priority,desc:'Claim desc priority',isIcon:true,display:true};
      let obj3={name:'updatedDate',value:item.updatedDate,desc:'Claim desc',isIcon:false,display:true};
      let obj4={name:'dueDate',value:item.dueDate,desc:'Due date desc',isIcon:false,display:true};
      let obj5={name:'assignee',value:item.assignee,desc:'Full name of the user',isIcon:false,display:true};
      let objRowFormat={
        item1:obj1,  item2:obj2, item3:obj3, item4:obj4, item5:obj5   
      }
      return objRowFormat;
  }

  public  objConverter(itemObj){
    this.leftTopItemsConverter(itemObj.item1,itemObj.item2);
    this.leftBottomItemsConverter(itemObj.item3);
    this.rightTopItemsConverter(itemObj.item4);
    this.rightBottomItemsConverter(itemObj.item5);
    let obj={
      leftTopItems:this.leftTopItems,
      leftBottomItems:this.leftBottomItems,
      rightTopItems:this.rightTopItems,
      rightBottomItems:this.rightBottomItems
    }
return obj;
}

  public leftTopItemsConverter(item1,item2){
    this.leftTopValue=[];
    let leftTopObj={};
    leftTopObj["name"]=item1.name;
    leftTopObj["value"]=item1.value;
    leftTopObj["desc"]=item1.desc;
    leftTopObj["isIcon"]=item1.isIcon;
    leftTopObj["display"]=item1.display;

    let leftTopObj1={}
    leftTopObj1["name"]=item2.name;
    leftTopObj1["value"]=item2.value;
    leftTopObj1["desc"]=item2.desc;
    leftTopObj1["isIcon"]=item2.isIcon;
    leftTopObj1["display"]=item2.display;
    this.leftTopValue.push(leftTopObj,leftTopObj1);
    this.leftTopItems=this.leftTopValue;

  }

  public leftBottomItemsConverter(item3){
    let leftBottomObj={};
    leftBottomObj["name"]=item3.name;
    leftBottomObj["value"]=item3.value;
    leftBottomObj["desc"]=item3.desc;
    leftBottomObj["isIcon"]=item3.isIcon;
    leftBottomObj["display"]=item3.display;
    this.leftBottomItems=leftBottomObj;
  }

  public rightTopItemsConverter(item4){
    let rightTopObj={};
    rightTopObj["name"]=item4.name;
    rightTopObj["value"]=item4.value;
    rightTopObj["desc"]=item4.desc;
    rightTopObj["isIcon"]=item4.isIcon;
    rightTopObj["display"]=item4.display;
    this.rightTopItems=rightTopObj;
  }

  public rightBottomItemsConverter(item5){
    let rightBottomObj={};
    rightBottomObj["name"]=item5.name;
    rightBottomObj["value"]=item5.value;
    rightBottomObj["desc"]=item5.desc;
    rightBottomObj["isIcon"]=item5.isIcon;
    rightBottomObj["display"]=item5.display;
    this.rightBottomItems=rightBottomObj;
  }
  
  public setTaskNumber(obj){
    this.taskNumber=obj;
  }
  public getTaskNumber(){
    return this.taskNumber;
  }

  public setRowitemCount(obj){
    this.rowitemcount=obj;
  }
  public getRowitemCount(){
    return this.rowitemcount;
  }

  public setStatus(obj){
    this.status=obj;
  }
  public getStatus(){
    return this.status;
  }

  public setFileNoteAttrValue(obj){
   this.fileNoteAttr=obj;
  }
  public getFileNoteAttrValue(){
   return this.fileNoteAttr;
  }

  public setCommentObservable(obj:any) {
    this.comment.next(obj);   
}
public getCommentObservable(): Observable<any> {
  return this.comment.asObservable();
}

public setPostCommObservable(obj:any){
  this.postComment.next(obj);
}
public getPostCommObservable():Observable<any>{
  return this.postComment.asObservable();
}

public setFileNoteComment(res){
  this.fileNotesComment.next(res);
}
public getFileNoteComment():Observable<any>{
  return this.fileNotesComment.asObservable();
}
}
