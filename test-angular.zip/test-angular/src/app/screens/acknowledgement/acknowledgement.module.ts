import { AcknowledgementRoutingModule } from './acknowledgement-routing.module';
import { SharedModule } from './../../shared/shared.module';

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AcknowledgementComponent } from './acknowledgement.component';
// import { QuillEditorModule } from 'ngx-quill-editor';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    AcknowledgementRoutingModule
    // QuillEditorModule
  ],

  declarations: [
    AcknowledgementComponent,
  
  ],

})
export class AcknowledgementModule { }



