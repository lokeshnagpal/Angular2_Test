import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ClientService } from './../../services/client.service';
import { environment } from './../../../environments/environment';
import { Component, OnInit } from '@angular/core';


@Component({
    selector: 'acknowledgement',
    templateUrl: './acknowledgement.component.html',
    styleUrls: ['acknowledgement.component.scss'],
})
export class AcknowledgementComponent implements OnInit {
    
    public ackTemplateUrl: any;
    public ackSecName:any;
    public lookupVal: any = [];
    public ackAttributes:any;
    public ackForm:FormGroup;
    public lookupUrl: any;
    public optionValue: any;
    
    constructor(private clientService: ClientService,public fb: FormBuilder) {
        this.ackTemplateUrl = environment.ackTemplateUrl;
        this.lookupUrl = environment.lookupUrl;    
        
    }

    ngOnInit() {
      this.clientService.setUrl(this.ackTemplateUrl);
      this.clientService.getClientData().subscribe(res=>{
       this.ackSecName=res[0].sectionName;
       this.ackAttributes=res[0].attributes;
       this.ackForm=this.createForm(this.ackAttributes);
      })
    }

  public createForm(obj){
    const group = this.fb.group({});
    obj.forEach(control => group.addControl(control.dbColumnName, this.createControl(control)));
    return group;
  }

  public createControl(config){
    const { isDisabled } = config;
    let value;
    let validation;
    if (config.mandatory) {
        validation = Validators.required;
    }
    let control = this.fb.control({ 'value': value, 'disabled': isDisabled }, validation);
    control.valueChanges.subscribe(res => {
      this.controlChange(control, config);
    })
    return control;
  }

    // method triggered when change in form control
    public controlChange(ctrl, attr) {
      if (attr.attributeType == 'SIMPLELOOKUP' || attr.attributeType == 'LOOKUP' || attr.attributeType == 'EMAILMULTILOOKUP') {
        this.getFilteredLookup(ctrl, attr);    
      }
    }

      //method triggered when lookup input change
  public getFilteredLookup(ctrl, attr) {
    this.optionValue = ctrl.value;
    let urlForLookup = this.lookupUrl + '/' + attr.attributeAlias + '/' + attr.attributeGroup + '/'
    if (attr.referenceDataValue && attr.referenceDataValue.id && ctrl.value == attr.referenceDataValue.name) {
      urlForLookup = urlForLookup + attr.referenceDataValue.id;
    } else {
      delete attr['referenceDataValue']
      urlForLookup = urlForLookup + ctrl.value;
    }
    this.clientService.setUrl(urlForLookup);
    this.clientService.getClientData().subscribe(response => {
      attr.attributeOptions = response;
    })
  }

  public checkLookupSelectedValue(lokupAttr, ctrl, lookupData) {
    if (lookupData.attributeOptions && lookupData.attributeOptions.length >= 0) {
      let selLookupval = lookupData.attributeOptions.find(x => x.name == ctrl.value);
      if (!selLookupval && !lookupData.referenceDataValue) {
        ctrl.setValue('');
      }
    }
  }

  public lookupOptionSelected(valSelected, config) {
    this.ackForm.controls[config.dbColumnName].setValue(valSelected.option.value);
    config['referenceDataValue'] = config.attributeOptions.find(x => x.name == valSelected.option.value);   
  }

  public getLookupData(data, controlName) {
    this.lookupVal = [];
    let urlForLookup = this.lookupUrl + '/' + data.attributeAlias + '/' + data.attributeGroup + '/';

    if (data.referenceDataValue && data.referenceDataValue.id && data.value == data.referenceDataValue.name) {
      urlForLookup = urlForLookup + data.referenceDataValue.id;
    }
    this.clientService.setUrl(urlForLookup);
    this.clientService.getClientData().subscribe(response => {
      data.attributeOptions = response;
    })
  }
}