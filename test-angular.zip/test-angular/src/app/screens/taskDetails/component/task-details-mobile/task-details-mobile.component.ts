import { Component, OnInit, ViewChild } from '@angular/core';
import { ClientService } from './../../../../services/client.service';
import { environment } from './../../../../../environments/environment';
import { Tab } from '../../../../shared/ui/model/tabs-with-actions';
import { ActivatedRoute, Router } from '@angular/router';
import { CurrencyPipe } from '@angular/common';
import { CommonTransformerService } from './../../../../util/common-transformer.service';
@Component({
  selector: 'app-task-details-mobile',
  templateUrl: './task-details-mobile.component.html',
  styleUrls: ['./task-details-mobile.component.scss']
})
export class TaskDetailsMobileComponent implements OnInit {

  public taskNumber: any;
  public docUrl: String;
  public readDocUrl: String;
  public documents: any;
  public alldocuments: any;
  public docDetails: any;
  public docLength: number;
  public taskOverviewDetails:any={}
 public actionButtons;
  public financeData;
  public taskLogs:any
  public index
  public i = 5;
  public t=3;
  tabOptions: Tab[] = [{
    displayTitle: "Task Details",
    navigationLink: "taskDetails"}];
public footerActionName='MORE ACTIONS'
public footerCommentsName
public postComments=false
public showFooterAction=true
public moreOptionsList
public allTaskLogs;
public taskLogLength;
public newTaskArray;
  constructor(protected route: ActivatedRoute, private clientService: ClientService, private currencyPipe:CurrencyPipe, public commonTransformerService: CommonTransformerService) {
    this.docUrl = environment.documentUrl;
    this.readDocUrl = environment.streamingServlet;
    this.route.queryParams.subscribe(params => {
        this.taskNumber = params['taskNumber'];
      });
  }

  ngOnInit() {
    //Read the documents
    this.clientService.setUrl(this.docUrl + 'TASKNUMBER/' + this.taskNumber);
    this.clientService.getClientData().subscribe(response => {
      this.alldocuments = [...response];
      this.documents = [...response];
      this.documents.splice(5)
      this.docLength = this.alldocuments.length
      // console.log(this.docLength)
    })

  //Task overview details
    this.clientService.setUrl(environment.taskOverviewUrl + this.taskNumber)
    this.clientService.getClientData().subscribe(response => {
   this.subscribeToData(response)
   this.taskOverviewDetails=response.sectionDetails[0].attributes
this.newTaskArray=response.sectionDetails[0].attributes.splice(3,6)
console.log(this.newTaskArray)
console.log(this.taskOverviewDetails)
    })
  

    //Read the task logs
    this.clientService.setUrl(environment.taskComments + this.taskNumber+"/comments/")
    this.clientService.getClientData().subscribe(response => {
   this.allTaskLogs=[...response.comments]
   this.taskLogs = [...response.comments];
   this.taskLogs.splice(3)
   this.taskLogLength = this.allTaskLogs.length
    })

   //Action buttons 
    this.clientService.setUrl(environment.actionButtonsUrl+this.taskNumber)
    this.clientService.getClientData().subscribe(response =>{
      this.actionButtonsTransform(response.actionButtons) 
      console.log(response.actionButtons)
    })
  }
 
  public actionButtonsTransform(data){
    let i=0
    this.moreOptionsList= data.map(el=>{
      ++i;
      if(!el.primary){
        return {
          "name": el.buttonName,
        "icon": this.iconName(el.buttonCode),
        "action": el.buttonName, 
        "show":true,
   }
      }else{
        this.footerCommentsName= el.buttonName.toUpperCase();
        this.index=i
     return{
       "remove":"yes"
     }
      }
}

)
this.moreOptionsList.splice(this.index-1,1)
let fixbutton={
  "name": "Go to my next task",
"icon":{name:'skip_next',
type:'icon'},
"action": 'next task', 
"show":true,
}
this.moreOptionsList.push(fixbutton)
  }

  public iconName(buttonCode){
    switch(buttonCode){
      case ("Save") : {
        return {name:'save',
                    type:'icon'}
      }
      case ("DECLINE") : {
        return {name:'close',
        type:'icon'}
      }
      case ("ADDINFOREQUIRED") : {
        return {name:'arrow_back',
        type:'icon'}
      }
      case ("Delegate") : {
        return {name:'compare_arrows',
        type:'icon'}
      }
    }
  }

private serviceDataToComponentData(serviceData) {
 // const json={}
 console.log(serviceData)
// serviceData.forEach(data => {
// this.taskOverviewDetails[data.dbColumnName] = { name: data.name,
// value: data.value
// }
// }); 
  }

  subscribeToData(res){
    if(Object.keys(res.financials).length != 0){ 
      if (res.financials.summary.background == undefined) {
        res.financials.summary.background = ['#21efb4', '#a2a7ae'];
      }
      this.financeData = res.financials;  
      this.financeData.summary.name = "Finance_Info"
      // console.log(this.financeData)
     } 
    }

  public openDocument(docId) {
    this.docDetails = this.readDocUrl + '?docId=' + docId + '&appName=NATIVE&openInline=Y ';
    window.open(this.docDetails);
  }

  public viewdoc(activity) {
    this.documents = [...this.alldocuments]
    switch (activity) {
      case 'more': {
        this.i = this.i + 5
        break;
      }
      case 'less': {
        this.i = 5;
        break;
      }
    }
    this.documents.splice(this.i)
  }

  public viewLog(activity) {
    this.taskLogs = [...this.allTaskLogs]
    switch (activity) {
      case 'more': {
        this.t = this.t + 3
        break;
      }
      case 'less': {
        this.t = 3;
        break;
      }
    }
    this.taskLogs.splice(this.t)
  }
  mobDiaryEvent(evt){
//  console.log(evt)
  }
  postCommEvent(evt){

  }
}



 //   this.moreOptionsList=  [
  //     {name: "All Diaries in Claim",
  //      icon: "arrow_back",
  //      action:"allDiary",
  //      show:true
  //     },
  //     {name: "Edit Diary",
  //     icon: "edit",
  //     action:"editDiary",
  //     show: true
  //    },
  //    {name: "Close Diary",
  //    icon: "close",
  //    action: "closeDiary",
  //    show: true
  //   },
  //   {name: "Go to my next Open Diary",
  //   icon: "skip_next",
  //   action:"nextOpenDiary",
  //   show:true,
  //  }
  //   ]