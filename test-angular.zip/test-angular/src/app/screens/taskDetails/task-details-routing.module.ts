import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {TaskDetailsMobileComponent} from './component/task-details-mobile/task-details-mobile.component';

const routes: Routes = [

  {
    path: '',
    component:TaskDetailsMobileComponent,
    children: [
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TaskDetailsRoutingModule { }
