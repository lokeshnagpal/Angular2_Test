import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from './../../shared/shared.module';
import { TaskDetailsRoutingModule } from './task-details-routing.module';
import { TaskDetailsMobileComponent } from './component/task-details-mobile/task-details-mobile.component';
import { CurrencyPipe } from '@angular/common';
@NgModule({
  declarations: [TaskDetailsMobileComponent],
  imports: [
    CommonModule,
    SharedModule,
    TaskDetailsRoutingModule
  ],
  providers:[CurrencyPipe]
})
export class  TaskDetailsModule{ }
