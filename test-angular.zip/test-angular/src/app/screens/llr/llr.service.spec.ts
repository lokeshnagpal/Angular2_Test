import { TestBed } from '@angular/core/testing';

import { LLRService } from './llr.service';

describe('LLRService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: LLRService = TestBed.get(LLRService);
    expect(service).toBeTruthy();
  });
});
