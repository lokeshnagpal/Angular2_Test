import { ApplicationStateService } from './../../../util/application.state.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-llr-container',
  templateUrl: './llr-container.component.html',
  styleUrls: ['./llr-container.component.scss']
})
export class LLrContainerComponent implements OnInit {

  constructor(public applicationStateService:ApplicationStateService) { }

  ngOnInit() {
    
  }

}
