import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LLrContainerComponent } from './llr-container.component';

describe('LLrContainerComponent', () => {
  let component: LLrContainerComponent;
  let fixture: ComponentFixture<LLrContainerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LLrContainerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LLrContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
