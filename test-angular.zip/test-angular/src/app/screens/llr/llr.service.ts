import { Constants } from './../../util/application.constants';
import { Observable } from 'rxjs/internal/Observable';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';
import { Injectable, EventEmitter, Output } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LLRService {
  public taskTypeData: any
  public taskNumber: any;
  public queryParams: any;
  public taskTypeValue = new BehaviorSubject<any>({});
  // public overviewData = new BehaviorSubject<any>({});
  public sectionAttrHolderArray: any = [];
  public taskDetails: any;
  public dynamicAttributesArray: any = [];
  public formValidateResponse = new BehaviorSubject<any>({});
  public financialInfo: any;
  public calculatedFinancialInfo: any;
  public status: any;
  public taskCreated: boolean = false;
  public roundTableSummarySectionsArray: any = [];
  public taskNumbersList: any;
  public tabChangeEvent: boolean = false;
  public isComposeMeeting:boolean=false;
  public isLoadTask:boolean=false;
  getStaticSectionData() {
    const sectionDetails = [
      {
        "sectionName": "Final Approver",
        "attributes": [
          {
            "attributeDataId": 0,
            "attributeOptions": [

            ],
            "attrId": 3133,
            "attrRules": [

            ],
            "columnIndex": 3,
            "dbColumnName": "FINAL_REVIEWER",
            "editableWrapper": false,
            "group": "CLAIMS_HANDLER",
            "isExternalLink": false,
            "isPopUp": false,
            "isValueHref": false,
            "mandatory": false,
            "name": "Final Reviewer",
            "readOnly": false,
            "rowIndex": 3,
            "secAttrMapId": "3147",
            "source": "CD",
            "tempMandatory": false,
            "tempReadOnly": false,
            "type": "SIMPLELOOKUP",
            "tempOptional": false,
            "prePopulated": false,
            "showTextRed": false,
            "infoIconInd": false,
            "focusFlag": false,
            "commentsModified": false,
            "sectionId": "156",
            "sectionName": "Final Approver",
            "sectionCode": "FINAL_APPROVER",
            "collapsedInd": false,
            "metaData": {

            },
            "dynamicLoad": false,
            "futureDateError": false,
            "hidden": false,
            "hyperLink": false,
            "progReadOnly": false,
            "searchable": false,
            "mouseOutEvent": false,
            "editForTable": false,
            "groupingAllowed": false
          }
        ],
        "disableForm": false,
        "sectionPosition": 0,
        "collapsedInd": false,
        "sectionCode": "FINAL_APPROVER",
        "activityDetailsTab": false
      },
      {
        "sectionName": "Delegate",
        "attributes": [
          {
            "attributeDataId": 0,
            "attributeOptions": [

            ],

            "dbColumnName": "DELEGATED_TO",
            "group": "CLAIMS_HANDLER",
            "name": "Delegate To",
            "source": "CD",
            "type": "SIMPLELOOKUP",
            "sectionName": "Delegate",
            "sectionCode": "DELEGATED_TO",
            "collapsedInd": false,
            "mandatory": false
          }
        ],
        "sectionCode": "DELEGATED_TO",
      },
      {
        "sectionName": "Mailbox Details",
        "attributes": [
          {
            "attributeDataId": 0,
            "attributeOptions": [

            ],
            "attrId": 3170,
            "attrRules": [

            ],
            "columnIndex": 3,
            "dbColumnName": "MAILBOX_USER",
            "editableWrapper": false,
            "group": "CLAIMS_HANDLER",
            "isExternalLink": false,
            "isPopUp": false,
            "isValueHref": false,
            "mandatory": false,
            "name": "Send to",
            "readOnly": false,
            "rowIndex": 3,
            "secAttrMapId": "3170",
            "source": "CD",
            "tempMandatory": false,
            "tempReadOnly": false,
            "type": "SIMPLELOOKUP",
            "tempOptional": false,
            "prePopulated": false,
            "showTextRed": false,
            "infoIconInd": false,
            "focusFlag": false,
            "commentsModified": false,
            "sectionId": "156",
            "sectionName": "Mailbox Details",
            "sectionCode": "LLR_MAILBOX_DETAILS",
            "collapsedInd": false,
            "metaData": {

            },
            "dynamicLoad": false,
            "futureDateError": false,
            "hidden": false,
            "hyperLink": false,
            "progReadOnly": false,
            "searchable": false,
            "mouseOutEvent": false,
            "editForTable": false,
            "groupingAllowed": false
          }
        ],
        "disableForm": false,
        "sectionPosition": 0,
        "collapsedInd": false,
        "sectionCode": "LLR_MAILBOX_DETAILS",
        "activityDetailsTab": false
      }

    ]

    return sectionDetails;
  }
  getTaskDetails(taskNumber: string) {

    const sections = [
      {
        "name": "About the Insured",
        "sectionType": "FORM"
      },
      {
        "name": "Participants",
        "sectionType": "PARTICIPANT"
      },
      {
        "name": "Comment",
        "sectionType": "POST_COMMENT"
      },
      {
        "name": "Task log",
        "sectionType": "TASK_HISTORY"
      }
    ];
    return sections;

  }

  getPartDialogData() {
    const list = [
      {
        "name": "Alvis Douglas",
        "id": "123"
      },
      {
        "name": "Alexandrine Rath",
        "id": "456"
      },
      {
        "name": "Alejandra Pollich",
        "id": "789"
      },
      {
        "name": "Alexandrine Rath",
        "id": "012"
      },
      {
        "name": "Alejandra Pollich",
        "id": "487"
      },
      {
        "name": "Alejandra Pollich",
        "id": "646"
      },
      {
        "name": "Puja",
        "id": "789"
      },
      {
        "name": "Raghavendra Bhatt",
        "id": "785"
      },
      {
        "name": "Sabin Sam",
        "id": "763"
      },
      {
        "name": "Ramkumar Shanmugavel Periasamy",
        "id": "757"
      },
    ]
    return list;
  }

  public setTaskTypeValue(obj) {

    //  if (obj.pageName == "LLR_RT") {    
    obj.type.code = Constants['LLR_GENERATE_ROUND_TABLE_CODE'];
    obj.type.name = Constants['LLR_GENERATE_ROUND_TABLE_NAME'];
    // obj.pageName = obj.pageName;
    // } 
    this.taskTypeValue.next(obj);
    this.taskTypeData = obj;

  }
  public getTaskTypeValue() {
    return this.taskTypeData;
  }

  public setQueryParams(obj) {
    this.queryParams = obj;
  }
  public getQueryParams() {
    return this.queryParams;
  }


  public setFormAttributes(obj, sectionName?) {
    if (obj === null) {
      this.dynamicAttributesArray = [];
    }
    else {
      if (this.tabChangeEvent) {
        this.dynamicAttributesArray = [];
        this.tabChangeEvent = false;
      }
      obj.sectionName = sectionName;
      if (this.dynamicAttributesArray.length > 0) {
        const index = this.dynamicAttributesArray.findIndex(x => x.sectionName === sectionName);
        if (index != -1) {
          this.dynamicAttributesArray[index] = obj;
        } else {
          this.dynamicAttributesArray.push(obj)
        }
      } else {
        this.dynamicAttributesArray.push(obj);
      }
    }

  }
  public getFormAttributes() {
    return this.dynamicAttributesArray;
  }
  public setTabChangeEvent(value) {
    this.tabChangeEvent = value;
  }


  public setTaskDetailsData(obj) {

    if (Object.keys(obj).length > 0) {
      if (this.sectionAttrHolderArray.length > 0) {
        let index = this.sectionAttrHolderArray.findIndex(x => x.sectionName === obj.sectionName);
        if (index != -1) {
          this.sectionAttrHolderArray[index] = obj;
        } else {
          this.sectionAttrHolderArray.push(obj)
        }
      }
      else {
        this.sectionAttrHolderArray.push(obj);
      }

      if (obj.sectionCode === Constants.DELEGATED_TO) this.delegateTo();
      // console.log("create attribute map",  this.sectionAttrHolderArray);
    }
    else {
      this.sectionAttrHolderArray = [];
    }
    // console.log("attribute map", this.sectionAttrHolderArray)
  }


  public getTaskDetailsData() {
    let attributeMap: any = {};
    let arr = this.sectionAttrHolderArray;
    for (let i = 0; i < arr.length; i++) {
      attributeMap[arr[i].sectionName] = arr[i].attributeMap;
    }

    return attributeMap;
  }

  delegateTo() {
    const delegateIndex = this.sectionAttrHolderArray.findIndex(x => x.sectionCode === Constants.DELEGATED_TO && x.attributeMap.length > 0);
    // if (delegateIndex !== -1) {
    //   const approverIndex = this.sectionAttrHolderArray.findIndex(x => x.sectionCode === Constants.FIRST_LEVEL_APPROVER || x.sectionCode === Constants.FINAL_APPROVER);
    //   this.sectionAttrHolderArray[approverIndex].attributeMap[0].referenceDataValue = this.sectionAttrHolderArray[delegateIndex].attributeMap[0].referenceDataValue;
    //   this.sectionAttrHolderArray[approverIndex].attributeMap[0].dbColumnName = this.sectionAttrHolderArray[delegateIndex].attributeMap[0].dbColumnName;
    //   this.sectionAttrHolderArray[approverIndex].attributeMap[0].value = this.sectionAttrHolderArray[delegateIndex].attributeMap[0].value;
    //   this.sectionAttrHolderArray[approverIndex].attributeMap[0].type = this.sectionAttrHolderArray[delegateIndex].attributeMap[0].type;
    //   delete this.sectionAttrHolderArray[approverIndex].attributeMap[0].referenceDataValueList;
    //   this.sectionAttrHolderArray.splice(delegateIndex, 1);

    // }

    if (delegateIndex !== -1) {
      if(this.isComposeMeeting){
        const approverIndex = this.sectionAttrHolderArray.findIndex(x =>x.sectionCode === Constants.FINAL_APPROVER);
        this.sectionAttrHolderArray[approverIndex].attributeMap[0].referenceDataValue = this.sectionAttrHolderArray[delegateIndex].attributeMap[0].referenceDataValue;
        this.sectionAttrHolderArray[approverIndex].attributeMap[0].dbColumnName = this.sectionAttrHolderArray[delegateIndex].attributeMap[0].dbColumnName;
        this.sectionAttrHolderArray[approverIndex].attributeMap[0].value = this.sectionAttrHolderArray[delegateIndex].attributeMap[0].value;
        this.sectionAttrHolderArray[approverIndex].attributeMap[0].type = this.sectionAttrHolderArray[delegateIndex].attributeMap[0].type;
        delete this.sectionAttrHolderArray[approverIndex].attributeMap[0].referenceDataValueList;
        this.sectionAttrHolderArray.splice(delegateIndex, 1);
      }
      if(this.isLoadTask){
        const approverIndex = this.sectionAttrHolderArray.findIndex(x =>x.sectionCode === Constants.FIRST_LEVEL_APPROVER);
        this.sectionAttrHolderArray[approverIndex].attributeMap[0].referenceDataValue = this.sectionAttrHolderArray[delegateIndex].attributeMap[0].referenceDataValue;
        this.sectionAttrHolderArray[approverIndex].attributeMap[0].dbColumnName = this.sectionAttrHolderArray[delegateIndex].attributeMap[0].dbColumnName;
        this.sectionAttrHolderArray[approverIndex].attributeMap[0].value = this.sectionAttrHolderArray[delegateIndex].attributeMap[0].value;
        this.sectionAttrHolderArray[approverIndex].attributeMap[0].type = this.sectionAttrHolderArray[delegateIndex].attributeMap[0].type;
        delete this.sectionAttrHolderArray[approverIndex].attributeMap[0].referenceDataValueList;
        this.sectionAttrHolderArray.splice(delegateIndex, 1);
      }
      

    }
  }

  public setFinancialInformation(obj) {
    this.financialInfo = obj;
  }
  public getFinancialInformation() {
    return this.financialInfo;
  }

  public setCalculatedFinancialInformation(obj) {
    this.calculatedFinancialInfo = obj;
  }

  public getCalculatedFinancialInformation() {
    return this.calculatedFinancialInfo;
  }

  public setProcessStatus(val) {
    this.status = val;
  }
  public getProcessStatus() {
    return this.status;
  }

  public setRoundTableSummarySectionsData(obj) {
    if (Object.keys(obj).length > 0) {
      if (this.roundTableSummarySectionsArray.length > 0) {
        let index = this.roundTableSummarySectionsArray.findIndex(x => x.key == obj.key);
        if (index != -1) {
          this.roundTableSummarySectionsArray[index] = obj;
        } else {
          this.roundTableSummarySectionsArray.push(obj)
        }
      }
      else {
        this.roundTableSummarySectionsArray.push(obj);
      }
    } else {
      this.roundTableSummarySectionsArray = [];
    }

  }

  public getRoundTableSummarySectionsData(key) {
    let index = this.roundTableSummarySectionsArray.findIndex(x => x.key == key);
    if (index != -1) {
      return this.roundTableSummarySectionsArray[index].value;
    }

  }

  public setLLENTaskNumbersList(data) {
    this.taskNumbersList = data;
  }

  public getLLENTaskNumbersList() {
    return this.taskNumbersList;
  }

  public checkDisableEditableSection(usersRoleStatus, section?) {

    // if (Object.keys(usersRoleStatus).length > 0) {
    //   if (section && section.sectionCode === Constants.FIRST_LEVEL_APPROVER) {
    //     if (usersRoleStatus.status === Constants.SENT_TO_LINE_MANAGER || usersRoleStatus.status === Constants.DRAFT_APPROVED
    //       || usersRoleStatus.status === Constants.APPROVED || usersRoleStatus.status === Constants.ADDINFOREQUIRED  || 
    //       Constants.FINAL_APPROVAL_REQUESTED || usersRoleStatus.status === Constants.ROUND_TABLE_APPROVED){
    //         return true;
    //       }

    //   }
    //   else {
    //     switch (true) {          
    //       case (usersRoleStatus.role === Constants.TASK_CREATOR)
    //         && (usersRoleStatus.status === Constants.FINAL_APPROVAL_REQUESTED || usersRoleStatus.status === Constants.ROUND_TABLE_APPROVED ||
    //           usersRoleStatus.status === Constants.SENT_TO_GROUP_MAILBOX || usersRoleStatus.status === Constants.CLOSED ||
    //           usersRoleStatus.status === Constants.CANCELED || usersRoleStatus.status === Constants.DECLINED):
    //         return true;
    //       case (usersRoleStatus.role === Constants.TASK_CREATOR || usersRoleStatus.role === Constants.REVIEWER)
    //         && (usersRoleStatus.status === Constants.ROUND_TABLE_APPROVED ||
    //           usersRoleStatus.status === Constants.SENT_TO_GROUP_MAILBOX || usersRoleStatus.status === Constants.CLOSED ||
    //           usersRoleStatus.status === Constants.CANCELED || usersRoleStatus.status === Constants.DECLINED):
    //         return true;          
    //       default:
    //         return false;
    //     }
    //   }

    // }

    let ownerArray: any = [];
    if (section && section.sectionCode === Constants.FIRST_LEVEL_APPROVER) {
      // if ((usersRoleStatus.role === Constants.LINE_MANAGER || usersRoleStatus.role === Constants.ASSIGNEE) &&(usersRoleStatus.status === Constants.SENT_TO_LINE_MANAGER 
      //   || usersRoleStatus.status === Constants.DRAFT_APPROVED ||  usersRoleStatus.status === Constants.APPROVED
      //   || usersRoleStatus.status === Constants.ADDINFOREQUIRED ||
      //   usersRoleStatus.status === Constants.FINAL_APPROVAL_REQUESTED || usersRoleStatus.status === Constants.ROUND_TABLE_APPROVED)) {
      //      return true;
      //   }else if(usersRoleStatus.role === Constants.TASK_CREATOR &&  usersRoleStatus.status === Constants.SENT_TO_LINE_MANAGER){
      //     return true;
      //   }   
      //   else{
      //     false;
      //   }      
      if(usersRoleStatus.role === Constants.TASK_CREATOR && usersRoleStatus.status === Constants.PREPARE ){
            return false;
          }   
      else if(usersRoleStatus.role === Constants.INFO_PROVIDER && usersRoleStatus.status === Constants.ADDINFOREQUIRED){
            return false;
        }    
      else{
       return  true;
      }
      
    }
    else {
      // if (usersRoleStatus.role) {
        if (usersRoleStatus.statusOwner) {
          ownerArray = usersRoleStatus.statusOwner.split('#~#');
          let itemFound = ownerArray.find(x => x === usersRoleStatus.role);
            if (itemFound) {
              return false;
            }
            else {
              return true;
            }
        }else{
          return true;
        }
      // } 
      // else {
      //   return true;
      // }
    }

  }

  public setComposeAndLoadTask(composeMeeting,loadTask){
    this.isComposeMeeting=composeMeeting;
    this.isLoadTask=loadTask;
  }
 
  constructor() { }
}
