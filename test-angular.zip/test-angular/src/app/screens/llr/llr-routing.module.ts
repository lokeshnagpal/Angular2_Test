import { LLrContainerComponent } from './llr-container/llr-container.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  
    {
      path: '',
      component: LLrContainerComponent,
      children: [
      ]
    
    }
  ];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LlrRoutingModule { }
