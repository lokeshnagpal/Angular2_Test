import { ClientService } from './../../../../services/client.service';
// import { TaskDetailsProperties } from './../../../../util/application.fields.interface';
import { Constants } from './../../../../util/application.constants';
import { LLRService } from './../../llr.service';
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-task-type',
  templateUrl: './task-type.component.html',
  styleUrls: ['./task-type.component.scss']
})
export class TaskTypeComponent implements OnInit {
  public taskType: string;
  public resMovement: boolean = false;
  public roundTable: boolean = false;
  public subscription: Subscription;
  public taskTypeObj: any={};
  // public taskTypeObj:any= new TaskDetailsProperties();
  // public taskTypeObj:TaskDetailsProperties;
  @Input() taskCreated;
  @Input() taskTypeDetails;
  @Input() isDisabled;
  @Input() isExpand
  // @Output() taskTypeEventData:EventEmitter<any>=new  EventEmitter();
  constructor(private llrService: LLRService,private clientService:ClientService) { }

  ngOnInit() {
    if (this.taskCreated) {
      this.getTaskDetails();
    }else{
      this.setTaskType();
    }

  }
  // set task from llr loading screen
  setTaskType(event?) {
      if(event){
        this.taskTypeObj.rtCategory=event.value;
      }else{
        this.taskType="GLOBAL";
        this.taskTypeObj.rtCategory=this.taskType;
      }
      // this.taskTypeObj.rtCategory=event.value;
      this.taskTypeObj.type={};
      this.llrService.setTaskTypeValue(this.taskTypeObj);
  }

  //get task details once task is created
  getTaskDetails() {
    if (this.taskCreated && this.taskTypeDetails !== undefined) {  
      this.taskType=this.taskTypeDetails.rtCategory;
      this.llrService.setTaskTypeValue(this.taskTypeDetails);     
    }

  }

}
