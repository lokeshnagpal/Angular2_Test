import { LLRService } from './../../llr.service';
import { MatSnackBar, MatDialogRef,MAT_DIALOG_DATA} from '@angular/material';
import { ClientService } from 'src/app/services/client.service';
import { environment } from './../../../../../environments/environment';
import { Constants } from './../../../../util/application.constants';
import { Component, OnInit, Inject } from '@angular/core';
import { CommonTransformerService } from 'src/app/util/common-transformer.service';

@Component({
  selector: 'app-llr-comments-dialog',
  templateUrl: './llr-comments-dialog.component.html',
  styleUrls: ['./llr-comments-dialog.component.scss']
})
export class LlrCommentsDialogComponent implements OnInit {

  public commentsTyped: any;
  public maxLength = Constants.MAX_CHARACTER_LENGTH;
  public charLengthLeft = Constants.MAX_CHARACTER_LENGTH;
  public saveCommentsUrl: any;
  public comments = [];
  public postClick: boolean = true;

  constructor(public clientService: ClientService, @Inject(MatDialogRef) public dialogRef, public llrService: LLRService,
  public commonTransformerService: CommonTransformerService,@Inject(MAT_DIALOG_DATA) public data) {
    this.saveCommentsUrl = environment.saveTaskComments;
  }

  ngOnInit() {
  }

  public charLengthchanged() {
    this.charLengthLeft = (this.maxLength) - (this.commentsTyped.length);
    if (this.commentsTyped.length > 0) {
      this.postClick = false;
    }
    else {
      this.postClick = true;
    }
  }

  public closeDialog() {
    this.dialogRef.close();
  }
  public saveComments() {
    this.comments = [];
    // let taskNumber=this.llrService.getTaskNumber();
    let taskNumber = this.clientService.getQueryParams().taskNumber;
    if (this.commentsTyped) {
      // if (taskNumber === "0" && this.clientService.getQueryParams().tab==="LLEN") {
      //   this.dialogRef.close(this.commentsTyped);
      // }
      // else {
        let obj = {
          "comment": this.commentsTyped,
          "status": this.llrService.getProcessStatus(),
          "commentAddedBy":this.data.obj.role
        }
        this.comments.push(obj);
        let requestObject: any = {
          "taskNumber": taskNumber,
          "comments": this.comments
          //  "type":tabObj
        }
        let self = this;
        this.clientService.setUrl(this.saveCommentsUrl);
        this.clientService.postClientData(requestObject).subscribe(response => {
          this.dialogRef.close(taskNumber);
          this.showMessage("Comments Saved Successfully", 3000)
        });
        this.commentsTyped = '';
        this.postClick = true;
        //  this.dialogRef.close(taskNumber);
      // }

    }

  }


  public showMessage(message: string, durationValue: number) {
    this.commonTransformerService.showMessage(message, durationValue);
  }
}
