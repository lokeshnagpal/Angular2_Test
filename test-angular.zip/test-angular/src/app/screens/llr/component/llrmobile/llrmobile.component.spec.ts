import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LLRMobileComponent } from './llrmobile.component';

describe('LLRMobileComponent', () => {
  let component: LLRMobileComponent;
  let fixture: ComponentFixture<LLRMobileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LLRMobileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LLRMobileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
