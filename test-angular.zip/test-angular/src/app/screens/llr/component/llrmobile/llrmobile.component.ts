import { CommonTransformerService } from 'src/app/util/common-transformer.service';
import { BaseComponent } from './../../../../shared/ui/base/base.component';
import { LLRService } from './../../llr.service';
import { LLRComponent } from './../llr/llr.component';
import { MatDialog, MatSnackBar } from '@angular/material';
import { ClientService } from './../../../../services/client.service';
import { ActivatedRoute,Router } from '@angular/router';
import { Component, OnInit, ChangeDetectorRef } from '@angular/core';


@Component({
  selector: 'app-llrmobile',
  templateUrl: './llrmobile.component.html',
  styleUrls: ['./llrmobile.component.scss']
})
export class LLRMobileComponent extends LLRComponent implements OnInit {

  constructor(public service: LLRService, public route: ActivatedRoute, public router:Router,public clientService: ClientService, public dialog: MatDialog,
    public ref: ChangeDetectorRef,public snackBar: MatSnackBar,public baseComponent:BaseComponent,public commonTransformerService: CommonTransformerService) {

    super(service,route,router,clientService,dialog,ref,snackBar,baseComponent,commonTransformerService);
    
   }
  ngOnInit() {
  }

}
