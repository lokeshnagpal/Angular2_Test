import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LlrParticipantsDialogComponent } from './llr-participants-dialog.component';

describe('LlrParticipantsDialogComponent', () => {
  let component: LlrParticipantsDialogComponent;
  let fixture: ComponentFixture<LlrParticipantsDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LlrParticipantsDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LlrParticipantsDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
