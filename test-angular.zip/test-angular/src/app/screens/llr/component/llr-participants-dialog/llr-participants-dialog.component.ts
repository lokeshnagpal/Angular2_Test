import { ApplicationStateService } from './../../../../util/application.state.service';
import { CommonTransformerService } from 'src/app/util/common-transformer.service';
import { ClientService } from 'src/app/services/client.service';
import { environment } from './../../../../../environments/environment';
import { LLRService } from './../../llr.service';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { FormControl } from '@angular/forms';
import { Component, OnInit, Inject } from '@angular/core';

@Component({
  selector: 'app-llr-participants-dialog',
  templateUrl: './llr-participants-dialog.component.html',
  styleUrls: ['./llr-participants-dialog.component.scss']
})
export class LlrParticipantsDialogComponent implements OnInit {
  
  public dialogList=[];
  public selectedData=[];
  public enableSearch:boolean=false;
  public showSearchLabel:boolean=true;
  public searchName:any;
  public lookupUrl:any;
  public urlForLookup:any;
  public initialValue:any;
  public showMobileView:boolean=false;

  constructor(@Inject(MAT_DIALOG_DATA) public data,@Inject(MatDialogRef) public dialogRef,public service: LLRService,
  public clientService: ClientService, public commonTransformerService: CommonTransformerService,public applicationStateService: ApplicationStateService) { 
    this.lookupUrl = environment.lookupUrl;
    if(this.applicationStateService.getIsDesktopResolution()==false){
      this.showMobileView=true;
    }
    else{
      this.showMobileView=false;
    }
  }

  ngOnInit() {
    this.urlForLookup=this.lookupUrl + '/' +this.data.list.source + '/' + this.data.list.group + '/';
    this.getLookupData(this.urlForLookup);
  }

  //will list the initital data on load
  public getLookupData(url){
    this.clientService.setUrl(url);
    this.clientService.getClientData().subscribe(response => {
     this.dialogList=response;
     this.checkedDialogList();
    })  
  }

  checkedDialogList(){
    console.log(this.data)
    if (this.data.list.referenceDataValueList!==undefined){
      this.selectedData=this.data.list.referenceDataValueList;
    }
    if(this.selectedData.length>0){     
      this.selectedData.forEach((x,i)=>{
        let index=this.dialogList.findIndex(item=>item.id===x.id);
        if(index!=-1){
          this.dialogList[index].selected=true;
          this.selectedData[i].selected=true;
        }
      })
    }
   
  }
  //get selected item from list
  // public getSelectedData(item,index){  
  // this.selectedData.push(item);
  //  this.dialogList.splice(index,1);
  // }

  public getSelectedData(item,index,e){
    if(item.selected){
      e.preventDefault()
    }  
    else{
      if(this.selectedData.length>0){
        let selectedIndex=this.selectedData.findIndex(x=>x.id===item.id);
        if(selectedIndex!=-1){        
          this.dialogList[index].selected=true;
        }
        else{
          this.selectedData.push(item);  
          this.dialogList[index].selected=true; 
        }
      }
      else{
        this.selectedData.push(item);
        this.dialogList[index].selected=true;
      }             
    }
  }

 

  //remove the selected item
  // public removeSelectedData(item){
  //   let removedData;
  //   if(this.selectedData.indexOf(item)>=0){
  //    removedData= this.selectedData.splice(this.selectedData.indexOf(item),1);
  //   }
  //  this.dialogList.push(item);
  // }
  public removeSelectedData(item){
    let removedData;
    if(this.selectedData.indexOf(item)>=0){
     removedData= this.selectedData.splice(this.selectedData.indexOf(item),1);
    }
    if(item["selected"]!==undefined){
      let index=this.dialogList.findIndex(x=>x.name===item.name);
      if(index==-1){
        this.dialogList.push(item);
      }else{
        this.dialogList[index]=item;
      }
      delete item["selected"]
    }  
  //  this.dialogList.push(item);
  }

  public closeDialog(){
    this.dialogRef.close();    
}

public addParticipants(){
  this.dialogRef.close(this.selectedData);
}

public openSearchPanel(){
  this.enableSearch=true;
}

public closeSearchPanel(){
  this.enableSearch=false;
  this.getLookupData(this.urlForLookup);
  // this.dialogList=this.data.list;
  this.searchName="";
  this.showSearchLabel=true;
}

//get the list of data from service when start typing
public getNameList(){
  this.showSearchLabel=false;
   let searchUrl= this.urlForLookup+this.searchName;
   this.getLookupData(searchUrl)
}
}
