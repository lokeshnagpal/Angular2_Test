import { BaseComponent } from './../../../../shared/ui/base/base.component';
// import { DialogProperties, TaskDetailsProperties, ReferenceData } from './../../../../util/application.fields.interface';
import { DialogProperties, TaskDetailsProperties, ReferenceData, LLRContextProperties } from './../../llr.fields.interface';
import { environment } from './../../../../../environments/environment';
import { LLRService } from './../../llr.service';
import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { Observable, of, from, Subscription } from 'rxjs';
import { ClientService } from './../../../../services/client.service';
import { ActivatedRoute, Router } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatSnackBar } from '@angular/material';
import { LlrCommentsDialogComponent } from './../llr-comments-dialog/llr-comments-dialog.component';
import { CommonTransformerService } from 'src/app/util/common-transformer.service';
import { Constants } from './../../../../util/application.constants';
import { LlrActionDialogComponent } from './../llr-action-dialog/llr-action-dialog.component';

@Component({
  selector: 'app-llr',
  templateUrl: './llr.component.html',
  styleUrls: ['./llr.component.scss']
})
export class LLRComponent implements OnInit {

  public resRecieved: boolean = false;
  public taskDetailsConfig = new TaskDetailsProperties();
  public llrContext = new LLRContextProperties();
  public constant = Constants;
  constructor(protected service: LLRService, protected route: ActivatedRoute, public router: Router, protected clientService: ClientService, public dialog: MatDialog,
    protected ref: ChangeDetectorRef, public snackBar: MatSnackBar, public baseComponent: BaseComponent, public commonTransformerService: CommonTransformerService) {
    this.llrContext.startTaskUrl = environment.startTask;
    this.llrContext.taskDetailsServiceUrl = environment.taskDetailsUrl;
    this.llrContext.commentsServiceUrl = environment.taskComments;
    this.route
      .queryParams
      .subscribe(params => {

        this.clearObject();
        this.llrContext.claimNumber = params['claimNumber'];
        if (params['taskNumber'] === undefined) {
          this.llrContext.taskNumber = null;
          this.taskDetailsConfig.taskId = null;
        } else {

          this.llrContext.taskNumber = params['taskNumber'];
        }

        if (this.llrContext.taskNumber === undefined || this.llrContext.taskNumber === null) {
          this.llrContext.isTaskCreated = false;
        }
        else {
          this.llrContext.isTaskCreated = true;
        }



        this.llrContext.queryParams = {
          claimNumber: this.llrContext.claimNumber,
          taskNumber: this.llrContext.taskNumber,
          // tab: this.llrContext.tab
        }
        this.clientService.setQueryParams(this.llrContext.queryParams);
        if (this.llrContext.taskNumber) {
          this.getSectionDetails(this.llrContext.taskNumber);
          this.getCommentsData(this.llrContext.taskNumber);
        }
      });
  }

  ngOnInit() {

  }

  ngAfterViewInit() {

    this.llrContext.subscription = this.baseComponent.getRichTextData.subscribe(res => {
      let attributeHolder: any = [];
      if (Object.keys(res).length > 0) {
        if (res.optional.section != undefined) {
          let taskObj = {
            attrId: res.optional.section.attributes[0].attrId,
            dbColumnName: res.optional.section.attributes[0].dbColumnName,
            type: res.optional.section.attributes[0].type,
            value: res.result
          }

          attributeHolder.push(taskObj)
          let sectionAttrHolderObject = {
            "sectionName": res.optional.section.sectionName,
            "attributeMap": attributeHolder
          }
          this.service.setTaskDetailsData(sectionAttrHolderObject);
        }
        else if (res.optional.key != null) {
          let obj: any = {
            "key": res.optional.key,
            "value": res.result
          }
          this.service.setRoundTableSummarySectionsData(obj);
        }
      }

    });

    this.llrContext.taskTypeSubscription=this.service.taskTypeValue.subscribe(res => {


      if (Object.keys(res).length > 0 && res !== undefined) {
        this.llrContext.taskType = res.type;
        this.taskDetailsConfig.type = res.type;
        this.taskDetailsConfig.rtCategory = res.rtCategory;
      }
      else {
        // res.pageName = this.llrContext.tab.toUpperCase();
        res.type = {};
        this.service.setTaskTypeValue(res);
      }
    });

  }

  ngOnDestroy() {
    if (this.llrContext.subscription !== undefined) {
      this.llrContext.subscription.unsubscribe();
      this.llrContext.taskTypeSubscription.unsubscribe();
    }
  }


  public clearObject() {
    this.taskDetailsConfig = new TaskDetailsProperties();
    this.service.setTaskDetailsData({});
    this.service.setCalculatedFinancialInformation(null);
    this.service.setRoundTableSummarySectionsData({});
    this.service.setFormAttributes(null);
    // this.taskDetailsConfig.taskAdditionalDetails={};
  }
  public getSectionDetails(taskNumber, button?) {

    if (button) {
      if (button.buttonName !== Constants.SAVE_DRAFT && button.buttonName !== Constants.SAVE) {
        this.service.setTaskDetailsData({});
      }
    }

    // this.service.setTaskDetailsData({});
    this.clientService.setUrl(this.llrContext.taskDetailsServiceUrl + taskNumber);
    this.clientService.getClientData().subscribe(res => {
      this.llrContext.showProgressBar = false;
      let index: any;
      this.taskDetailsConfig = res;

      // if (this.taskDetailsConfig.userRole !== undefined) {
      if (this.taskDetailsConfig.status !== undefined) {
        this.llrContext.usersRoleStatus = {
          role: res.userRole,
          status: res.status,
          prevStatus: res.prevStatus,
          statusOwner: res.statusOwner
        }
      }
      //  else {
      //   this.llrContext.usersRoleStatus = {};
      // }
      // this.llrContext.isEdit = !this.service.checkDisableEditableSection(this.llrContext.usersRoleStatus);  //set  disable/enable  section for standalone component

      this.service.setFinancialInformation(res.financialsData);
      this.createMeetingSummary(res);
      this.showAdditionalInfoCommentBox();
    });
  }
  //method to get the response of comments section
  public getCommentsData(tasknumber) {
    const groupTaskObj: any = {};
    this.clientService.setUrl(this.llrContext.commentsServiceUrl + tasknumber + "/comments/");
    this.clientService.getClientData().subscribe(res => {
      if (res.comments && res.comments.length > 0) {
        this.llrContext.commentsData = res.comments;

        this.llrContext.participantComment = [];
        res.comments.forEach((item, index) => {
          if (item.commentAddedBy === Constants.OTHER_PARTICIPANT) {
            this.llrContext.participantComment.push(item);
          }
        });

        const participantComment = JSON.parse(JSON.stringify(this.llrContext.participantComment));
        this.llrContext.participantLogGroup = this.groupTaskLog(participantComment, "createdDate");

        const taskLogList = JSON.parse(JSON.stringify(res.comments));
        this.llrContext.taskLogGroup = this.groupTaskLog(taskLogList, "createdDate");
        this.llrContext.showNoComments = false;
      }
      else {
        this.llrContext.showNoComments = true;
      }
    })
  }

  public groupTaskLog(collection, property) {

    const groupedCollection = collection.reduce((previous, current) => {
      current.timeZone = this.commonTransformerService.getTimeZone(current[property]);
      current[property] = this.commonTransformerService.dateTimeZoneChange(current[property]);
      current[property] = this.commonTransformerService.dateObjectToDateTimeChange(current[property]);
      const date = current[property].split(' ')[0] + ' ' + current[property].split(' ')[1] + ' ' + current[property].split(' ')[2];
      if (!previous[date]) {
        previous[date] = [current];
      } else {
        previous[date].push(current);
      }
      return previous;
    }, {});

    // this will return an array of objects, each object containing a group of objects
    return Object.keys(groupedCollection).map(key => (
      {
        key, value: groupedCollection[key]
      }
    ))
  }
  public addComments() {
    let dialogRef;
    let obj: any = {
      role: this.llrContext.usersRoleStatus.role,
      headerName: "Participant Comments",
      placeHolder: "Write Comments"
    }
    dialogRef = this.dialog.open(LlrCommentsDialogComponent, {
      autoFocus: false,
      width: '43.5%',
      panelClass: 'llr-comments-dialog-panel',
      data: { obj }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.getCommentsData(result);
      }
    });
  }
  getOverviewEvent(event) {
    this.resRecieved = event
  }

  //method to perform task on action button and check vaildation
  taskAction(button) {
    const vaildationStatusObj = this.checkValidation(button);
    this.ref.detectChanges();
    if (!vaildationStatusObj.statusFlag) {
      this.actionButtonTask(button);
    }
    else {
      this.commonTransformerService.showMessage(vaildationStatusObj.message, 3000)
    }
  }

  //method to perfom task on open dialog/without open
  actionButtonTask(button) {
    const actionDialogObj: DialogProperties = {};
    this.llrContext.showProgressBar = true;
    this.llrContext.processSteps = false;
    let message: string = ''
    if (this.llrContext.taskNumber !== null && this.llrContext.taskNumber !== "0") {
      this.llrContext.newTask = false;
    }
    else {
      this.llrContext.newTask = true;
      this.llrContext.taskNumber = null;
      this.clientService.setClaimNumber(this.llrContext.claimNumber);
    }

    switch (button.buttonName) {
      case "SUBMIT": {
        actionDialogObj.headerName = Constants.COMMENTS_HEADER;
        actionDialogObj.placeholder = Constants.COMMENTS_PLACEHOLDER;
        actionDialogObj.actionButton = button.buttonName;
        // actionDialogObj.message="Task Submitted Successfully";
        this.openActionDialog(actionDialogObj, button, message);
        break;
      }
      case "APPROVE": {
        actionDialogObj.headerName = Constants.APPROVAL_HEADER;
        actionDialogObj.placeholder = Constants.APPROVAL_PLACEHOLDER;
        actionDialogObj.actionButton = button.buttonName;
        actionDialogObj.message = Constants.SUBMIT_TASK_MSSG;
        this.openActionDialog(actionDialogObj, button, message);
        break;
      }
      case "REQUEST ADDITIONAL INFORMATION": {
        actionDialogObj.headerName = Constants.REQUEST_ADDITIONAL_HEADER;
        actionDialogObj.placeholder = Constants.REQUEST_ADDITIONAL_PLACEHOLDER;
        actionDialogObj.actionButton = button.buttonName;
        this.openActionDialog(actionDialogObj, button, message);
        break;
      }
      case "DELEGATE": {
        actionDialogObj.headerName = Constants.DELEGATE_HEADER_PLACEHOLDER;
        actionDialogObj.placeholder = Constants.DELEGATE_HEADER_PLACEHOLDER;
        actionDialogObj.actionButton = button.buttonName;
        message = "Round Table is Successfully Delegated";
        this.openActionDialog(actionDialogObj, button, message);
        break;
      }
      case "DECLINE": {
        actionDialogObj.headerName = Constants.DECLINE_HEADER;
        actionDialogObj.placeholder = Constants.DECLINE_PLACEHOLDER;
        actionDialogObj.actionButton = button.buttonName;
        message = "Round Table is Successfully Declined";
        this.openActionDialog(actionDialogObj, button, message);
        break;
      }
      case "DISCARD": {
        actionDialogObj.actionButton = button.buttonName;
        actionDialogObj.headerName = Constants.DISCARD_RT_HEADER;
        actionDialogObj.placeholder = Constants.DISCARD_RT_PLACEHOLDER;
        message = "Round Table is Successfully Discarded";
        this.openActionDialog(actionDialogObj, button, message);
        break;
      }
      default: {
        this.createTaskTypeObject(button, actionDialogObj, message);
        break;
      }
    }
  }
  public openActionDialog(actionObj, button, message) {
    let dialogRef;
    if (button.commentMandInd === 'Y' || (button.commentMandInd === 'N' && (button.statusCode === Constants.SENT_TO_LINE_MANAGER ||
      button.statusCode === Constants.DRAFT_APPROVED || button.statusCode === Constants.ROUND_TABLE_APPROVED))) {
      dialogRef = this.dialog.open(LlrActionDialogComponent, {
        autoFocus: false,
        width: '43.5%',
        panelClass: 'llr-action-dialog-panel',
        data: { actionObj, button }  // Need to send final approver details to delegate on delegate click
      });

      dialogRef.afterClosed().subscribe(result => {
        if (result !== undefined) {
          if (result.action !== 'CANCEL') {
            this.llrContext.showProgressBar = true;
            this.llrContext.actionDialogComments = result.value;
            this.createTaskTypeObject(button, actionObj, message);
          }
          else {
            this.llrContext.showProgressBar = false;
          }
        }
        else {
          this.llrContext.showProgressBar = false;
        }
      });
    }


  }
  public createTaskTypeObject(button, actionObj, message) {

    const comment = {
      'attrId': null,
      'value': null,
      'type': 'TEXTAREA'
    }
    this.llrContext.taskTypeObject = {
      "claimNum": this.llrContext.claimNumber,
      "taskTitle": this.llrContext.taskType.name,
      "taskTypeValue": {
        "code": this.llrContext.taskType.code,
        "name": this.llrContext.taskType.name,
        "children": null
      },
      "newTask": this.llrContext.newTask,
      "actionButtonName": button.buttonName.toUpperCase(),
      // "isReserveMovement": this.taskDetailsConfig.isReserveMovement,
      "rtCategory": this.taskDetailsConfig.rtCategory,
      "nextStatusId": button.nextStatusId,
      "taskNumber": this.llrContext.taskNumber,
      "isEditAllowed": true,
      "taskActionButtons": this.taskDetailsConfig.actionButtons,
      "attributeMap": null,
      "taskId": this.taskDetailsConfig.taskId,
      "refNum": this.llrContext.refNum,
      "financialsData": this.service.getCalculatedFinancialInformation(),
      "liablityQuantum": this.service.getRoundTableSummarySectionsData(this.llrContext.liablityQuantumKey),
      "proposedReserved": this.service.getRoundTableSummarySectionsData(this.llrContext.proposedReservedKey),
      "outcomeRT": this.service.getRoundTableSummarySectionsData(this.llrContext.outcomeRTKey)

    }


    comment.value = this.llrContext.actionDialogComments;
    this.llrContext.taskTypeObject.comment = comment;
    this.llrContext.taskTypeObject.attributeMap = this.service.getTaskDetailsData();

    // console.log("attributMap", this.llrContext.taskTypeObject.attributeMap);
    // console.log("taskObj", this.llrContext.taskTypeObject);
    // console.log("taskObj", JSON.stringify(this.llrContext.taskTypeObject));

    this.clientService.setUrl(this.llrContext.startTaskUrl);
    this.clientService.postClientData(this.llrContext.taskTypeObject).subscribe(response => {
      if (response) {

        this.llrContext.isTaskCreated = true;
        this.llrContext.processSteps = true;
        this.llrContext.taskNumber = response.taskNumber;
        this.taskDetailsConfig.taskId = response.taskId;
        const claimNumber = this.route.snapshot.queryParams;
        this.llrContext.queryParams.taskNumber = this.llrContext.taskNumber;
        // this.llrContext.queryParams.tab = this.llrContext.tab;
        this.clientService.setQueryParams(this.llrContext.queryParams);
        // this.getSectionDetails(this.llrContext.taskNumber);
        // this.getCommentsData(this.llrContext.taskNumber);
        if (this.llrContext.newTask) {
          this.router.navigate([], {
            queryParams: { "taskNumber": this.llrContext.taskNumber, "claimNumber": this.llrContext.claimNumber },
          });
        }
        else {
          this.getSectionDetails(this.llrContext.taskNumber, button);
          this.getCommentsData(this.llrContext.taskNumber);
        }
        if (!this.llrContext.newTask) {
          if (message !== '') {
            this.commonTransformerService.showMessage(message, 3000);
          }
          else {
            this.commonTransformerService.showMessage("Saved Successfully", 3000);
          }
        } else {
          this.commonTransformerService.showMessage("Task Created Successfully", 3000)
        }

        // console.log("response", response);
      }
    }, err => {
      this.llrContext.showProgressBar = false;
      this.commonTransformerService.showError(err, 3000);
    });
  }

  //method to compose meeting for Round Table
  public createMeetingSummary(obj) {
    this.llrContext.isComposedMeeting = false;
    this.ref.detectChanges();
    if (obj.type.code === Constants.LLR_GENERATE_ROUND_TABLE_CODE && (
      obj.status === Constants.RT_SCHEDULED || obj.status === Constants.FINAL_APPROVAL_REQUESTED
      || obj.status === Constants.ROUND_TABLE_APPROVED
      || obj.status === Constants.SENT_TO_GROUP_MAILBOX || obj.status === Constants.CLOSED)
      || (obj.status === Constants.ADDINFOREQUIRED && obj.prevStatus === Constants.FINAL_APPROVAL_REQUESTED)) {
      // this.llrContext.isTaskTypeAndLLEN = false;
      this.llrContext.isTaskType = false;
      this.llrContext.isComposedMeeting = true;
      this.llrContext.isLoadTaskDetails = false;
    }
    else if (obj.status === Constants.ADDINFOREQUIRED && (obj.prevStatus === Constants.SENT_TO_LINE_MANAGER || obj.prevStatus === Constants.DRAFT_APPROVED)) {
      this.llrContext.isComposedMeeting = false;
      this.llrContext.isLoadTaskDetails = true;
    }
    else {
      this.llrContext.isComposedMeeting = false;
      this.llrContext.isLoadTaskDetails = true;
    }
    if (this.llrContext.isComposedMeeting) {
      if (obj.sectionDetails.length > 0) {// check condition for static section      
        // this.llrContext.finalApprover=undefined;
        this.llrContext.finalApprover = obj.sectionDetails.find(x => x.sectionCode === Constants.FINAL_APPROVER);
        if (this.llrContext.finalApprover) {
          if (this.llrContext.finalApprover.attributes.length > 0) {
            this.llrContext.finalApprover = this.llrContext.finalApprover;
          }
        }
        else {
          this.llrContext.finalApprover = this.service.getStaticSectionData()[0];
        }

        if (this.llrContext.finalApprover.attributes[0].referenceDataValue) {
          let referenceObj: any = {
            refDataId: this.llrContext.finalApprover.attributes[0].referenceDataValue.refDataId,
            name: this.llrContext.finalApprover.attributes[0].referenceDataValue.name,
            code: this.llrContext.finalApprover.attributes[0].referenceDataValue.id
          }
          let taskObj = {
            attrId: this.llrContext.finalApprover.attributes[0].attrId,
            dbColumnName: this.llrContext.finalApprover.attributes[0].dbColumnName,
            type: this.llrContext.finalApprover.attributes[0].type,
            value: referenceObj.name,
            referenceDataValue: referenceObj
          }
          let attributeHolder: any = [];
          attributeHolder.push(taskObj)
          let sectionAttrHolderObject = {
            "sectionName": this.llrContext.finalApprover.sectionName,
            "sectionCode": this.llrContext.finalApprover.sectionCode,
            "attributeMap": attributeHolder
          }
          this.service.setTaskDetailsData(sectionAttrHolderObject);
        }
        // this.llrContext.participants=undefined;
        let participantIndex = obj.sectionDetails.findIndex(x => x.sectionCode === Constants.PARTICIPANTS);
        if (participantIndex > -1) {
          this.llrContext.participants = obj.sectionDetails[participantIndex];
        }

        this.llrContext.mailInbox = obj.sectionDetails.find(x => x.sectionCode === Constants.LLR_MAILBOX_DETAILS);
        // this.ref.detectChanges();
        if (this.llrContext.mailInbox) {
          if (this.llrContext.mailInbox.attributes.length > 0) {
            this.llrContext.mailInbox = this.llrContext.mailInbox;
          }
        }
        else {
          this.llrContext.mailInbox = this.service.getStaticSectionData()[2];
        }


        let financialIndex = this.taskDetailsConfig.taskAdditionalDetails.sectionDetails.findIndex(x => x.sectionCode === Constants.LLR_FINANCIAL_INFORMATION);
        if (financialIndex > -1) {
          this.llrContext.financialInfo = this.taskDetailsConfig.taskAdditionalDetails.sectionDetails[financialIndex];
        }
      }

      this.llrContext.isEdit = !this.service.checkDisableEditableSection(this.llrContext.usersRoleStatus);  //set  disable/enable  section for standalone component
    }
    this.service.setComposeAndLoadTask(this.llrContext.isComposedMeeting, this.llrContext.isLoadTaskDetails);

  }

  //method to show additional info comment box base on condition
  public showAdditionalInfoCommentBox() {

    if (this.taskDetailsConfig.status === Constants.ADDINFOREQUIRED) {
      if (this.taskDetailsConfig.userRole === Constants.INFO_PROVIDER &&
        (this.taskDetailsConfig.prevStatus === Constants.SENT_TO_LINE_MANAGER || this.taskDetailsConfig.prevStatus === Constants.ADDINFOREQUIRED)) {
        // return true;
        this.llrContext.isAdditionalInfoRequired = true;
      }

      else if ((this.taskDetailsConfig.userRole === Constants.TASK_CREATOR || this.taskDetailsConfig.userRole === Constants.INFO_PROVIDER)
        && this.taskDetailsConfig.prevStatus === Constants.FINAL_APPROVAL_REQUESTED) {
        // return true;
        this.llrContext.isAdditionalInfoRequired = true;
      }

      else if (this.taskDetailsConfig.userRole === Constants.ASSIGNEE &&
        (this.taskDetailsConfig.prevStatus === Constants.DRAFT_APPROVED || this.taskDetailsConfig.prevStatus === Constants.ADDINFOREQUIRED)) {
        // return true;
        this.llrContext.isAdditionalInfoRequired = true;
      }
      else {
        // return false;
        this.llrContext.isAdditionalInfoRequired = false;
      }

    }
  }

  //switching between the tabs
  public tabChange(event) {
    this.service.setTabChangeEvent(true); // method to null the dynamic formArray while tab switching to remove the redundancy 
    if (event.tab.textLabel === "MEETING SUMMARY") {
      this.llrContext.isComposedMeeting = true;
      this.llrContext.isLoadTaskDetails = false;
      this.llrContext.isTaskType = false;
    }
    else {
      this.llrContext.isTaskType = true;
      if (this.llrContext.isComposedMeeting !== true) {
        this.llrContext.isLoadTaskDetails = true;
      } else {
        this.llrContext.isLoadTaskDetails = false;
        this.llrContext.isComposedMeeting = false;
      }
    }


    // if (event.navigationLink === 'taskDetails' || event.navigationLink === 'meetingDetails') {
    //   this.service.setTabChangeEvent(true); // method to null the dynamic formArray while tab switching to remove the redundancy 
    //   if (event.displayTitle === "MEETING SUMMARY") {
    //     this.llrContext.isComposedMeeting = true;
    //     this.llrContext.isLoadTaskDetails = false;
    //     this.llrContext.isTaskType = false;
    //   }
    //   else {
    //     this.llrContext.isTaskType = true;
    //     if (this.llrContext.isComposedMeeting !== true) {
    //       this.llrContext.isLoadTaskDetails = true;
    //     } else {
    //       this.llrContext.isLoadTaskDetails = false;
    //       this.llrContext.isComposedMeeting = false;
    //     }
    //   }
    // }
    // else {
    //   let pageName = event.navigationLink;
    //   // console.log(this.pageName)
    //   switch (pageName) {
    //     case "claimSummary":
    //       this.router.navigate(["/claimSummary"], { queryParams: { "claimNumber": this.llrContext.claimNumber, tab: pageName } });
    //       break;
    //     case "diary":
    //       this.router.navigate(["/diary"], {
    //         queryParams: { "claimNumber": this.llrContext.claimNumber, tab: pageName },
    //       });
    //       break;
    //     //   case "financial":
    //     // this.router.navigate(["/financial"], {relativeTo: this.route});
    //     //   break;

    //     //   case "claimDetails":
    //     // this.router.navigate(["/claimDetails"]);
    //     //   break;

    //     //   case "history":
    //     // this.router.navigate(["/history"], {relativeTo: this.route});
    //     //   break;
    //     //   case "documents":
    //     // this.router.navigate(["/documents"], {relativeTo: this.route});
    //     //   break;

    //   }
    // }

  }

  public checkValidation(button) {
    const formGroupArray: any = this.service.getFormAttributes();
    // let statusFlag: boolean = false;
    let validationStatus: any = {
      statusFlag: false,
      message: ''
    }
    switch (true) {
      case this.llrContext.isTaskCreated &&
        (button.buttonName === Constants.SUBMIT || button.buttonName === Constants.APPROVE ||
          button.buttonName === Constants.SEND_TO_MAILBOX || button.buttonName === Constants.TRIGGER_ACTIVITY):
        //check dynamic form control validation
        {
          formGroupArray.forEach(item => {
            for (const key in item.controls) {
              if (item.controls[key]['_status'] === "INVALID" || item.controls[key].status === "INVALID") {
                validationStatus.message = '';
                if (item.controls[key].errors !== null && item.controls[key].errors.required === true) {
                  item.controls[key].errors.errorMsg = "Field is mandatory";
                }
                const index = this.taskDetailsConfig.taskAdditionalDetails.sectionDetails.findIndex(x => x.sectionName === item.sectionName);
                if (index !== -1) {
                  if (this.taskDetailsConfig.taskAdditionalDetails.sectionDetails[index]["isExpand"]) {
                    this.taskDetailsConfig.taskAdditionalDetails.sectionDetails[index]["isExpand"] = false;
                    // this.ref.detectChanges();
                  }
                  this.taskDetailsConfig.taskAdditionalDetails.sectionDetails[index]["isExpand"] = true;

                }

                const staticIndex = this.taskDetailsConfig.sectionDetails.findIndex(x => x.sectionName === item.sectionName);
                if (staticIndex !== -1) {
                  // if (this.taskDetailsConfig.sectionDetails[staticIndex]["isExpand"]) {
                  //   this.taskDetailsConfig.sectionDetails[staticIndex]["isExpand"] = false;
                  //   // this.ref.detectChanges();
                  // }
                  // this.taskDetailsConfig.sectionDetails[staticIndex]["isExpand"] = true;
                  if (!this.taskDetailsConfig.sectionDetails[staticIndex]["isExpand"]) {
                    this.taskDetailsConfig.sectionDetails[staticIndex]["isExpand"] = true;
                  }
                }


                if (this.llrContext.finalApprover && item.sectionName === this.llrContext.finalApprover.sectionName && item.status === "INVALID") {
                  // if (this.llrContext.finalApprover["isExpand"]) {
                  //   this.llrContext.finalApprover["isExpand"] = false;
                  //   // this.ref.detectChanges();
                  // }
                  // else {
                  //   this.llrContext.finalApprover["isExpand"] = true;
                  // }
                  if (!this.llrContext.finalApprover["isExpand"]) {
                    this.llrContext.finalApprover["isExpand"] = true;
                  }
                }

                if (this.llrContext.mailInbox && item.sectionName === this.llrContext.mailInbox.sectionName && item.status === "INVALID") {
                  if (this.llrContext.mailInbox["isExpand"]) {
                    this.llrContext.mailInbox["isExpand"] = false;
                    // this.ref.detectChanges();
                  }
                  else {
                    this.llrContext.mailInbox["isExpand"] = true;
                  }
                }

                this.ref.detectChanges();
                validationStatus.statusFlag = true;
                validationStatus.message = validationStatus.message + Constants.FILL_REQUIRED_FIELDS_MSSG + '.' + "\r\n";
              }
            }
          });

          let items: any = this.service.getTaskDetailsData()
          if (items.Participants && this.llrContext.isComposedMeeting) {
            let index = items.Participants.findIndex(x => x.dbColumnName === Constants.PARTICIPANTS)
            if (index > -1 && items.Participants[index].referenceDataValueList.length < 2) {
              validationStatus.statusFlag = true;
              validationStatus.message = validationStatus.message + Constants.ADD_TWO_PARTICIPANTS_MSSG + "\r\n";
            }
          }

          return validationStatus;
        }

      // case !this.llrContext.isTaskCreated && this.taskDetailsConfig.rtCategory === undefined:
      //   {
      //     validationStatus.statusFlag = true;
      //     validationStatus.message = Constants.ROUND_TABLE_CATEGORY_MSSG;
      //     return validationStatus;
      //   }
      default: {
        return false;
      }
    }
  }
}
