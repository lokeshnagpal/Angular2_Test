import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LLRComponent } from './llr.component';

describe('LLRComponent', () => {
  let component: LLRComponent;
  let fixture: ComponentFixture<LLRComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LLRComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LLRComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
