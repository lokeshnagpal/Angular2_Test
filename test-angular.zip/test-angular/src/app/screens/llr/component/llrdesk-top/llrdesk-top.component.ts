import { BaseComponent } from 'src/app/shared/ui/base/base.component';
import { CommonTransformerService } from 'src/app/util/common-transformer.service';
import { LlrCommentsDialogComponent } from './../llr-comments-dialog/llr-comments-dialog.component';
import { Constants } from './../../../../util/application.constants';
import { environment } from './../../../../../environments/environment';
import { LLRService } from './../../llr.service';
import { LLRComponent } from './../llr/llr.component';
import { MatDialog, MatSnackBar } from '@angular/material';
import { ClientService } from './../../../../services/client.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { Subscription } from 'rxjs';
import { Tab } from 'src/app/shared/ui/model/tabs-with-actions';

@Component({
  selector: 'app-llrdesk-top',
  templateUrl: './llrdesk-top.component.html',
  styleUrls: ['./llrdesk-top.component.scss']
})
export class LLRDeskTopComponent extends LLRComponent implements OnInit {

  tabOptions:Tab[] =[
    {
      displayTitle:"TASK DETAILS",
       navigationLink: "taskDetails"
    }
    // {
    // displayTitle:"CLAIM SUMMARY",
    //  navigationLink: "claimSummary"
    // },   
    // {
    //   displayTitle:"FINANCIAL",
    //   navigationLink: "financial"
    //  },
    // {
    //   displayTitle:"DIARY DATES",
    //    navigationLink: "diary"
    // },
    // {
    //   displayTitle:"HISTORY",
    //   navigationLink: "history"
    //  },
    //  {
    //   displayTitle:"DOCUMENTS",
    //   navigationLink: "documents"
    //  }
    
    ];

    // meetindTabOptions:Tab[] =[
    //   {
    //     displayTitle:"MEETING SUMMARY",
    //      navigationLink: "meetingDetails"
    //   },
    //   {
    //     displayTitle:"TASK DETAILS",
    //      navigationLink: "taskDetails"
    //   },
    //   {
    //   displayTitle:"CLAIM SUMMARY",
    //    navigationLink: "claimSummary"
    //   },   
    //   {
    //     displayTitle:"FINANCIAL",
    //     navigationLink: "financial"
    //    },
    //   {
    //     displayTitle:"DIARY DATES",
    //      navigationLink: "diary"
    //   },
    //   {
    //     displayTitle:"HISTORY",
    //     navigationLink: "history"
    //    },
    //    {
    //     displayTitle:"DOCUMENTS",
    //     navigationLink: "documents"
    //    }
      
    //   ];
  
  public pageName:any;
  public claimNumber: any;
  public subscription: Subscription;
  constructor(public service: LLRService, public route: ActivatedRoute, public router: Router, public clientService: ClientService, public dialog: MatDialog,
    public ref: ChangeDetectorRef, public snackBar: MatSnackBar, public baseComponent:BaseComponent,public commonTransformerService: CommonTransformerService) {
    super(service, route, router, clientService, dialog, ref, snackBar,baseComponent,commonTransformerService);
    this.route
    .queryParams
    .subscribe(params => {
      this.claimNumber = params['claimNumber'];     
    }); 
  }

  ngOnInit() {

  }

  ngOnChanges() {

  }
  handleTabClick(event:any){
    this.pageName=event.navigationLink;
  // console.log(this.pageName)
  switch (this.pageName) {
    case "claimSummary":
    this.router.navigate(["/claimSummary"], {queryParams: { "claimNumber": this.claimNumber, tab: this.pageName }});
      break;
      case "diary":
    this.router.navigate(["/diary"], {
      queryParams: { "claimNumber": this.claimNumber, tab: this.pageName },
    });
      break;
    //   case "financial":
    // this.router.navigate(["/financial"], {relativeTo: this.route});
    //   break;
      
    //   case "claimDetails":
    // this.router.navigate(["/claimDetails"]);
    //   break;
    
    //   case "history":
    // this.router.navigate(["/history"], {relativeTo: this.route});
    //   break;
    //   case "documents":
    // this.router.navigate(["/documents"], {relativeTo: this.route});
    //   break;
    
    }
      }
}
