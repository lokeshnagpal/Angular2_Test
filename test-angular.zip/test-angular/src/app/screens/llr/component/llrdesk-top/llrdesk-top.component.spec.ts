import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LLRDeskTopComponent } from './llrdesk-top.component';

describe('LLRDeskTopComponent', () => {
  let component: LLRDeskTopComponent;
  let fixture: ComponentFixture<LLRDeskTopComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LLRDeskTopComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LLRDeskTopComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
