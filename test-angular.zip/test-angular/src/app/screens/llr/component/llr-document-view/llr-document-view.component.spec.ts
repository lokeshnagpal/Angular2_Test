import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LLrDocumentViewComponent } from './llr-document-view.component';

describe('LlrDocumentViewComponent', () => {
  let component: LLrDocumentViewComponent;
  let fixture: ComponentFixture<LLrDocumentViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LLrDocumentViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LLrDocumentViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
