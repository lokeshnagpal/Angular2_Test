import { LLRService } from './../../../../screens/llr/llr.service';
import { Constants } from './../../../../util/application.constants';
import { environment } from './../../../../../environments/environment';
import { ClientService } from './../../../../services/client.service';
import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';

@Component({
  selector: 'app-llen-section',
  templateUrl: './llen-section.component.html',
  styleUrls: ['./llen-section.component.scss']
})
export class LlenSectionComponent implements OnInit {
  public taskItems: any = [];
  public isLLEN: boolean = false;
  public llenTaskList: string;
  public llenTaskObj: any = {};
  public selectedTask: any;
  @Input() refNum: string;
  @Input() taskCreated: boolean;
  // @Input() llenDetails: any;
  @Output() getLLENInformationEvent: EventEmitter<any> = new EventEmitter();
  constructor(public clientService: ClientService, public llrService: LLRService) {
    this.llenTaskList = environment.llenTaskList
  }

  ngOnInit() {
    if (this.refNum && this.taskCreated) {
      this.isLLEN = true;
      this.getTaskNumbers()
    }
  }
  getTaskNumbers(event?) {
    if (event !== undefined) {
      this.isLLEN = event.checked;
    }

    this.clientService.setUrl(this.llenTaskList);
    if (this.isLLEN === true) {
      let requestObj = {        // always send status closed for llen toggle on
        "claimNumber": this.clientService.getQueryParams().claimNumber,
        "status": "CLOSED",
        "type": {
          "code": Constants.LARGE_LOSS_EVENT_NOTIFICATION_CODE,
          "name": Constants.LARGE_LOSS_EVENT_NOTIFICATION_NAME
        }
      }
      this.clientService.postClientData(requestObj).subscribe(res => {
        res.forEach(element => {
          this.taskItems.push(element);
        });
        if (this.refNum && this.taskCreated) {
          const index = this.taskItems.findIndex(x => x.taskNumber === this.refNum);
          if (index !== -1) {
            this.getLLENInformation(event, this.taskItems[index], index);
          }

        }
      })

    }
    else {
      this.taskItems = [];
      this.llenTaskObj.llenChecked = this.isLLEN;
      this.getLLENInformationEvent.emit(this.llenTaskObj);
    }

  }
  getLLENInformation(event, val, index) {
    if (this.taskCreated && event !== undefined) {
      event.stopPropagation();
    }
    else {
      this.selectedTask = index;
      this.llenTaskObj.selectedTask = this.selectedTask;
      this.llenTaskObj.taskData = val;
      this.llenTaskObj.llenChecked = this.isLLEN;
      this.getLLENInformationEvent.emit(this.llenTaskObj);
    }

  }
}
