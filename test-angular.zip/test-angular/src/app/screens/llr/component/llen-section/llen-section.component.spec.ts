import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LlenSectionComponent } from './llen-section.component';

describe('LlenSectionComponent', () => {
  let component: LlenSectionComponent;
  let fixture: ComponentFixture<LlenSectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LlenSectionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LlenSectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
