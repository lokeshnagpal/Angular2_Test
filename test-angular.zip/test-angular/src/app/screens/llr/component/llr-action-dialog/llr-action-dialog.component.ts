import { LLRService } from './../../llr.service';

import { MatSnackBar, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Constants } from './../../../../util/application.constants';
import { Component, OnInit, Inject } from '@angular/core';

@Component({
  selector: 'app-llr-action-dialog',
  templateUrl: './llr-action-dialog.component.html',
  styleUrls: ['./llr-action-dialog.component.scss']
})
export class LlrActionDialogComponent implements OnInit {
  public commentsTyped: string = "";
  public maxLength = Constants.MAX_CHARACTER_LENGTH;
  public charLengthLeft = Constants.MAX_CHARACTER_LENGTH;
  public saveCommentsUrl: any;
  public comments = [];
  public postClick: boolean = true;
  public delegateTo:any;
  public disableButton:boolean;
  constructor( @Inject(MatDialogRef) public dialogRef, public snackBar: MatSnackBar, @Inject(MAT_DIALOG_DATA) public data,public llrService:LLRService) { }

  ngOnInit() {
    this.delegateTo=this.llrService.getStaticSectionData()[1];
    if(this.data.button.commentMandInd==='Y' && this.data.button.buttonName!==Constants.DISCARD){
       this.disableButton=true;
    }
  }
  public charLengthchanged() {
    this.charLengthLeft = (this.maxLength) - (this.commentsTyped.length);
    if(this.data.button.commentMandInd==='Y'){
        this.disableButton=false;
     }
  }

  // public closeDialog() {
  //   this.dialogRef.close('CANCEL');
  // }
  public actionPerfom(action) {
    let obj={
      value:this.commentsTyped,
      action:action
    }
    this.dialogRef.close(obj);
  }

}
