import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LlrActionDialogComponent } from './llr-action-dialog.component';

describe('LlrActionDialogComponent', () => {
  let component: LlrActionDialogComponent;
  let fixture: ComponentFixture<LlrActionDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LlrActionDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LlrActionDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
