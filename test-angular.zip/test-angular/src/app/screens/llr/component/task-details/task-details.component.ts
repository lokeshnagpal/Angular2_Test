import { LLRService } from 'src/app/screens/llr/llr.service';
import { environment } from './../../../../../environments/environment';
import { CommonTransformerService } from './../../../../util/common-transformer.service';
import { ClientService } from './../../../../services/client.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-task-details',
  templateUrl: './task-details.component.html',
  styleUrls: ['./task-details.component.scss']
})
export class TaskDetailsComponent implements OnInit {

  @Input() taskDetailsAttributes;

  public lookupUrl:any;
  public lookupVal:any=[];
  public optionValue:any;
  public attributes:any;
  public taskDetailsForm: FormGroup;
  public attributeHolder: any = [];
  constructor(public fb: FormBuilder,public clientService: ClientService,
    private commonTransformerService: CommonTransformerService,public llrService:LLRService) {
    this.lookupUrl=environment.lookupUrl;
   }

  ngOnInit() {
  }

  ngOnChanges(){
    if(this.taskDetailsAttributes){
      this.attributes=this.taskDetailsAttributes[0].attributes
      this.taskDetailsForm = this.createForm(this.attributes);     
      this.createTaskDetails();
    }
  }

  public createForm(obj) {
    const group = this.fb.group({});
    obj.forEach(control => group.addControl(control.dbColumnName, this.createControl(control)));
    return group;
}

public createControl(config) {
  const { isDisabled } = config;
  let value;
  let validation;
  let item = config;
  if (config.mandatory) {
    validation = Validators.required;
}
if(item.type=='DATEBOX' && item.dbColumnName==config.dbColumnName && item.dbdateValue){
  let dateValue = this.commonTransformerService.getDatepickerFormat(item.dbdateValue);
 value= new Date(dateValue);
}
else if(item.type=='LOOKUP' && item.dbColumnName==config.dbColumnName && item.referenceDataValue){
   value = item.referenceDataValue.name;
}
  let control = this.fb.control({ 'value': value, 'disabled': isDisabled }, validation);
  control.valueChanges.subscribe(res => {
    this.controlChange(control, config);
})
  return control;
}

   // method triggered when change in form control
    public controlChange(ctrl, attr){
      if(attr.type == 'LOOKUP'){
          this.getFilteredLookup(ctrl,attr);
      }
      this.createTaskDetails();
      // this.llrService.setFormValidation();
  }

      //method triggered when lookup input change
      public getFilteredLookup(ctrl,attr){
        this.optionValue=ctrl.value;
        let urlForLookup = this.lookupUrl + '/' + attr.source + '/' + attr.group + '/' 
        if(attr.referenceDataValue && attr.referenceDataValue.id && ctrl.value == attr.referenceDataValue.name){
            urlForLookup = urlForLookup+ attr.referenceDataValue.id;
        }else{
            delete attr['referenceDataValue']
            urlForLookup = urlForLookup+  ctrl.value;
        }
        this.clientService.setUrl(urlForLookup);
        this.clientService.getClientData().subscribe(response => {
               attr.attributeOptions = response;
        }) 
    }

    public checkLookupSelectedValue(lokupAttr,ctrl,lookupData){
      if(lookupData.attributeOptions && lookupData.attributeOptions.length>=0){
          let selLookupval=lookupData.attributeOptions.find(x=>x.name==ctrl.value);
          if(!selLookupval && !lookupData.referenceDataValue){
              ctrl.setValue('');
          }             
   }
}

public lookupOptionSelected(valSelected,config){
  this.taskDetailsForm.controls[config.dbColumnName].setValue(valSelected.option.value);
  config['referenceDataValue'] = config.attributeOptions.find(x => x.name == valSelected.option.value);
}

public getLookupData(data, controlName) {
  this.lookupVal = [];
  let urlForLookup = this.lookupUrl + '/' + data.source + '/' + data.group + '/';
  
  if(data.referenceDataValue && data.referenceDataValue.id && data.value == data.referenceDataValue.name){
      urlForLookup = urlForLookup+ data.referenceDataValue.id;
  }
  this.clientService.setUrl(urlForLookup);
  this.clientService.getClientData().subscribe(response => {
      data.attributeOptions = response;
  })       
}

createTaskDetails() {
  let attributeMap: any = {};
  let sectionAttrHolderObject: any;

  this.attributeHolder = [];    
  for (let attribute of this.taskDetailsAttributes[0].attributes) {
    let val: any
    if (attribute.value != undefined) {
      val = attribute.value;
    }
    else {
      val = this.taskDetailsForm.controls[attribute.dbColumnName].value;
    }

    if (attribute.type == 'LABEL') {
      let taskObj = {
        attrId: attribute.attrId,
        dbColumnName: attribute.dbColumnName,
        type: attribute.type,
        value: val
      }
      this.attributeHolder.push(taskObj);
    }
    else if (attribute.type == "DATEBOX") {
      let convertedDate;
      if (val) {
        convertedDate = this.commonTransformerService.dateInServiceFormat(val);
      }
      let diaryObj = {
        attrId: attribute.attrId,
        dbColumnName: attribute.dbColumnName,
        type: attribute.type,
        dateValue: convertedDate
      }
      this.attributeHolder.push(diaryObj);
    }  
    else if (attribute.type == "LOOKUP") {
      let referenceObj: any = {
        refDataId: '',
        name: '',
        code: ''
      }     
      if (val && val != '') {
        let itemFound = attribute.attributeOptions.find(x => x.name == val);
        if (itemFound) {
          referenceObj["code"] = itemFound.id;
          referenceObj["refDataId"] = itemFound.refDataId;
          referenceObj["name"] = itemFound.name;
        }
        else {
          if (attribute.referenceDataValue && attribute.referenceDataValue.name == val) {
            referenceObj["code"] = attribute.referenceDataValue.id;
            referenceObj["refDataId"] = attribute.referenceDataValue.refDataId;
            referenceObj["name"] = attribute.referenceDataValue.name;
          }
        }
      }
      let taskObj = {
        attrId: attribute.attrId,
        referenceDataValue: referenceObj,
        dbColumnName: attribute.dbColumnName,
        type: attribute.type,
        value: val
      }
      this.attributeHolder.push(taskObj);
    }
  }

  sectionAttrHolderObject = {
    "sectionName": this.taskDetailsAttributes[0].sectionName,
    "attributeMap": this.attributeHolder
  }
  this.llrService.setTaskDetailsData(sectionAttrHolderObject);
  // this.llrService.setTaskDetailsDataObservable(sectionAttrHolderObject);
}
}
