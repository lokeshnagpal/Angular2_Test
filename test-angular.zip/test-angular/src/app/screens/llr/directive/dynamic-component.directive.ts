import { Constants } from './../../../util/application.constants';

import { LLRService } from './../llr.service';
import { ClaimInformationComponent } from './../../../shared/ui/claim-information/claim-information.component';
import { RichTextComponent } from './../../../shared/ui/rich-text/rich-text.component';
import { DynamicFormComponent } from './../../../shared/ui/dynamic-form/dynamic-form.component';
import { ParticipantsComponent } from './../../../shared/ui/participants/participants.component';
import { ClaimDescComponent } from './../../claim-summary/claim-desc/claim-desc.component';
import { CommentListComponent } from './../../../shared/ui/comment-list/comment-list.component';
import { PostCommentComponent } from './../../../shared/ui/post-comment/post-comment.component';
import {Input, Directive,OnInit,ComponentFactoryResolver,ComponentRef,ViewContainerRef } from '@angular/core';
import { FinancialInformationComponent } from 'src/app/shared/ui/financial-information/financial-information.component';
import {LLrDocumentViewComponent} from 'src/app/screens/llr/component/llr-document-view/llr-document-view.component'


//TODO ADD ALL THE DIFFERENT SUPPORTED COMPONENTS OF LLR
const components :{[type:string]:any} ={
'PARTICIPANTS':ParticipantsComponent,
// 'CLAIM_DESCRIPTION':ClaimDescComponent,
'CLAIM_DESCRIPTION':RichTextComponent,
// 'LLR_CLAIM_INFORMATION':DynamicFormComponent,
'LLR_CLAIM_INFORMATION':ClaimInformationComponent,
'LLR_FINANCIAL_INFORMATION':FinancialInformationComponent,
'LLR_ADDITIONAL_DETAILS':DynamicFormComponent,
// 'LLR_ABOUT_FINANCIALS':DynamicFormComponent,
'LLR_SUBROGATION_SALVAGE_RECOVERY':RichTextComponent,
'FIRST_LEVEL_APPROVER':DynamicFormComponent,
'FINAL_APPROVER':DynamicFormComponent,
'DELEGATED_TO':DynamicFormComponent,
'LLR_LIABILITY_AND_QUANTUM_COVERAGE':RichTextComponent,
'LLR_PROPOSED_RESERVE_MOMENT':RichTextComponent,
'LLR_RELEVANT_DOCUMENTS':LLrDocumentViewComponent,
'MEETING_DATE':DynamicFormComponent,
'LLR_RT_SCHEDULER':DynamicFormComponent,
'LLR_MAILBOX_DETAILS':DynamicFormComponent
}



@Directive({
  selector: '[appDynamicComponent]'
})
export class DynamicComponentDirective implements OnInit {
component:ComponentRef<any>;
@Input() section:any;
@Input() sectionDetails:any;
@Input() usersRoleStatus:any;

  constructor(private resolver:ComponentFactoryResolver,private container:ViewContainerRef,public llrService:LLRService) { }

  ngOnInit() {
    if(!components[this.section.sectionCode]) {
      const supportedTypes =Object.keys(components).join(', ');
      throw new Error(` Trying to use an unsupported type (${this.section.sectionCode}).
      Supported types are : ${supportedTypes}`)
    }

    const component =this.resolver.resolveComponentFactory<any>(components[this.section.sectionCode]);
    this.component=this.container.createComponent(component);
    //TODO SET COMMON PARAMETERS FOR THE COMPONENT TO INITIALIZE
    this.component.instance.section=this.section;   
    this.component.instance.usersRoleStatus=this.usersRoleStatus
    this.component.instance.sectionDetails=this.sectionDetails;
    
    if(this.section.sectionCode!=="DELEGATED_TO" && this.section.sectionCode !==Constants.LLR_MAILBOX_DETAILS )  {
      // this.component.instance.isDisableField=this.llrService.checkDisableEditableSection(this.usersRoleStatus);    
      // this.component.instance.isDisableField=this.llrService.checkDisableEditableSection(this.usersRoleStatus,this.section);   
      this.component.instance.section.isDisableField=this.llrService.checkDisableEditableSection(this.usersRoleStatus,this.section);
    }
    // if(this.section.sectionCode==="RT Description Approval" && 
    //    this.usersRoleStatus.status ===Constants.SENT_TO_LINE_MANAGER ||  this.usersRoleStatus.status ===Constants.DRAFT_APPROVED){
    //     this.component.instance.isDisableField=true;
    // }
        
    // if(this.section.sectionCode=="CLAIM_DESCRIPTION" || this.section.sectionCode=="LLR_SUBROGATION_SALVAGE_RECOVERY"){  
      const index=this.section.attributes.findIndex(x => x.type==="RICHCOMMENTTEXTAREA")
      if(index!=-1){
        this.component.instance.isEdit=!this.component.instance.section.isDisableField;
        this.component.instance.descriptionData= this.component.instance.section.attributes[0].value;
        this.component.instance.descLabel=this.component.instance.section.sectionName
      }
     
    //  }
  }
  
}

