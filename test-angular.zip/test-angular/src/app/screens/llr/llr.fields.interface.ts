import { Constants } from './../../util/application.constants';


export interface DialogProperties  {
    headerName?: string;
    placeholder?: any;
    actionButton?:string;
    width?:number;
    hieght?:number;
    message?:string;
  }

  export class LLRContextProperties{
      subscription?:any;
      taskTypeSubscription?:any;
    resRecieved?: boolean = false;
    isTaskCreated?: boolean = false;
    startTaskUrl?: string;
    taskDetailsServiceUrl?: any;
    commentsServiceUrl?: any;
    commentsData?: any = [];
    showNoComments?: boolean = true;
    disableStartTask?: boolean = false;
    queryParams?: any;
    showProgressBar?: any;
    taskTypeObject?: any = {};
    attributeMap?: any = null;
    // disableTaskButton?: boolean = true;
    processSteps?: boolean;
    financialData?: any;
    llenDetails?: any = {};
    startTaskObj?: any = {
      "newtask": true,
      "nextStatusId": 41,
      "buttonName": "Save",
    }
  
    newTask?: boolean = false;
    refNum?: string;
    isComposedMeeting?: boolean = false;
    // isTaskTypeAndLLEN?: boolean = true;  
    isTaskType?:boolean=true;
    liablityQuantumKey?:string = "liablityQuantumKey";
    proposedReservedKey?:string = "proposedReservedKey";
    outcomeRTKey?:string = "outcomeRTKey";
    liablityQuantumHeader?: string = Constants.LIABILITY_QUATUM_COVERAGE;
    proposedReservedHeader?: string = Constants.PROPOSED_RESERVE_MOVEMENT;
    outcomeRTHeader?: string = Constants.OUTCOME_RT_HEADER;
    llenComment?: string;
    actionDialogComments?: string;
    finalApprover?: any;
    taskLogGroup?: any = [];
    usersRoleStatus?: any = {};
    isLoadTaskDetails?: boolean = true;
    isEdit?: boolean = true;
    tab?: any;
    claimNumber?: any;
    taskNumber?: any;
    taskType?:any={};
    meetingDate?:any;
    participants?:any;
    mailInbox?:any;
    financialInfo?:any;
    participantComment?:any=[];
    participantLogGroup?:any=[];
    isAdditionalInfoRequired?:boolean=false;;
  }

  export class TaskDetailsProperties {
    taskNumber?: string;
    taskId?: string=null;
    claimNumber?:string;
	activityId?:string;
	mainLOB?:string;
	// taskDetails?:TaskDetails;
	region?:string;
	type?:ReferenceData={};
	status?:string;
    dueDate?:string;
	category?:string;
	priority?:string;
	assignee?:string;
	userId?:string;  
    attributes?:Attribute[];
    openDiary?:boolean;
    closedDiary?:boolean;
    sendNotification?:boolean;
    updatedDate?:string;
	taskAdditionalDetails?:TaskAdditionalDetails={};
	// comments?:TaskComments[];
    // commentsGroup?:TaskCommentsGroup[];
	 actionButtons?:TaskActionButton[];
    // sectionDetails?:SectionDetails[];
	//  processSteps?:ProcessSteps[];
    //  isReserveMovement?:string;
	 displayedIn?:string;
	 createdDate?:string;
	 financialsData?:FinancialsData;
	// private Map<String, String> filterCriteria;
	refNum?:string ; 
	liablityQuantum?:string;
	proposedReserved?:string;
	outcomeRT?:string;
	taskNumbers?:string[]; 
    action?:string; 
    userRole?:string;  
    prevStatus?:string;
    rtCategory?:string;
    sectionDetails?:any=[];
  }

  export class ReferenceData extends TaskDetailsProperties{
     code?:string;
     name?:string;
     selectable?:string;
     group?:number;
     showOnlyId?:boolean;    
     showOnlyValue?: boolean;
     showDisplayValue?:boolean;    
      id?:string;
      eventFired?:boolean;
      removed?:boolean;
      customFilter?:boolean;
      pomPolicySearch?:boolean;
     }
export interface Attribute{
    attributeDataId?: number;
    attributeOptions?:string[]; 
    attrId?:number;
    // attrRules?: FieldRule[];
    columnIndex?:number;
    dbColumnName?:string,   
    mandatory?:boolean;
    name?:string;
    readOnly?:boolean; 
    value?:string; 
    sectionName?: string;
    sectionCode?:string;   
    dbvalue?:string;   
    hidden?:boolean;
    dbdateValue?:string;
    bigDecimalValue?:string;
    referenceDataValueList?:any[];
  }
  export interface TaskAdditionalDetails extends TaskDetailsProperties {
    sectionDetails?:SectionDetails[];
  }
  export class SectionDetails{
    sectionName?:string;
    sectionCode?:string;
    attributes?:Attribute[];
    isExpand?:boolean;
   
    }

export interface TaskActionButton{
    buttonName?:string;
    statusCode?:string;
    nextStatusId?:number;
    commentMandInd?:string;
    primary?: boolean;
}

// export interface ProcessSteps{}
export interface FinancialsData{
    indemnityBeforeIncurred?:string;
    indemnityProposedIncurred?:string;
    indemnityAfterIncurred?:string;
    expenseBeforeIncurred?:string;
    expenseProposedIncurred?:string;
    expenseAfterIncurred?:string;
    totalBeforeIncurred?:string;
    totalProposedIncurred?:string;
    totalAfterIncurred?:string;
}


 