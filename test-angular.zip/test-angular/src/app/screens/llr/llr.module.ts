import { LlrCommentsDialogComponent } from './component/llr-comments-dialog/llr-comments-dialog.component';
import { LlrParticipantsDialogComponent } from './component/llr-participants-dialog/llr-participants-dialog.component';
import { SharedModule } from './../../shared/shared.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LlrRoutingModule } from './llr-routing.module';
import { LLrContainerComponent } from './llr-container/llr-container.component';
import { LLRDeskTopComponent } from './component/llrdesk-top/llrdesk-top.component';
import { LLRMobileComponent } from './component/llrmobile/llrmobile.component';
import { LLRComponent } from './component/llr/llr.component';
import { DynamicComponentDirective } from './directive/dynamic-component.directive';
// import { LLROverviewDesktopComponent } from './component/llr-overview-desktop/llr-overview-desktop.component';
import { TaskTypeComponent } from './component/task-type/task-type.component';
import { TaskDetailsComponent } from './component/task-details/task-details.component';
// import { LLROverviewMobileComponent } from './component/llr-overview-mobile/llr-overview-mobile.component';
// import { LLROverviewComponent } from './component/llr-overview/llr-overview.component';
import { LlenSectionComponent } from './component/llen-section/llen-section.component';
import { LlrActionDialogComponent } from './component/llr-action-dialog/llr-action-dialog.component';
import {LLrDocumentViewComponent} from 'src/app/screens/llr/component/llr-document-view/llr-document-view.component'
import { PdfViewerModule } from 'ng2-pdf-viewer';

@NgModule({
 
  imports: [
    CommonModule,
    SharedModule,
    LlrRoutingModule,
    PdfViewerModule
  ],
 entryComponents:[LlrParticipantsDialogComponent,LlrCommentsDialogComponent,LlrActionDialogComponent, LLrDocumentViewComponent],
  declarations: [LLrContainerComponent, LLRDeskTopComponent, LLRMobileComponent, LLRComponent, DynamicComponentDirective,
   
    TaskTypeComponent, TaskDetailsComponent, LlrParticipantsDialogComponent,LlrCommentsDialogComponent, LlenSectionComponent, LlrActionDialogComponent, LLrDocumentViewComponent]
})
export class LlrModule { }
