import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FinancialDesktopComponent } from './component/financial-desktop/financial-desktop.component';
import { ClaimDetailsComponent } from './component/claim-details/claim-details.component';

const routes: Routes = [

  {
    path: '',
    component: FinancialDesktopComponent,
    children: [
    ]
  },
  {
    path: 'claim',
    component: ClaimDetailsComponent,
    children: [
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FinancialRoutingModule { }
