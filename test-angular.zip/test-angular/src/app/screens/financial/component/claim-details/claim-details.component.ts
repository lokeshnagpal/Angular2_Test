import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-claim-details',
  templateUrl: './claim-details.component.html',
  styleUrls: ['./claim-details.component.scss']
})
export class ClaimDetailsComponent implements OnInit {

  showProgressBar: boolean = false;
  context: any = {
    businessArea: 'EMEAPROPUW',
    status: 'TO_BE_INDEXED'
  };
  sections = [
    {
      'label': 'Basic Information',
      'attributes': [
        {
          attrId: 1,
          dbColumnName: 'CLAIM_STATUS',
          name: 'Claim Status',
          secAttrMapId: '1001',
          type: 'ICONLOOKUP',
          mandatory: false,
          hidden: false,
          readonly: false,
          source: 'CLAIMS',
          group: 'CLAIM_STATUS',
        },
        {
          attrId: 2,
          dbColumnName: 'DATE_OF_LOSS',
          name: 'Date of Loss',
          secAttrMapId: '1002',
          type: 'DATE',
          mandatory: true,
          hidden: false,
          readonly: false
        },
        {
          attrId: 3,
          dbColumnName: 'LOSS_TRIGGER',
          name: 'Trigger Relevant for Date of Loss',
          secAttrMapId: '1003',
          type: 'TEXTBOX',
          mandatory: false,
          hidden: false,
          readonly: false
        },
        {
          attrId: 4,
          dbColumnName: 'FIRST_REPORT_DATE',
          name: 'First Report Date to Swiss Re',
          secAttrMapId: '1004',
          type: 'DATE',
          mandatory: true,
          hidden: false,
          readonly: false
        },
        {
          attrId: 5,
          dbColumnName: 'CLAIM_HANDLER',
          name: 'Claim Handler',
          secAttrMapId: '1005',
          type: 'ICONLOOKUP',
          mandatory: true,
          hidden: false,
          readonly: false,
          source: 'CLAIM_HANDLER',
          group: 'CLAIM_HANDLER',
        },
        {
          attrId: 6,
          dbColumnName: 'CLAIM_TEAM',
          name: 'Claim Team',
          secAttrMapId: '1006',
          type: 'SIMPLELOOKUP',
          mandatory: false,
          hidden: false,
          readonly: false,
          source: 'CLAIM_TEAM',
          group: 'CLAIM_TEAM',
        },
        {
          attrId: 7,
          dbColumnName: 'INCOMING_CLIAM_HANDLER',
          name: 'Incoming Claim Handler',
          secAttrMapId: '1007',
          type: 'ICONLOOKUP',
          mandatory: false,
          hidden: false,
          readonly: false,
          source: 'INCOMING_CLIAM_HANDLER',
          group: 'INCOMING_CLIAM_HANDLER',
        },
        {
          attrId: 8,
          dbColumnName: 'CLAIM_TYPE',
          name: 'Type of Claim',
          secAttrMapId: '1008',
          type: 'SIMPLELOOKUP',
          mandatory: true,
          hidden: false,
          readonly: false,
          source: 'CLAIM_TYPE',
          group: 'CLAIM_TYPE',
        },
        {
          attrId: 9,
          dbColumnName: 'LIGITATION',
          name: 'Litigation',
          secAttrMapId: '1009',
          type: 'CHECKBOX',
          mandatory: false,
          hidden: false,
          readonly: false
        },
        {
          attrId: 10,
          dbColumnName: 'OCCURRENCE',
          name: 'Integrated Occurrence',
          secAttrMapId: '1010',
          type: 'CHECKBOX',
          mandatory: false,
          hidden: false,
          readonly: false
        },
        {
          attrId: 11,
          dbColumnName: 'BULK_CLAIM',
          name: 'Bulk Claim',
          secAttrMapId: '1011',
          type: 'CHECKBOX',
          mandatory: false,
          hidden: false,
          readonly: false
        }
      ]
    },
    {
      'label': 'ITC',
      'attributes': [
        {
          attrId: 1,
          dbColumnName: 'ITC_STATUS',
          name: 'ITC Status',
          secAttrMapId: '2001',
          type: 'SIMPLELOOKUP',
          mandatory: false,
          hidden: false,
          readonly: false,
          source: 'ITC_STATUS',
          group: 'ITC_STATUS'
        },
        {
          attrId: 2,
          dbColumnName: 'ITC_UPDATE_DATE',
          name: 'ITC Update Date',
          secAttrMapId: '2002',
          type: 'DATE',
          mandatory: false,
          hidden: false,
          readonly: false
        },
        {
          attrId: 3,
          dbColumnName: 'ITC_UPDATED_BY',
          name: 'ITC Updated By',
          secAttrMapId: '2003',
          type: 'SIMPLELOOKUP',
          mandatory: false,
          hidden: false,
          readonly: false,
          source: 'ITC_UPDATED_BY',
          group: 'ITC_UPDATED_BY'
        }
      ]
    },
    {
      'label': 'Global Loss Information',
      'attributes': [
        {
          attrId: 1,
          dbColumnName: 'TEAM_EVENT',
          name: 'Team Event',
          secAttrMapId: '3001',
          type: 'CHECKBOX',
          mandatory: false,
          hidden: false,
          readonly: false
        },
        {
          attrId: 2,
          dbColumnName: 'TEAM_EVENT_NUMBER',
          name: 'Team Event No.',
          secAttrMapId: '3002',
          type: 'LOOKUP',
          mandatory: false,
          hidden: false,
          readonly: false,
          source: 'TEAM_EVENT_NUMBER',
          group: 'TEAM_EVENT_NUMBER'
        },
        {
          attrId: 3,
          dbColumnName: 'TEAM_EVENT_DESCRIPTION',
          name: 'Team Event Description',
          secAttrMapId: '3003',
          type: 'TEXTAREA',
          mandatory: false,
          hidden: false,
          readonly: false
        }
      ]
    },
    {
      'label': 'Damage \ Loss Information',
      'attributes': [
        {
          attrId: 1,
          dbColumnName: 'ACCIDENT_DATE',
          name: 'Date of Accident',
          secAttrMapId: '4001',
          type: 'DATE',
          mandatory: false,
          hidden: false,
          readonly: false
        },
        {
          attrId: 2,
          dbColumnName: 'EVENT_LOCATION',
          name: 'Event / Accident Location',
          secAttrMapId: '4002',
          type: 'SIMPLELOOKUP',
          mandatory: false,
          hidden: false,
          readonly: false,
          source: 'EVENT_LOCATION',
          group: 'EVENT_LOCATION'
        },
        {
          attrId: 3,
          dbColumnName: 'LOSS_COUNTRY',
          name: 'Loss Country',
          secAttrMapId: '4003',
          type: 'SIMPLELOOKUP',
          mandatory: false,
          hidden: false,
          readonly: false,
          source: 'LOSS_COUNTRY',
          group: 'LOSS_COUNTRY'
        },
        {
          attrId: 4,
          dbColumnName: 'LOSS_STATE',
          name: 'Loss State',
          secAttrMapId: '4004',
          type: 'SIMPLELOOKUP',
          mandatory: false,
          hidden: false,
          readonly: false,
          source: 'LOSS_STATE',
          group: 'LOSS_STATE'
        },
        {
          attrId: 5,
          dbColumnName: 'JURISDICTION',
          name: 'Jurisdiction / Venue',
          secAttrMapId: '4005',
          type: 'TEXTBOX',
          mandatory: false,
          hidden: false,
          readonly: false
        }
      ]
    },
    {
      'label': 'Claim Reference Nos.',
      'attributes': [
        {
          attrId: 1,
          dbColumnName: 'REINSURED_REFERENCE_NUMBER',
          name: 'Claim Reference No. of Reinsured',
          secAttrMapId: '5001',
          type: 'TEXTBOX',
          mandatory: false,
          hidden: false,
          readonly: false
        },
        {
          attrId: 2,
          dbColumnName: 'BROKER_REFERENCE_NUMBER',
          name: 'Claim Reference No. of Broker',
          secAttrMapId: '5002',
          type: 'TEXTBOX',
          mandatory: false,
          hidden: false,
          readonly: false
        },
        {
          attrId: 3,
          dbColumnName: 'LEADER_REFERENCE_NUMBER',
          name: 'Claim Reference No. of Leader',
          secAttrMapId: '5003',
          type: 'TEXTBOX',
          mandatory: false,
          hidden: false,
          readonly: false
        },
        {
          attrId: 4,
          dbColumnName: 'NETWORK_REFERENCE_NUMBER',
          name: 'Claim Reference No. of Network Partner',
          secAttrMapId: '5004',
          type: 'TEXTBOX',
          mandatory: false,
          hidden: false,
          readonly: false
        },
        {
          attrId: 5,
          dbColumnName: 'EXTERNAL_REFERENCE_NUMBER',
          name: 'Claim Reference No. of External',
          secAttrMapId: '5005',
          type: 'TEXTBOX',
          mandatory: false,
          hidden: false,
          readonly: false
        }
      ]
    }
  ];

  constructor() { }

  ngOnInit() {
  }

  logger(event) {
    console.log(event);
  }
}
