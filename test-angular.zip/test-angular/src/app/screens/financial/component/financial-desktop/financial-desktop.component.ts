import { Component, OnInit, ViewChild } from '@angular/core';
import { ClientService } from './../../../../services/client.service';
import { environment } from './../../../../../environments/environment';
import { Financial, FinancialBookingDetailsComponent, IFinancialBookingDetails, PaymentTypeEnum, } from 'mh-financials';
import { MatDialog } from '@angular/material';
import { SearchLocationDialog } from 'src/app/shared/ui/search-location-dialog/search-location-dialog.component';

@Component({
  selector: 'app-financial-desktop',
  templateUrl: './financial-desktop.component.html',
  styleUrls: ['./financial-desktop.component.scss']
})
export class FinancialDesktopComponent implements OnInit {
 
  showProgressBar: boolean = false;
  sections: any = null;

  documentList: any[];
  getDocumentsUrl: string = '';
  pdfSrc: string;
  isFormValid: boolean = false;
  
  context: any = {
    businessArea: 'EMEAPROPUW',
    status: 'TO_BE_INDEXED'
  };
  screen: string = 'task';
  submitButton: any = {
    label: 'NEW BOOKING'
  };
  public financial: Financial = { bookingNumber: 10987126 , paymentType: PaymentTypeEnum.LossPayment };
  @ViewChild(FinancialBookingDetailsComponent, {static: false}) financialBookingDetailsComponent: IFinancialBookingDetails;

  constructor(public clientService: ClientService, public dialog: MatDialog) { }

  ngOnInit() {
    this.clientService.setUrl(environment.financialUrl);
    this.clientService.getClientData().subscribe(response => {
      this.sections = response.sectionDetails;
    });
    this.getDocumentsUrl = environment.documentUrl + 'WORK_ITEM/147230';
    this.clientService.setUrl(this.getDocumentsUrl);
    this.clientService.getClientData().subscribe(response => {
      this.documentList = response;
    });
  }

  launchDocument() {
    window.open(this.pdfSrc);
  }

  loadDocument(event) {
    const docId = event.doc_id;
    this.pdfSrc = environment.streamingServlet + '?docId=' + docId + '&appName=NATIVE&openInline=Y';
  }

  onSubmit() {
    if (this.screen == 'booking') {
      this.showProgressBar = true;
      this.financialBookingDetailsComponent.onAsyncCreateBooking().subscribe(response => {
        console.log(response);
        this.showProgressBar = false;
        this.isFormValid = false;
        this.submitButton.label = 'SEND FOR APPROVAL';
        this.screen = 'claims';
      }, error => {
        alert(error);
        console.log(error);
        this.showProgressBar = false;
      });
    } else if (this.screen == 'task') {
      this.screen = 'booking';
      this.isFormValid = true;
      this.submitButton.label = 'CREATE BOOKING';
    }
  }

  validateForm(event) {
    console.log(event);
    if (event.valid) {
      this.isFormValid = true;
    } else {
      this.isFormValid = false;
    }
  }

  onActionPerformed(event) {
      console.log(event);
  }

  selectLocation() {
    const data = {
      header: 'Select Booking Location',
      claimNumber: '12345',
      select: 'DONE',
      cancel: 'CANCEL'
    };
    const dialogRef = this.dialog.open(SearchLocationDialog, {
      width: '65%',
      minWidth: '480px',
      height: '85%',
      data,
      autoFocus: false
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        console.log(result);
      }
    });
  }

}
