import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FinancialDesktopComponent } from './financial-desktop.component';

describe('FinancialDesktopComponent', () => {
  let component: FinancialDesktopComponent;
  let fixture: ComponentFixture<FinancialDesktopComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FinancialDesktopComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FinancialDesktopComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
