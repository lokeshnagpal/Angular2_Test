import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from './../../shared/shared.module';
import { FinancialRoutingModule } from './financial-routing.module';
import { FinancialDesktopComponent } from './component/financial-desktop/financial-desktop.component';
import { FinancialsModule } from 'mh-financials';
import { environment } from 'src/environments/environment';
import { ClaimDetailsComponent } from './component/claim-details/claim-details.component';

@NgModule({
  declarations: [FinancialDesktopComponent, ClaimDetailsComponent],
  imports: [
    CommonModule,
    SharedModule,
    FinancialRoutingModule,
    FinancialsModule.forRoot(environment)
  ]
})
export class FinancialModule { }
