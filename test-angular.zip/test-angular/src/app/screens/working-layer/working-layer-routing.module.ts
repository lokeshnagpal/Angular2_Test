import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { WorkingLayerComponent } from './component/working-layer/working-layer.component';

const routes: Routes = [

  {
    path: '',
    component: WorkingLayerComponent,
    children: [
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class WorkingLayerRoutingModule { }
