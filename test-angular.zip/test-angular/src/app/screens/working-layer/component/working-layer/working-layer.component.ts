import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { Component, ElementRef, ViewChild, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatAutocompleteSelectedEvent, MatAutocomplete } from '@angular/material/autocomplete';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatChipInputEvent } from '@angular/material/chips';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { ActivatedRoute, Router } from '@angular/router';
import { MindMapComponent } from './../../../../shared/ui/mind-map/mind-map.component';
import { environment } from './../../../../../environments/environment'
import { ClientService } from './../../../../services/client.service'
import { CommonTransformerService } from 'src/app/util/common-transformer.service';
import { CurrencyPipe } from '@angular/common';

@Component({
  selector: 'app-working-layer',
  templateUrl: './working-layer.component.html',
  styleUrls: ['./working-layer.component.scss']
})

export class WorkingLayerComponent implements OnInit {
  public currentClaim;    //stores layer number value for showiing current layer
  public currentAtttachingClaimNumber;      //variable to store initial value of attaching claim in case a person cancels
  public claimNumber;     //stores current claim number
  public selectable = true;   
  public removable = true;
  public  serviceData;     //stores the copy of data from service
  public excessTowerId;    
  public attachedClaimArray = [];     //array to keep values of all the attaching claim in the current tower structure
  public filterCurrencyUrl;       
  public filterMarketPositionUrl;
  public currency;     //stores currency selected object
  public followPosition;
  public currencySelected;    //stores currency selected object
  public followPositionSelected;
  public addOnBlur=true;
  public workingLayers = [];    //store the array layerdetails comming from service and the current editing variable
  public separatorKeysCodes: number[] = [ENTER, COMMA];
  public allinsurers: string[] = ['Swiss Re'];
  public showCard = false;      //boolean variable to store the variable to show mindmap
  public existingTowerStructure;       //stores a boolean to decide wheather to show the warning or not
  public participantsCtrl = new FormControl();
  public filteredInsurers: Observable<string[]>;
  public attachingClaimlookupUrl;  
  @ViewChild('insuredInput', {static: false}) insuredInput: ElementRef<HTMLInputElement>;
  @ViewChild('auto', {static: false}) matAutocomplete: MatAutocomplete;

  ngOnInit() {
    //settign url for all the lookups and making call for current claim number from service
    this.attachingClaimlookupUrl=environment.cccLookupUrl+'STATIC_REFDATA/CLAIM_NUMBER/';
    this.filterCurrencyUrl = environment.cccLookupUrl+'REFDATA/FGU_CURRENCY/';  
          this.filterMarketPositionUrl = environment.cccLookupUrl+'REFDATA/Follow%20Description%20/'
    this.clientService.setUrl(environment.workingLayerUrl + "/" + this.claimNumber)
    this.clientService.getClientData().subscribe(response => {
      this.serviceData = response   
      this.servicetocomponent(this.serviceData.isOtherTowerLinked)
    });
  }

  constructor(protected route: ActivatedRoute, private clientService: ClientService, public commonTransformerService: CommonTransformerService,
    private currencyPipe:CurrencyPipe
  ) {
    //code to retrieve claim number from url
    this.route.queryParams.subscribe(params => {
      this.claimNumber = params['claimNumber'];
    });
      //Code for mat MatChip to push filtered list in filteredInsurers
    this.filteredInsurers = this.participantsCtrl.valueChanges.pipe(
      map((insurer: string | null) => insurer ? this._filter(insurer) : this.allinsurers.slice()));
  }

  public servicetocomponent(otherTower) {
 //cases made on the value of isOtherTowerLinked variable 
    switch (otherTower) {
      case null: {
        //nothing exists for the claim and for the policy also
        this.existingTowerStructure = false;
        this.workingLayers = [];
        break;
      }
      case true: {
        //claim doesnot have tower structure but the policy has predefined tower structure which can be used
        this.existingTowerStructure = true;
        this.workingLayers = [];
        break;
      }
      case false: {
        // calim queried ahs predefined TowerStructure showing it to edit
        this.existingTowerStructure = false;
        this.excessTowerId = this.serviceData.excessTowerId;
        this.currency = this.serviceData.currency;
        if(this.serviceData.currency!=null){
        this.currencySelected = this.serviceData.currency.code
        }
        this.followPosition = this.serviceData.followPosition;
        if(this.serviceData.followPosition!=null){
        this.followPositionSelected = this.serviceData.followPosition.name;
        }
        // this.workingLayers =this.serviceData.layerDetails.map(el=>{
        //   this.attachedClaimArray.push(el.attachingClaim)
        //   if(el.attachingClaim===this.claimNumber){
        //           this.currentClaim=(el.layerNumber-1);
        //   }
        //   return {
        //     "layerNumber":el.layerNumber,
        //     "participants":[...el.participants],
        //     "attachingClaim":el.attachingClaim,
        //     "amount": this.numberToComma(el.amount,'amount'),
        //     "excessAmount":this.numberToComma(el.excessAmount,'excessAmount'),
        //     "showAttachClaim":false,
        //     "lastElement": (el.layerNumber=this.serviceData.layerDetails.length)? true:false,
        //     "hasSwissRe": (el.participants.includes("Swiss Re"))?  true:false
        //   }
        // })
        //   break;
        // }
        this.workingLayers = this.serviceData.layerDetails.map(x => Object.assign({}, x));
        for (let i = 0; i < this.serviceData.layerDetails.length; i++) {
          if(this.serviceData.layerDetails[i].participants!=null){
          this.workingLayers[i].participants = [...this.serviceData.layerDetails[i].participants]
          }
          else{
            this.workingLayers[i].participants=[];
          }
          this.workingLayers[i].amount= this.numberToComma(this.serviceData.layerDetails[i].amount)
          this.workingLayers[i].excessAmount= this.numberToComma(this.serviceData.layerDetails[i].excessAmount)
          this.workingLayers[i].showAttachedClaim = false;
          this.attachedClaimArray.push(this.serviceData.layerDetails[i].attachingClaim)
          if (i == (this.serviceData.layerDetails.length - 1)) {
            this.workingLayers[i].lastElement = true
          }
          else {
            this.workingLayers[i].lastElement = false
          }
          if (this.serviceData.layerDetails[i].participants!=null && this.serviceData.layerDetails[i].participants.includes("Swiss Re")) {
            this.workingLayers[i].hasSwissRe = true
          }
          else {
            this.workingLayers[i].hasSwissRe = false
          }
          if(this.serviceData.layerDetails[i].attachingClaim===this.claimNumber){
            this.currentClaim=i;
          }
        }
        break;
      }
    }
  }

  public details() {
    this.showCard = !this.showCard;
  }

  public addLayer() {
    let obj: any = {
      "layerNumber": this.workingLayers.length + 1,
      "amount": null,
      "excessAmount": "",
      "participants": [],
      "attachingClaim": "",
      "lastElement": true,
      "hasSwissRe": false,
      "showAttachedClaim": false
    }
    if (this.workingLayers.length > 0) {
      this.workingLayers[this.workingLayers.length - 1].lastElement = false;
    }
    this.workingLayers.push(obj);
    this.attachedClaimArray.push("")
  }

  //Delete a 
  public delete(i) {
    
    this.workingLayers.pop();
    if (this.workingLayers.length > 0) {
      this.workingLayers[this.workingLayers.length - 1].lastElement = true;
    }
    if(this.currentClaim==i){
      this.currentClaim=null;
    }
    this.attachedClaimArray.pop();
  }

  //Reset
  public reset(i) {
    // if (this.currentClaim == layer.layerNumber - 1) {
    //   this.currentClaim = null;
    // }
    if(this.workingLayers[i-1].attachingClaim===this.claimNumber){
      this.currentClaim=null;
    }
    this.attachedClaimArray[i-1]=""
    // if (i <= this.serviceData.layerDetails.length) {
    //   this.workingLayers[i - 1] = Object.assign({}, this.serviceData.layerDetails[i - 1])
    //   this.workingLayers[i - 1].lastElement = false;
    //   this.workingLayers[i - 1].hasSwissRe = (this.serviceData.layerDetails[i-1].participants.includes("Swiss Re"))?  true:false;
    //   this.workingLayers[i - 1].showAttachedClaim = false;
    //   this.workingLayers[i - 1].participants = [...this.serviceData.layerDetails[i - 1].participants]
    // }else {
      this.clear(i - 1)
    // }
  }

  //Edit functionaties
  public showAttachClaim(layer, i) {
    this.workingLayers[i].showAttachedClaim = true;
    this.currentAtttachingClaimNumber = layer.attachingClaim
  }

  public close(i) {
    // this.workingLayers[i].hasSwissRe = true;
    this.workingLayers[i].showAttachedClaim = false;
    this.workingLayers[i].attachingClaim = this.currentAtttachingClaimNumber;
  }

  public saveAttachingClaim(i,claim) {
    //if removing attaching claim from current working layer
    if (claim == "" || claim==null) {
      this.attachedClaimArray[i] = ""
      if(this.currentClaim==i){
      this.currentClaim = null
    }
  }
    else if (this.attachedClaimArray.includes(claim)) {
      if (claim == this.attachedClaimArray[i]) {
        // this.currentClaim = i;
      }
      else {
        this.commonTransformerService.showError("claim number is already attached to other layer",3000)
        claim = ""
        this.attachedClaimArray[i] = "";
        this.workingLayers[i].attachingClaim=""
      }
    }
    else {
      this.attachedClaimArray[i] = claim
      if(this.claimNumber==claim)
      this.currentClaim = i;
      else if(this.currentClaim==i){
        this.currentClaim=null;
      }
    }
    this.workingLayers[i].showAttachedClaim = false;
  }
  
  public add(event: MatChipInputEvent, i): void {
    // Add participant only when MatAutocomplete is not open
    // To make sure this does not conflict with OptionSelected Event
    // this.matAutocomplete=new  MatAutocomplete();
    if (!this.matAutocomplete.isOpen) {
      const input = event.input;
      const value = event.value;
      // Add our participant
      if ((value || '').trim()) {
        if (value.trim() == "Swiss Re") {
          if (this.workingLayers[i].hasSwissRe == false) {
            this.workingLayers[i].participants.push(value.trim());
            this.workingLayers[i].hasSwissRe = true;
          }
        }
        else {
          this.workingLayers[i].participants.push(value.trim());
        }
      }
      // Reset the input value
      if (input) {
        input.value = '';
      }
      this.participantsCtrl.setValue(null);
    }
  }


  public selected(event: MatAutocompleteSelectedEvent, i): void {
    if (this.workingLayers[i].hasSwissRe == false) {
      this.workingLayers[i].participants.push(event.option.viewValue);
      this.workingLayers[i].hasSwissRe = true;
    }
    this.insuredInput.nativeElement.value = '';
    this.participantsCtrl.setValue(null);
  }

  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();
    return this.allinsurers.filter(insurer => insurer.toLowerCase().indexOf(filterValue) === 0);
}

  public remove(i, participant: string): void {
    if (participant == "Swiss Re") {
      this.workingLayers[i].hasSwissRe = false;
      this.workingLayers[i].attachingClaim=""
      if(this.currentClaim==i){
       this.currentClaim=null; 
      }
    }
    var index = this.workingLayers[i].participants.indexOf(participant);
    if (index >= 0) {
      this.workingLayers[i].participants.splice(index, 1);
    }
  }

  public clear(i) {
    
    let obj: any = {
      "layerNumber": this.workingLayers[i].layerNumber,
      "amount": null,
      "excessAmount": "",
      "participants": [],
      "attachingClaim": "",
      "lastElement": this.workingLayers[i].lastElement,
      "hasSwissRe": false,
      "showAttachedClaim": false
    }
    this.workingLayers[i] = Object.assign({}, obj);
  }

  public applyFilter(event, id,i?) {
    switch (id) {
      case "currency": {
        this.currencySelected = event.id;
        let currency = {
          "refDataId": event.refDataId,
          "code": event.id,
          "name": event.name
        }
        this.currency = currency
        break;
      }
      case "followPosition": {
        let followPosition = {
          "refDataId": event.refDataId,
          "code": event.id,
          "name": event.name
        }
        this.followPosition = followPosition
        break;
      }
      case "attachingClaim":{
        this.workingLayers[i].attachingClaim=event.name;
        break;
      }
    }
  }
numberToComma(value){
  if (value === null || value === "" || value === 0) {
    return value
  }
  else{
  const convNum = Number(value);
       if(value>999){
       let value1 = this.currencyPipe.transform(convNum,'USD',"code" , '1.0-0');
       return value1.replace( 'USD', "")
       }
      else{
        return value.toString();
      }
    }
  }
  onChange(event,i,property){
    if(/^[0-9,]*$/.test(event)){
 var num = event.replace('USD', "").replace(new RegExp(',', 'g'), '');
   const convNum = Number(num);
    switch (property){
      case 'amount':{
        this.workingLayers[i].amount = this.currencyPipe.transform(convNum,'USD',"code" , '1.0-0');
        this.workingLayers[i].amount = this.workingLayers[i].amount.replace( 'USD', "")
        break;
      }
      case 'excessAmount': {
        this.workingLayers[i].excessAmount = this.currencyPipe.transform(convNum,'USD',"code" , '1.0-0');
        this.workingLayers[i].excessAmount = this.workingLayers[i].excessAmount.replace( 'USD', "")
        break;
      }
    }
  }
  else{
    this.commonTransformerService.showError("Alphabets are not allowed",3000)
  }
 }

  commaFormatTonumber(value, type?) {
    if (value === null || value === "" || value === 0) {
      return value
    }
    else {
      if (value > 0) {
        if (type == 'number') {
          return Number(value)
        }
        else {
          return value
        }
      }
      else {
        let res = value.replace(/[, ]+/g, "").trim();
        if (type == 'number') {
          return Number(res)
        }
        else {
          return res
        }
      }
    }
  }

  //Save the data
  public save() {
   if(this.currency==null){
    this.commonTransformerService.showError("Currency cannot be empty",3000)
   }
   else{

    let postdata = {
      "excessTowerId": this.excessTowerId,
      "claimNumber": this.claimNumber,
      "currency": this.currency,
      "followPosition": this.followPosition,
      "layerDetails": this.workingLayers.map(el=>{
        return {
          "layerNumber": el.layerNumber,
          "amount": this.commaFormatTonumber(el.amount,'number'),
          "excessAmount": this.commaFormatTonumber(el.excessAmount),
          "participants": [...el.participants],
          "attachingClaim": el.attachingClaim
        }
    })
  }
  console.log(postdata)
    this.clientService.setUrl(environment.workingLayerUrl + "/")
    this.clientService.postLayer(postdata).subscribe(response =>
      {
        if (JSON.parse(response['_body']).excessTowerId!=0){
      this.excessTowerId=JSON.parse(response['_body']).excessTowerId;
        }
      this.commonTransformerService.showMessage("Saved Successfully", 3000)
    })
    console.log({action: "excess tower", actionBy: "",message:"Save success"})
    var message ={action: "excess tower", actionBy: "",message:"Save success"}
    window.parent.postMessage(JSON.stringify(message), '*');
 console.log(postdata)
  }
}
}


  // numberWithCommas(evt, val,i) {
  //   let value: any;
  //   let exceedLimitFlag=false;
  //   // item.controls.attributeValue1.status = "VALID";
  //   var invalidcharacters = /[^0-9]/gi;
  //   val = val.replace(/\,/g, '');
  //   // if (invalidcharacters.test(val)) {
  //   //   // item.controls.attributeValue1.status = "INVALID";
  //   //   // item.controls.attributeValue1.setErrors({ number: true, errorMsg: "Please enter only number" });
  //   //   alert("Please enter only number")
  //   // }
   
  //   if (parseInt(val) > 1000000000) {
  //       evt.preventDefault();
  //     //  val = val.substring(0, this.config.referenceDataValueList[index].attributeValue1.length - 1);
  //       if(val.length>10){
  //          val = val.substring(0, 9);
  //       }else{
  //         val = val.substring(0, 9);
  //       }
  //       // val = "1000000000";
  //     //  item.controls.attributeValue1.status = "INVALID";
  //     // item.controls.attributeValue1.setErrors({ limit: true, errorMsg: "should not more than 1 billion" });
  //     // item.controls.attributeValue1.setErrors({ limitOnly: true, errorMsg: "should not more than 1 billion" })
  //     exceedLimitFlag=true;
  //   }
  //     if(exceedLimitFlag){
  //       value = val.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
  //        let commaCount:any=value.split(',');
  //        commaCount=commaCount.length-1;
  //         // if(document.getElementById("attr1")!=null){
  //         //   document.getElementById("attr1").setAttribute('maxlength',10+commaCount.length);
  //         //   }   
  //     }else{
  //       value = val.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
  //     }
  //      this.workingLayers[i].excessAmount=value;
  // //  return value
  //   // this.config.referenceDataValueList[index].attributeValue1 = value;
  //   // this.checkValidation();
  // }

  // serviceData = {
  //     "excessTowerId": 1000,
  //     "claimNumber": "FC132234234",
  //     "currency": { "refDataId": 0, "code": "USD", "name": null },
  //     "followPosition": { "refDataId": 0, "code": "", "name": null },
  //     "isOtherTowerLinked": false,
  //     "layerDetails": [
  //       {
  //         "layerNumber": 1,
  //         "amount": 10000,
  //         "excessAmount": "200000",
  //         "participants": ["Swiss Re", "AXA", "ICICI"],
  //         "attachingClaim": "020198554545",
  
  //       },
  //       {
  //         "layerNumber": 2,
  //         "amount": 100,
  //         "excessAmount": "2005000",
  //         "participants": ["AXA", "ICICI", "Kotak", "Citi"],
  //         "attachingClaim": "",
       
  //       },
  //       {
  //         "layerNumber": 3,
  //         "amount": 150,
  //         "excessAmount": "500",
  //         "participants": ["AXA", "ICICI"],
  //         "attachingClaim": "",
    
  //       },
  //     ]
  //   }





  // serviceData = {
  //   "excessTowerId": 0,
  //   "claimNumber": null,
  //   "currency": null,
  //   "followPosition": null,
  //   "isOtherTowerLinked": null,
  //   "layerDetails": []
  // }
  // serviceData={
  //   "excessTowerId": 0,
  //   "claimNumber": null,
  //   "currency": null,
  //   "followPosition": null,
  //   "isOtherTowerLinked": true,
  //   "layerDetails": []
  //   }

  // serviceData = {
  //   "excessTowerId": 1000,
  //   "claimNumber": "FC132234234",
  //   "currency": { "refDataId": 0, "code": "USD", "name": null },
  //   "followPosition": { "refDataId": 0, "code": "", "name": null },
  //   "isOtherTowerLinked": false,
  //   "layerDetails": [
  //     {
  //       "layerNumber": 1,
  //       "amount": 10000,
  //       "excessAmount": "200000",
  //       "participants": ["Swiss Re", "AXA", "ICICI"],
  //       "attachingClaim": "020198554545",

  //       "lastElement": false,
  //       "hasSwissRe": true,
  //       "showAttachedClaim": false
  //     },
  //     {
  //       "layerNumber": 2,
  //       "amount": 100,
  //       "excessAmount": "2005000",
  //       "participants": ["AXA", "ICICI", "Kotak", "Citi"],
  //       "attachingClaim": "020198554546",
  //       "lastElement": false,
  //       "hasSwissRe": false,
  //       "showAttachedClaim": false
  //     },
  //     {
  //       "layerNumber": 3,
  //       "amount": 150,
  //       "excessAmount": "500",
  //       "participants": ["AXA", "ICICI"],
  //       "attachingClaim": "",
  //       "lastElement": true,
  //       "hasSwissRe": false,
  //       "showAttachedClaim": false
  //     },
  //   ]
  // }


  // createArray(length){
  //   let newLayerArray=[];
  //   for(let i=1;i<=length;i++){
  //   newLayerArray.push(i)}
  //   return newLayerArray
  // }

  // swissRecheck(layerNum,claim){
  //   console.log(layerNum, claim)
  //   let match=false;
  //   for (let i=0;i<claim.swisreLayers.length;i++){
  //     if(claim.swisreLayers[i]==layerNum){
  //     match=true;
  //     }
  //   }
  //        return match
  //     }


  // public copyLayer(layer) {
  //   // let obj: any = {
  //   //   "layerNumber": layer.layerNumber,
  //   //   "amount": layer.amount,
  //   //   "excessAmount": layer.excessAmount,
  //   //   "participants": [...layer.participants],
  //   //   "attachingClaim": layer.attachingClaim,
  //   //   "lastElement": true,
  //   //   "hasSwissRe": false,
  //   //   "showAttachedClaim": false
  //   // }
  //  let obj= Object.assign({},layer)
  //  obj.participants=[...layer.participants]
  //   this.workingLayers[this.workingLayers.length - 1].lastElement = false;
  //   this.workingLayers.push(obj);
  //   this.workingLayers[this.workingLayers.length - 1].lastElement = true;
  // }