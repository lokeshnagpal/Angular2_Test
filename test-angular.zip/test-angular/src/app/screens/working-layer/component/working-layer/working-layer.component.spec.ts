import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WorkingLayerComponent } from './working-layer.component';

describe('WorkingLayerComponent', () => {
  let component: WorkingLayerComponent;
  let fixture: ComponentFixture<WorkingLayerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WorkingLayerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WorkingLayerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
