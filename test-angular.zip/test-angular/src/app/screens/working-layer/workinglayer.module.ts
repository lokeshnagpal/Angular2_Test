import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from './../../shared/shared.module';
import { WorkingLayerRoutingModule } from './working-layer-routing.module';
import { WorkingLayerComponent} from './component/working-layer/working-layer.component';
import {MatFormFieldModule} from '@angular/material/form-field';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CurrencyPipe } from '@angular/common';

@NgModule({
  declarations: [WorkingLayerComponent],
  imports: [
    CommonModule,
    SharedModule,
    WorkingLayerRoutingModule,
    MatFormFieldModule,
    FormsModule,
     ReactiveFormsModule
  ],
  providers:[CurrencyPipe]
})
export class WorkingLayerModule { }
