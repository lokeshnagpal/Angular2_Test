import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from './../../shared/shared.module';
import { UnderConstructionRoutingModule } from './under-construction-routing.module';
import { UnderConstructionComponent} from './component/under-construction/under-construction.component';
import {MatFormFieldModule} from '@angular/material/form-field';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [UnderConstructionComponent],
  imports: [
    CommonModule,
    SharedModule,
    UnderConstructionRoutingModule,
    MatFormFieldModule,
    FormsModule,
     ReactiveFormsModule
  ],
})
export class UnderConstructionModule { }
