
import { Component, ElementRef, ViewChild, OnInit } from '@angular/core';

import { ActivatedRoute, Router } from '@angular/router';


@Component({
  selector: 'app-under-construction',
  templateUrl: './under-construction.component.html',
  styleUrls: ['./under-construction.component.scss']
})

export class UnderConstructionComponent implements OnInit {
ngOnInit(){

}
}