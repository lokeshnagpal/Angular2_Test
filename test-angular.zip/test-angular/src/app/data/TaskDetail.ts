import { TaskComment } from './TaskComment';
export class TaskDetail {
    id:number;
    category:string;
    priority:string;
    assignee:string;
    dueDate:string;
    comments:TaskComment[];
    
}