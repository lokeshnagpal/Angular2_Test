export class TaskComment {
    id:number;
    createdBy:string;
    createdDate:string;
    comment:string;
    
}