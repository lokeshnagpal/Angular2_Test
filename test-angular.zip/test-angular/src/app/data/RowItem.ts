export class RowItems{
    leftTopItems:any;
    leftBottomItems:any;
    rightTopItems:any;
    rightBottomItems:any;
}

export class RowItem{
    name:string;
    Value:string;
    desc:string;
    isIcon:boolean;
}


