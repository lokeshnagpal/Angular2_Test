


import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// const routes: Routes = [
//   {
//     path: 'diary',
//     loadChildren: './screens/diary/diary.module#DiaryModule'
//   },
//   {
//     path: 'claimSummary',
//     loadChildren: './screens/claim-summary/claim-summary.module#ClaimSummaryModule'
//   },
//   {
//     path: 'llr',
//     loadChildren: './screens/llr/llr.module#LlrModule'
//   },
//   {
//     path: 'acknowledgement',
//     loadChildren: './screens/acknowledgement/acknowledgement.module#AcknowledgementModule'
//   },
//   {
//     path: 'financial',
//     loadChildren: './screens/financial/financial.module#FinancialModule'
//   },
//   {
//     path: 'taskDetails',
//     loadChildren: './screens/taskDetails/task-details.module#TaskDetailsModule'
//   },
//   // {
//   //   path: 'claimDetails',
//   //   loadChildren: ''
//   // },
//   // {
//   //   path: 'history',
//   //   loadChildren: ''
//   // },
//   {
//     path: 'workinglayer',
//     loadChildren: './screens/working-layer/workinglayer.module#WorkingLayerModule'
//   },
//   {
//     path: 'underconstruction',
//     loadChildren: './screens/under-construction/underconstruction.module#UnderConstructionModule'
//   },
//   {
//     path:'claimshandlingagreement',
//     loadChildren:'./screens/claims-handling-agreement/claims-handling-agreement.module#ClaimHandlingAgreementModule'
//   },
//   {
//     path: '',
//     redirectTo: 'diary',
//     pathMatch: 'full'
//   }
// ];

const routes: Routes = [
  {
    path: 'diary',
    // loadChildren: './screens/diary/diary.module#DiaryModule'
    loadChildren: () => import('./screens/diary/diary.module').then(m => m.DiaryModule)
  },
  {
    path: 'claimSummary',
    // loadChildren: './screens/claim-summary/claim-summary.module#ClaimSummaryModule'
    loadChildren: () => import('./screens/claim-summary/claim-summary.module').then(m => m.ClaimSummaryModule)
  },
  {
    path: 'llr',
    // loadChildren: './screens/llr/llr.module#LlrModule'
    loadChildren: () => import('./screens/llr/llr.module').then(m => m.LlrModule)
  },
  {
    path: 'acknowledgement',
    // loadChildren: './screens/acknowledgement/acknowledgement.module#AcknowledgementModule'
    loadChildren: () => import('./screens/acknowledgement/acknowledgement.module').then(m => m.AcknowledgementModule)
  },
  {
    path: 'financial',
    // loadChildren: './screens/financial/financial.module#FinancialModule'
    loadChildren: () => import('./screens/financial/financial.module').then(m => m.FinancialModule)
  },
  {
    path: 'taskDetails',
    // loadChildren: './screens/taskDetails/task-details.module#TaskDetailsModule'
    loadChildren: () => import('./screens/taskDetails/task-details.module').then(m => m.TaskDetailsModule)
  },
  // {
  //   path: 'claimDetails',
  //   loadChildren: ''
  // },
  // {
  //   path: 'history',
  //   loadChildren: ''
  // },
  {
    path: 'workinglayer',
    // loadChildren: './screens/working-layer/workinglayer.module#WorkingLayerModule'
    loadChildren: () => import('./screens/working-layer/workinglayer.module').then(m => m.WorkingLayerModule)
  },
  {
    path: 'underconstruction',
    // loadChildren: './screens/under-construction/underconstruction.module#UnderConstructionModule'
    loadChildren: () => import('./screens/under-construction/underconstruction.module').then(m => m.UnderConstructionModule)
  },
  {
    path:'claimshandlingagreement',
    // loadChildren:'./screens/claims-handling-agreement/claims-handling-agreement.module#ClaimHandlingAgreementModule'
    loadChildren: () => import('./screens/claims-handling-agreement/claims-handling-agreement.module').then(m => m.ClaimHandlingAgreementModule)
  },
  {
    path: '',
    redirectTo: 'diary',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  
  exports: [RouterModule]
})
export class AppRoutingModule { }
