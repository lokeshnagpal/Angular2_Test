import { ServerErrorInterceptor } from './httpInterceptor/server-error-handler';
import { SharedModule } from './shared/shared.module';
import { NotificationService } from './error/services/notification.service';
import { SwissReDateAdapter } from './customDateAdapter';
import { ClaimSummaryService } from './screens/claim-summary/claim-summary.service';
import { CustomBrowserXhr } from './custom-browser-xhr';
import { HttpModule, BrowserXhr } from '@angular/http';
// import { BrowserXhr } from '@angular/http';
import { ClientService } from './services/client.service';

import { DateAdapter, MAT_DATE_FORMATS } from '@angular/material';
// import { diaryAsyncHandler } from './screens/diary/action/action.middleware';
import { BrowserModule , HAMMER_GESTURE_CONFIG} from '@angular/platform-browser';
import { NgModule, ErrorHandler } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { GestureConfig } from '@angular/material';
// import { NgReduxModule }  from '@angular-redux/store';
import { APP_BASE_HREF, LocationStrategy, HashLocationStrategy, DatePipe} from '@angular/common';
import { BaseComponent } from 'src/app/shared/ui/base/base.component';
import { GlobalErrorHandler } from './error/global-error-handler';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { FlexLayoutModule } from '@angular/flex-layout';

@NgModule({
  declarations: [
    AppComponent,
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    SharedModule,
    HttpClientModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    HttpModule,
    FlexLayoutModule,
    InfiniteScrollModule
  ],
  providers: [ClientService,
    NotificationService,
    { provide: BrowserXhr, useClass: CustomBrowserXhr },
    ClaimSummaryService, BaseComponent,
    {
      provide: BrowserXhr, useClass: CustomBrowserXhr
    },
    {
      provide: DateAdapter, useClass: SwissReDateAdapter
  },
  { provide: ErrorHandler, useClass: GlobalErrorHandler },
  { provide: HTTP_INTERCEPTORS, useClass: ServerErrorInterceptor, multi: true },
  { provide: HAMMER_GESTURE_CONFIG, useClass: GestureConfig },
  // { provide: APP_BASE_HREF, useValue: '/' },
  { provide: LocationStrategy, useClass: HashLocationStrategy }, DatePipe
  ],
  bootstrap: [AppComponent]
})
export class AppModule {


 }
