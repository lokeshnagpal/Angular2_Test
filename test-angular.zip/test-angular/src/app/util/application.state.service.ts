import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApplicationStateService {

  public deviceName: string;
  private isMobileResolution: boolean;
  private isTabResolution: boolean;
  private isDesktopResolution: boolean;
  private width: number;
  private subject: Subject<number> = new Subject();
  constructor() {
    this.setResolutionFlags(window.innerWidth);
    this.setDeviceName(window.innerWidth);
  }
  public onResize(event: any) {
    this.setResolutionFlags(event.target.innerWidth);
    this.setDeviceName(window.innerWidth);
  }
  public setResolutionFlags(width) {
    this.width = width;
    this.subject.next(width);
    if (width < 768) {
      this.isMobileResolution = true;
      this.isTabResolution = false;
      this.isDesktopResolution = false;
    } else if (width <= 1024) {
      this.isMobileResolution = false;
      this.isTabResolution = true;
      this.isDesktopResolution = false;
    } else {
      this.isMobileResolution = false;
      this.isTabResolution = false;
      this.isDesktopResolution = true;
    }
  }
  public setDeviceName(width) {
    if (width >= 768 && width <= 1024) {
      this.deviceName = 'Tablet';
    } else if (width >= 320 && width < 768 ) {
      this.deviceName = 'Mobile';
    } else if (width > 1024) {
      this.deviceName = 'Desktop';
    }
  }
  public getIsMobileResolution(): boolean {
    return this.isMobileResolution;
  }
  public getIsTabResolution(): boolean {
    return this.isTabResolution;
  }
  public getIsDesktopResolution(): boolean {
    return this.isDesktopResolution;
  }
  public getDeviceName() {
    return this.deviceName;
  }
  public isBrowserIE() {
    return /msie\s|trident\//i.test(window.navigator.userAgent);
  }
  public getWidth() {
    return this.width;
  }
  public subscribeToResolution() {
    return this.subject;
  }
}
