import { RequestOptions } from '@angular/http';

export class Constants{
    public static CLAIM_NUMBER:any="Claim Number";
    public static CLAIM_INDICATORS:any="Claim Indicators";
    public static CLAIM_INSURED:any="Insured";
    public static DATE_OF_LOSS:any="Date of Loss";
    public static CLAIM_DORMANCY:any="Claim Dormancy";
    public static CLAIM_HANDLER:any="Claim Handler";
    public static CLAIM_EXAMINER:any="Claim Examiner";
    public static CLAIM_STATUS:any="Claim Status";
    public static LOSS_CAUSE:any="Loss Cause";

// Poilcy information property
    public static POLICY_NAME:any="Policy Name";
    public static POLICY_DESC:any="Policy Description";
    // public static POLICY_ID:any="Policy ID";
    public static POLICYNUMBER="Policy ID"
    public static POLICYID="Policy ID & Status"
    public static POLICY_PREMIUM:any="Premium";
    public static POLICY_STATUS:any="Policy Status";
    public static OPENCLAIMS:any="Open Claims";
    public static PREMIUM:any="Premium";
    public static INCEPTIONDATE:any="Policy Inception";
    public static EXPIRATIONDATE:any="Expiration Date";
    public static POLICY_LOCATION:any="Location";
    public static CLAIM_DORMANCY_VALUE_TEXT: string = "Inactive for ";
    

// Diary Dates and File Notes property
    public static DIARY_DATES:string="DIARY DATES";
    public static FILE_NOTES:string="FILE NOTES";
    public static FILE_NOTE_CLASS:string="file-note-card";
    public static DIARY_DATE_CLASS:string="diary-date-card"
    public static OPEN_DIARY:string="Open Diary";
    public static CLOSED_DIARY:string="Closed Diary";
    public static POSTED:string="Posted";
    public static SAVED_DRAFTS:string="Saved Drafts";
    public static DIARY_SECTION_CODE:string="CREATE_DIARY_DATE";
    public static FILE_NOTE_SECTION_CODE:string="CREATE_FILE_NOTES"
    public static DIARY_DATES_TAB_ID:string="DIARY_DATE";
    public static DIARY_DATES_TAB_NAME:string="Diary Date";
    public static FILE_NOTE_TAB_ID:string="FILE_NOTE";
    public static FILE_NOTE_TAB_NAME:string="File Note";
    public static MORE_ACTIONS:string="MORE ACTIONS";
    public static DIARY_DATES_FOOTER_COMM="WRITE COMMENTS";
    public static FILE_NOTES_FOOTER_COMM="WRITE A NOTE";
    public static DIARY_DATES_POST_LABEL="Write Comments";
    public static FILE_NOTES_POST_LABEL="Write a Note";
    public static MAX_CHARACTER_LENGTH:number=3999;
    public static CHARACTER_LENGTH:number=999;
    public static DIARY_DEFAULT_COMMENT="New Diary Created"

//  EditorComponent
     public static CANCEL="CANCEL";
     public static SAVE_DRAFT="SAVE DRAFT";
     public static SAVE="SAVE";
// LLR
     public static GENERATE_ROUND_TABLE_LLR_NAME = "Generate Round Table/LLR";
     public static GENERATE_ROUND_TABLE_LLR_CODE= "GENERATE_ROUND_TABLE_LLR";    
    //  public static LARGE_LOSS_REPORT= "Large Loss Report"; 
    //  public static LLR_GENERATE_ROUND_TABLE = "Generate Round Table/LLR";
    //  public static LARGE_LOSS_EVENT_NOTIFICATION="Large Loss Event Notification";

    public static  LLR_GENERATE_ROUND_TABLE_NAME = "Generate Round Table/LLR";
     public static LLR_GENERATE_ROUND_TABLE_CODE= "LLR_GENERATE_ROUND_TABLE";   
     public static LARGE_LOSS_REPORT_CODE= "LARGE_LOSS_REPORT"; 
     public static LARGE_LOSS_REPORT_NAME= "Large Loss Report"; 
     public static LARGE_LOSS_EVENT_NOTIFICATION_CODE= "LARGE_LOSS_EVENT_NOTIFICATION"; 
     public static LARGE_LOSS_EVENT_NOTIFICATION_NAME= "Large Loss Event Notification"; 

 //Task Type    
 public static TASK_ID:any="Task ID"; 
 public static DATE_OF_REPORT:any="Date of Report";
 public static CLAIM_UNIT:any="Claim Unit";
 public static TASK_TYPE_ID:any="Task Type";
 public static TASK_STATUS_ID:any="Task Status";
 public static TASK_DUE_DATE:any="Task Due In";

 //Finance Inormation
 public static FINANCIAL_POSITION:any="Financial Position"; 
 public static INCURRED_BEFORE_MOVEMENT:any="Incurred Before Movement";
 public static PROPOSED_INCREASE:any="Proposed Increase";
 public static INCURRED_AFTER_MOVEMENT:any="Incurred After Movement";
 public static INDEMNITY:any="Indemnity";
 public static EXPENSE:any="Expense";
 public static TOTAL_INCURRED:any="Total Incurred";

 //Round Table 
 public static LIABILITY_QUATUM_COVERAGE="Liability and Quantum Coverage";
 public static PROPOSED_RESERVE_MOVEMENT="Narrative for proposed reserve movement";
 public static OUTCOME_RT_HEADER="Outcome of RT Meeting";
 public static DELEGATED_TO="DELEGATED_TO";
 public static FIRST_LEVEL_APPROVER="FIRST_LEVEL_APPROVER";
 public static FINAL_APPROVER="FINAL_APPROVER";
 public static FINAL_APPROVAL_REQUESTED="FINAL_APPROVAL_REQUESTED";
//  public static SENT_TO_PARTICIPANTS="SENT_TO_PARTICIPANTS";
public static RT_SCHEDULED="RT_SCHEDULED";
 public static ADDINFOREQUIRED="ADDINFOREQUIRED";
 public static ADDINFOPROVIDED="ADDINFOPROVIDED";
 public static ROUND_TABLE_APPROVED="ROUND_TABLE_APPROVED";
 public static SENT_TO_GROUP_MAILBOX="SENT_TO_GROUP_MAILBOX";
 public static CLOSED="CLOSED";
 public static SENT_TO_LINE_MANAGER="SENT_TO_LINE_MANAGER";
 public static DRAFT_APPROVED="DRAFT_APPROVED";
 public static APPROVED="APPROVED";
  public static LLR_FINANCIAL_INFORMATION="LLR_FINANCIAL_INFORMATION";
public static LINE_MANAGER="LINE_MANAGER";
public static FINAL_REVIEWER="FINAL_REVIEWER";
public static ASSIGNEE="ASSIGNEE";
public static TASK_CREATOR="TASK_CREATOR";
public static CANCELED="CANCELED";
public static DECLINED="DECLINED ";
public static PARTICIPANTS="PARTICIPANTS";
public static REVIEWER="REVIEWER";
public static SCHEDULER="SCHEDULER";
public static INFO_PROVIDER="INFO_PROVIDER";
public static LLR_MAILBOX_DETAILS="LLR_MAILBOX_DETAILS";
public static OTHER_PARTICIPANT="OTHER_PARTICIPANT";
public static PREPARE="PREPARE";
 //Action Buttons
 public static SUBMIT="SUBMIT";
 public static DISTRIBUTE="DISTRIBUTE";
public static MEETING_DATE="MEETING_DATE";
public static DISCARD="DISCARD";
public static SEND_TO_MAILBOX="SEND TO GROUP MAILBOX";
public static TRIGGER_ACTIVITY="TRIGGER FINANCIAL ACTIVITY";
public static APPROVE="APPROVE";
 // Action button messages
 public static FILL_REQUIRED_FIELDS_MSSG="Please fill in all required fields";
 public static ADD_TWO_PARTICIPANTS_MSSG="Please add atleast two participants";
 public static SUBMIT_TASK_MSSG="Task Submitted";
 public static APPROVE_TASK_MSSG="Task Approved";
 public static ROUND_TABLE_CATEGORY_MSSG="Please select the Round table type";

 //LLR/RT comment box property
 public static COMMENTS_HEADER="Submission Comments";
 public static COMMENTS_PLACEHOLDER="Write Submission Comments";
 public static APPROVAL_HEADER="Approval Comments";
 public static APPROVAL_PLACEHOLDER="Write Approval Comments";
 public static REQUEST_ADDITIONAL_HEADER="Request Additional Information";
 public static  REQUEST_ADDITIONAL_PLACEHOLDER="Write Comments";
 public static DELEGATE_HEADER_PLACEHOLDER="Delegate to"; 
 public static DECLINE_HEADER="Decline Comments";
 public static DECLINE_PLACEHOLDER="Write Decline Comments"; 
 public static DISCARD_RT_HEADER="Discard round table task?";
 public static DISCARD_RT_PLACEHOLDER="This will discard round table task. Do you want to proceed ?"; 
 public static DISCARD_LLR_HEADER="Discard LLR task?";
 public static DISCARD_LLR_PLACEHOLDER="This will discard LLR task. Do you want to proceed ?"; 

//Editor toolbar RequestOptions ['bold', 'italic', 'underline', 'strikeThrough','paragraphFormat', 'align', 'formatOL',
 public static TOOLBAR_OPTIONS= ['bold', 'italic', 'underline', 'strikeThrough','paragraphFormat', 'align',
  'formatOL','formatUL', 'indent', 'outdent', 'undo', 'redo', 'insertTable', 'insertImage'];

  //Multi Level Approver
  public static MULTI_LEVEL_OPTIONS=[
      {name:'Line Manager',dbColumnName:'LINE_MANAGER'},
      {name:'First  Level Approver',dbColumnName:'FIRST_LEVEL_APPROVER'},
      {name:'Second  Level Approver',dbColumnName:'SECOND_LEVEL_APPROVER'},
      {name: 'Third  Level Approver',dbColumnName:'THIRD_LEVEL_APPROVER'},
      {name:'Fourth  Level Approver',dbColumnName:'FOURTH_LEVEL_APPROVER'},
      {name:'Fifth  Level Approver',dbColumnName:'FIFTH_LEVEL_APPROVER'},
      {name:'Sixth  Level Approver',dbColumnName:'SIXTH_LEVEL_APPROVER'},
      {name:'Seventh Level Approver',dbColumnName:'SEVENTH_LEVEL_APPROVER'},
      {name:'Eight  Level Approver',dbColumnName:'EIGHT_LEVEL_APPROVER'},
    ];
}
