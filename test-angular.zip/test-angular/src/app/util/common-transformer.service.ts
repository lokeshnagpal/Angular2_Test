import { Injectable } from '@angular/core';
import { formatDate } from '@angular/common';
import { Constants } from './application.constants';
import * as moment from 'moment';
import momentTZ from 'moment-timezone';
import {MatSnackBar } from '@angular/material';
// import { CurrencyPipe } from '@angular/common';
@Injectable({
  providedIn: 'root'
})
export class CommonTransformerService {
  public headerData: any = [];
  public contentData: any = [];
  public headerTopLeftItem: any;
  public headerBottomLeftItem: any;
  public headerTopRightItem: any;
  public headerBottomRightItem: any;
  public leftTopObj: any = {}
  private regex: RegExp = new RegExp(/^\d*\.?\d{0,2}$/g);
  private specialKeys: Array<string> = ['Backspace', 'Tab', 'End', 'Home', '-', 'ArrowLeft', 'ArrowRight', 'Del', 'Delete'];

  constructor(private snackBar: MatSnackBar,  ){

  }


  calculateDiffDate(inputDate: string) {
    if (inputDate != undefined || inputDate != null) {
      let pattern = /(\d{4})(\d{2})(\d{2})/;
      let modDate: any;
      if (inputDate.indexOf(':') == -1) {
        modDate = new Date(inputDate.replace(pattern, '$1/$2/$3'));
      } else {
        let arr = inputDate.split(" ");
        let d = arr[0].replace(pattern, '$1/$2/$3');
        modDate = new Date(d + " " + arr[1]);
      }

      let date1 = new Date();
      let diff = Math.floor(date1.getTime() - modDate.getTime());
      let day = 1000 * 60 * 60 * 24;

      let days = Math.floor(diff / day);
      let months = Math.floor(days / 31);
      let years = Math.floor(months / 12);

      let message = "";
      if (years > 0) {
        message += years + " yrs "
      }
      if (months > 0) {
        message += months - (12 * years) + " mos "
      } if (days > 0) {
        message += days - (months * 31) + " dys"
      }
      // console.log("Diff - ",message);
      return message;
    }
  }

  // Convert number to money format with optional currency parameter
  parseMoney(amount, currency?) {
    amount = parseFloat(amount);
    amount = Math.round(amount * 100) / 100;
    let parsed = amount.toLocaleString();
    if (currency) {
      parsed = currency + ' ' + parsed;
    }
    return parsed;
  }

  public dateTimeZoneChange(dateToConvert) {
    return moment(momentTZ(dateToConvert).tz(momentTZ.tz.guess())).format('YYYY-MM-DD HH:mm:ss');
  }

  public getTimeZone(dateToConvert) {
    // momentTZ.tz.guess(); // OUTPUT: America/New_York
    // momentTZ.tz(momentTZ.tz.guess()).format("Z z"); // OUTPUT: -08:00 PST
    // momentTZ.tz(momentTZ.tz.guess()).zoneAbbr();    // OUTPUT: PST
    // return momentTZ.tz(momentTZ.tz.guess()).zoneAbbr();
    return  moment(momentTZ(dateToConvert).tz(momentTZ.tz.guess())).zoneAbbr();
  }

  //Converts date object to dd mmm yyyy
  public dateObjectFormatChange(dateToConvert) {
    if(dateToConvert){
    let date = dateToConvert.toString();
    const split = dateToConvert.split(' ')[0].split('-');
    date = split[0] + split[1] + split[2];
    return this.dateFormatChange(date);
    }
  }

  //Converts date object to dd mmm yyyy  hh:mm
  public dateObjectToDateTimeChange(dateToConvert) {
    let date = dateToConvert.toString();
    const split = dateToConvert.split(' ')[0].split('-');
    date = split[0] + split[1] + split[2];
    return this.dateFormatChange(date) + '  ' + dateToConvert.toString().split(' ')[1].substring(0,5);
  }

  // Converts 'yyyymmdd' to 'dd mmm yyyy'
  public dateFormatChange(dateToConvert) {
    if (dateToConvert != undefined) {
      let monthList = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
      let year = dateToConvert.substring(0, 4);
      let month = dateToConvert.substring(4, 6);
      let day = dateToConvert.substring(6, 8);
      let date = day + " " + monthList[month - 1] + " " + year;
      return date;
    }
  }

  // Converts 'yyyy-mm-dd' to 'dd mmm yyyy'
  public dateMHFormatChange(dateToConvert) {
    if (dateToConvert != undefined) {
      const monthList = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
      const split = dateToConvert.split('-');
      let date = split[2] + " " + monthList[split[1] - 1] + " " + split[0];
      return date;
    }
  }

  // Converts 'yyyymmdd' to Date Object
  public dateToObjectFormatChange(dateToConvert) {
    const year = parseInt(dateToConvert.substring(0, 4));
    const month = parseInt(dateToConvert.substring(4, 6)) - 1;
    const day = parseInt(dateToConvert.substring(6, 8));
    return new Date(year, month, day);
  }

  // Converts Date Object to 'yyyymmdd'
  public dateInServiceFormat(dateToConvert) {
    let monthList = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    let monthNUmbers = ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"];
    let dateVal = String(dateToConvert);
    let formDate = dateVal.split(" ");
    let dateFormat = formDate[3] + (monthNUmbers[monthList.indexOf(formDate[1])]) + formDate[2];
    if (dateFormat.indexOf('undefined') < 0) {
      return dateFormat;
    } else {
      return dateToConvert;
    }
  }

  public convertDateInServiceFormat(dateToConvert) {
    let monthList = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    let monthNUmbers = ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"];
    let dateVal = String(dateToConvert);
    let formDate = dateVal.split(" ");
    let dateFormat = formDate[2] + (monthNUmbers[monthList.indexOf(formDate[1])]) + formDate[0];
    if (dateFormat.indexOf('undefined') < 0) {
      return dateFormat;
    } else {
      return dateToConvert;
    }
  }
  public getDatepickerFormat(dateToConvert) {
    let monthList = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    let year = dateToConvert.substring(0, 4);
    let month = dateToConvert.substring(4, 6);
    let day = dateToConvert.substring(6, 8);
    let date = year + "-" + month + "-" + day;
    return date;
  }

  //create chips with first and last character of name
  public createChips(item) {
    if (item) {
      let lastCharIndex = item.lastIndexOf(" ");
      let charVal;
      if (lastCharIndex > 1) {
        let nextIndex = lastCharIndex + 1;
        // charVal=item.charAt(0)+item.charAt(nextIndex);
        charVal = item.charAt(nextIndex) + item.charAt(0);
      }
      else {
        charVal = item.charAt(0);
      }
      return charVal;
    }

  }

  public headerDataConverter(claimSummaryDetails) {

    for (let item of claimSummaryDetails) {
      this.headerData = [];
      switch (item.name) {
        case Constants.CLAIM_NUMBER:
          this.headerLeftTop(item);
          break;

        case Constants.CLAIM_HANDLER:
          this.headerLeftBottom(item);
          break;

        case Constants.CLAIM_STATUS:
          this.headerRightTop(item);
          break;

        case Constants.DATE_OF_LOSS:
          this.headerRightBottom(item);
          break;

        case Constants.TASK_ID:
          this.headerLeftTop(item);
          break;

        case Constants.TASK_DUE_DATE:
          this.headerRightTop(item);
          break;

        case Constants.TASK_TYPE_ID:
          this.headerLeftBottom(item);
          break;

        case Constants.TASK_STATUS_ID:
          this.headerRightBottom(item);
          break;
      }

      // this.headerLeftTop(item);
      // this.headerLeftBottom(item);
      // this.headerRightTop(item);
      // this.headerRightBottom(item);

      let headerObj = {
        headerTopLeftItem: this.headerTopLeftItem,
        leftBottomItems: this.headerBottomLeftItem,
        rightTopItems: this.headerTopRightItem,
        rightBottomItems: this.headerBottomRightItem
      }

      this.headerData.push(headerObj);
    }

    return this.headerData
  }

  public headerLeftTop(item) {
    this.leftTopObj["name"] = item.name
    this.leftTopObj["value"] = item.value
    this.headerTopLeftItem = this.leftTopObj
  }

  public headerLeftBottom(item) {
    let leftBottomObj = {}
    leftBottomObj["name"] = item.name
    leftBottomObj["value"] = item.value
    this.headerBottomLeftItem = leftBottomObj;
  }

  public headerRightTop(item) {
    let rightTopObj = {}
    rightTopObj["name"] = item.name

    if (item.type == "DATEBOX") {
      rightTopObj["value"] = this.dateFormatChange(item.dateValue);
    }
    rightTopObj["value"] = item.value
    this.headerTopRightItem = rightTopObj;
  }

  public headerRightBottom(item) {
    let rightBottomObj = {}
    rightBottomObj["name"] = item.name
    rightBottomObj["value"] = this.dateFormatChange(item.dateValue);
    this.headerBottomRightItem = rightBottomObj;
  }

  public mobileOverviewListData(claimSummaryDetails) {

    this.contentData = [];

    for (let item of claimSummaryDetails) {
      let obj: any = {};
      switch (item.name) {
        case Constants.CLAIM_STATUS:
          obj = {
            'name': item.name,
            'value': item.value
          }
          this.contentData.push(obj)
          break;

        case Constants.CLAIM_HANDLER:
          obj = {
            'name': item.name,
            'value': item.value
          }
          this.contentData.push(obj)
          break;

        case Constants.CLAIM_EXAMINER:
          obj = {
            'name': item.name,
            'value': item.value
          }
          this.contentData.push(obj)
          break;

        case Constants.LOSS_CAUSE:
          obj = {
            'name': item.name,
            'value': item.value
          }
          this.contentData.push(obj)
          break;

        case Constants.CLAIM_UNIT:
          obj = {
            'name': item.name,
            'value': item.value
          }
          this.contentData.push(obj)
          break

        case Constants.DATE_OF_REPORT:
          obj = {
            'name': item.name,
            'value': item.value
          }
          this.contentData.push(obj)
          break

        case Constants.CLAIM_INSURED:
          obj = {
            'name': item.name,
            'value': item.value
          }
          this.contentData.push(obj)
          break
      }

    }
    return this.contentData;
  }

  onlyNumber(value) {
    let num = Number(value)
    if (isNaN(num) == true) {
      return true;
    }
    else {
      return false;
    }
  }
  numberWithDecimal(value) {
    if (value !== "") {
      var isValid = /^[.\d]+$/.test(value);
      if (!isValid) {
        return { value: value, flag: true };
      }
      else {
        if (value.indexOf(".") != -1) {
          let splitValue = value.split('.')[1];
          if (splitValue == "") return { value: value, flag: false };
          let splitValueRegex = /^[.\d]+$/.test(splitValue);
          if (!splitValueRegex) {
            return { value: value, flag: true };
          } else {
            if (splitValue.length > 2) {
              value = Number.parseFloat(value).toFixed(2);
              return { value: value, flag: false };
            }
          }
        }
        else {
          return { value: value, flag: false };
        }
        // return { value: value, flag: false };
      }
    }
    return { value: value, flag: false };
  }
  public showError(message, durationValue?: number) {
    console.log(message);
     if(message["status"]!==200 && message["status"]!==0 && message["status"]!==undefined) {
      try {
        if (message.json().exceptionMessage) {
          message = message.json().exceptionMessage;
        }
      } catch(error) {}
      message = message.message ? message : message.toString();
     }
     this.snackBar.open(message, 'X', {
       panelClass: ['error-snack-bar', 'mdl-shadow--6dp'], duration: 5000
     });
   }
   
  public showMessage(message: string, durationValue?: number) {  
    if(message["status"]!==200 && message["status"]!==0 && message["status"]!==undefined) {
      // message=JSON.parse(message["_body"]);
      message=message["_body"];
      message=message["exceptionCode"] + ':' + message["exceptionType"] + ':'+ message['exceptionMessage'];
    } 
    this.snackBar.open(message, 'CLOSE', {
      panelClass: ['message-snack-bar', 'mdl-shadow--6dp'], duration: 3000
    })
    
  }

   convertIntoKeyValue(item){
    let contentArray:any=[];
    let policyDate:any={};
      for(let key of Object.keys(item)){
        let obj:any={
          name:'',
          value:''
        }
      obj.name=Constants[key.toUpperCase()];
      obj.value=item[key];    
      contentArray.push(obj);
      }
      return contentArray;
  }

  // numberToComma(value){
  //   if (value === null || value === "" || value === 0) {
  //     return value
  //   }
  //   else{
  //   const convNum = Number(value);
  //        if(value>999){
  //        let value1 = this.currencyPipe.transform(convNum,'USD',"code" , '1.0-0');
  //        return value1.replace( 'USD', "")
  //        }
  //       else{
  //         return value.toString();
  //       }
  //     }
  //   }

    RemovalCommaFormat(value, type?) {
      if (value === null || value === "" || value === 0) {
        return value
      }
      else {
        if (value > 0) {
          if (type == 'number') {
            return Number(value)
          }
          else {
            return value
          }
        }
        else {
          let res = value.replace(/[, ]+/g, "").trim();
          if (type == 'number') {
            return Number(res)
          }
          else {
            return res
          }
        }
      }
    }
  
}
