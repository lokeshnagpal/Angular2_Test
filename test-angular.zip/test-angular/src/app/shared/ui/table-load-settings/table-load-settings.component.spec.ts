import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TableLoadSettingsComponent } from './table-load-settings.component';

describe('TableLoadSettingsComponent', () => {
  let component: TableLoadSettingsComponent;
  let fixture: ComponentFixture<TableLoadSettingsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TableLoadSettingsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TableLoadSettingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
