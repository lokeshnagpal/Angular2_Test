import { Component, OnInit, Input, SimpleChanges, Output, EventEmitter } from '@angular/core';
import { environment } from 'src/environments/environment';
import { ClientService } from 'src/app/services/client.service';
import { CommonTransformerService } from 'src/app/util/common-transformer.service';

@Component({
  selector: 'app-table-load-settings',
  templateUrl: './table-load-settings.component.html',
  styleUrls: ['./table-load-settings.component.scss']
})
export class TableLoadSettingsComponent implements OnInit {

  @Input() settings;
  @Input() currentSetting;
  @Output() deletedSetting = new EventEmitter();
  @Output() selectedSetting = new EventEmitter();

  public displaySettings: any[] = [];
  public count: number = 0;
  public isLoading: boolean = true;
  public deleted: boolean = false;
  public selected: string = 'default';
  
  constructor(private clientService: ClientService, private commonTransformerService: CommonTransformerService) { }

  ngOnInit() {
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.settings && this.settings) {
      if (this.deleted) {
        this.deleted = false;
      } else {
        this.parseSettings();
      }
    }
    if (changes.currentSetting && this.currentSetting) {
      this.selected = this.currentSetting;
    }
  }

  parseSettings() {
    this.displaySettings = [];
    this.settings.forEach(setting => {
      const attr = {
        'attributes': {
          'filterby': [],
          'sortby': []
        },
        'userSettings': [],
        'searchCriteria': {}
      };
      this.displaySettings.push({...setting, ...attr});
    });
    this.count = 0;
    this.displaySettings.forEach(setting => {
      if (setting.id != 'default') {
        this.loadSetting(setting);
      }
    });
  }

  loadSetting(setting) {
    const attr = {
      'filterName': setting.name,
      'action': 'LOAD',
      'currentTab': 'CODiaries'
    };
    this.clientService.setUrl(environment.customSettingsUrl);
    this.clientService.postClientData(attr).subscribe(response => {
      setting.userSettings = response.userFilters;
      setting.searchCriteria = response.searchCriteria;
      this.getSettingsLabel(setting);
      this.count++;
      if (this.count == this.displaySettings.length - 1) {
        this.isLoading = false;
      }
    });
  }

  getSettingsLabel(settings) {
    settings.userSettings.forEach(userSetting => {
      if (userSetting.sorting) {
        if (userSetting.attributeLabel && (userSetting.sortingOrder.sortingAsc || userSetting.sortingOrder.sortingDesc)) {
          settings.attributes.sortby.push(userSetting.attributeLabel);
        }
      }
      if (userSetting.filter) {
        if (userSetting.dbColumnName != 'DUE_DATE' && userSetting.filterValue) {
          settings.attributes.filterby.push(userSetting.filterValue);
        }
      }
      if (userSetting.dbColumnName == 'DUE_DATE' && userSetting.filterValue) {
        const dates = userSetting.filterValue.split(',');
        let string = '';
        string += dates[0].length > 0 ? this.commonTransformerService.dateFormatChange(dates[0]) : '';
        if (dates[0].length > 0 && dates[1].length > 0) {
          string += ' - ';
        }
        string += dates[1].length > 0 ? this.commonTransformerService.dateFormatChange(dates[1]) : '';
        settings.attributes.filterby.push(string);
      }
    });
  }

  parseArray(array) {
    let string = '';
    array.forEach((item, index) => {
      string += item;
      if (index < array.length - 1) {
        string += ' | ';
      }
    });
    return string;
  }

  selectSetting(event, id) {
    if (event) {
      event.stopPropagation();
    }
    this.selected = id;
    this.displaySettings.forEach(userSetting => {
      if (userSetting.id == id) {
        this.selectedSetting.emit(userSetting);
      }
    });
  }

  deleteSetting(setting) {
    const attr = {
      'filterName':  setting.name,
      'action':  'DELETE',    // action can be SAVE – Save or Update And DELETE - Delete
      'currentTab': 'CODiaries'
    };
    this.clientService.setUrl(environment.customSettingsUrl);
    this.clientService.postClientData(attr).subscribe(response => {
      const settings = this.displaySettings.filter(userSetting => userSetting.id != setting.id);
      this.displaySettings = [...settings];
      this.deletedSetting.emit(setting);
      this.deleted = true;
    });
  }
}
