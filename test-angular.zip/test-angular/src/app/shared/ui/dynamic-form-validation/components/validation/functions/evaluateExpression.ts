export const evaluateExpression = function (expression, value) {
    const ANY_VALUE = 'ANY_VALUE';
    const VALUE = 'VALUE';
    const NOT_EQUAL = '!=';
    const EQUAL = '==';
    const AND = '&&';
    const OR = '||';

  const checkCondition = (act_value, values, returnOnfail) => {
    let output = false;
    values.forEach(condition => {
        if (condition.includes(EQUAL)) {
            const rule = VALUE + EQUAL + act_value;
            const anyValue = VALUE + EQUAL + ANY_VALUE;
            if (rule.toLowerCase() == condition.trim().toLowerCase() || anyValue.toLowerCase == condition.trim().toLowerCase()) {
                output = true;
            } else if (returnOnfail) {
                output = false;
            }
        } else if (condition.includes(NOT_EQUAL)) {
            const rule = VALUE + NOT_EQUAL + act_value;
            if (rule.toLowerCase() != condition.trim().toLowerCase()) {
                output = true;
            } else if (returnOnfail) {
                output = false;
            }
        }
    });
    return output;
  };

  let ruleSatisfied = false;
  if (expression.includes(OR)) {
    const values = expression.split('\\|\\|');
    ruleSatisfied = checkCondition(value, values, false);
  } else if (expression.includes(AND)) {
    const values = expression.split(AND);
    ruleSatisfied = checkCondition(value, values, true);
  } else {
    const values = [];
    values[0] = expression;
    ruleSatisfied = checkCondition(value, values, true);
  }
  return ruleSatisfied;
};
