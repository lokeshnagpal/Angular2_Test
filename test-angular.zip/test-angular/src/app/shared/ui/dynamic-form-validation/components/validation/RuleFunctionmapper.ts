import { RuleType } from '../../field.interface';
import { Validators } from '@angular/forms';
import { showControl, mandatoryControl, hideControl, readControl, valueControl } from './functions';
export const RULE_TYPE_FUNCTION_MAPPER = new Map<any, any>([
  ['SHOW', showControl],
  ['HIDE', hideControl],
  ['MANDATORY', mandatoryControl],
  ['READONLY', readControl],
  ['NOTIFY_ON_VALUE_CHANGE', valueControl]
]);
