import { Component, OnInit, Input, Output, EventEmitter, SimpleChanges } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Observable, Subject } from 'rxjs';
import { map, startWith, debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { ClientService } from 'src/app/services/client.service';
import { FormGroup } from '@angular/forms';
import { FieldConfig } from '../../field.interface';
import { CommonTransformerService } from 'src/app/util/common-transformer.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-icon-lookup',
  templateUrl: './icon-lookup.component.html',
  styleUrls: ['./icon-lookup.component.scss']
})
export class IconLookupComponent implements OnInit {

  public options: any[] = [];
  field: FieldConfig;
  group: FormGroup;
  width25: boolean;
  public initials: string = '';
  url: string;
  public filteredOptions: Observable<any[]>;
  private subject: Subject<string> = new Subject();
  public isLoading: boolean = false;

  constructor(public clientService: ClientService, public commonTransformerService: CommonTransformerService) {
  }

  ngOnInit() {
    if (this.field.source || this.field.group) {
      this.url = environment.lookupUrl + (this.field.type.toLowerCase().includes('suggest') ? '/suggest' : '') + '/' + (this.field.source ? this.field.source : '0') + '/' + (this.field.group ? this.field.group : '0') + '/';
    }
    this.subject.pipe(debounceTime(300), distinctUntilChanged(),
    switchMap((query) => {
      let response;
      if (query) {
        response = this.fetchLookupData(query);
      } else {
        response = this.fetchLookupData();
      }
      return response;
    })).subscribe(response => {
      if (response) {
        this.parseResponse(response);
        this.isLoading = false;
      }
    });
  }

  fetchLookupData(query?) {
    this.initials = '';
    if (this.url) {
      let url = this.url;
      if (query && query.length > 0) {
        if (url.charAt(url.length - 1) != '/') {
          url += '/';
        }
        url += query;
      }
      this.isLoading = true;
      this.clientService.setUrl(url);
      return this.clientService.getClientData();
    }
    return null;
  }

  public parseResponse(response) {
    if (response && response.length > 0) {
      this.options = [];
      if (typeof response[0] == 'string') {
        response.forEach(item => {
          this.options.push({'name': item});
        });
      } else {
        response.forEach(item => {
          this.options.push(item);
        });
      }
      this.filteredOptions = this.group.controls[this.field.dbColumnName].valueChanges
        .pipe(
          startWith(''),
          map(value => this._filter(value))
      );
    }
  }

  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();
    return this.options.filter(option => option.name.toLowerCase().includes(filterValue));
  }

  checkSelectedValue() {
    if (this.group.controls[this.field.dbColumnName].value && this.group.controls[this.field.dbColumnName].value.length > 0) {
      const selected = this.options.find(option => option.name == this.group.controls[this.field.dbColumnName].value);
      if (!selected) {
        this.group.controls[this.field.dbColumnName].setValue('');
      }
    }
  }

  emitChanges(option) {
    this.group.controls[this.field.dbColumnName].setValue(option.name);
    this.getInitials(option.name);
  }

  getInitials(name) {
    this.initials = this.commonTransformerService.createChips(name);
  }
  
  fetchFilteredLookup() {
    this.subject.next(this.group.controls[this.field.dbColumnName].value);
  }
}
