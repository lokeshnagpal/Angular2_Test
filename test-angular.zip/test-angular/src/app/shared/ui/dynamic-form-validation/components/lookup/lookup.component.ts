import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FieldConfig } from '../../field.interface';

@Component({
  selector: 'app-lookup',
  templateUrl: './lookup.component.html',
  styleUrls: ['./lookup.component.scss']
})
export class LookupComponent implements OnInit {

  public options: any[] = [];
  field: FieldConfig;
  group: FormGroup;
  width25: boolean;

  constructor() {
  }

  ngOnInit() {
    if (this.field.options) {
      this.options = this.field.options;
    }
  }
}
