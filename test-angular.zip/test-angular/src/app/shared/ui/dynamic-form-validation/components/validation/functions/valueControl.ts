import { AbstractControl } from '@angular/forms';
import { FormGroup, FormControl } from '@angular/forms';
import { FieldConfig, FieldRule } from '../../../field.interface';
import { evaluateExpression } from './evaluateExpression';

/* Sets value of current field based on value of affected field
*/
export const valueControl = (field: FieldConfig, affectedField: FieldConfig, fieldRule: FieldRule, formGroup: FormGroup, context: any) => {
  return (formControl: FormControl) => {
    const affectedControl = formGroup.get(affectedField.dbColumnName);
    const currentControl = formGroup.get(field.dbColumnName);
    const mapper = field.options;
    if (fieldRule !== undefined && currentControl && affectedControl && currentControl.value) {
      mapper.forEach(section => {
        if (section.child) {
          const found = section.child.find(child => child.name.toLowerCase() == currentControl.value.toLowerCase());
          if (found && section.name != affectedControl.value) {
            affectedControl.setValue(section.name);
          }
        }
      });
    }
    return null;
  };
};
