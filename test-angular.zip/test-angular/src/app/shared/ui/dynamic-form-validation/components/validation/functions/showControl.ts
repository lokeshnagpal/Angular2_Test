import { AbstractControl } from '@angular/forms';
import { FormGroup, FormControl } from '@angular/forms';
import { FieldConfig, FieldRule } from '../../../field.interface';
import { evaluateExpression } from './evaluateExpression';

/* SHOWS or Hide Controls based on the selected field value matching with Rule Value
Here each validation function receives following fields
1) Field with which user is interacting
2) Affected field from the given field
3) Rule to be executed
4) From group to traverse any other form field
It returns a validation function which accepts given form control and returns validation JSON object
if an error and in case of success it returns null
*/
export const showControl = (field: FieldConfig, affectedField: FieldConfig, fieldRule: FieldRule, formGroup: FormGroup, context: any) => {
  return (formControl: FormControl) => {
    const currentControl = formGroup.get(field.dbColumnName);
    if (fieldRule !== undefined && currentControl !== null && currentControl.value && evaluateExpression(fieldRule.attributeValue , currentControl.value)) {
        affectedField.hidden = false;
    } else {
        affectedField.hidden = true;
    }
    return null ;
  };
};
