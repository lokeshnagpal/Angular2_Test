import { Component, EventEmitter, Input, OnChanges, OnInit, Output } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { FieldConfig, Validator, RuleType, FieldRule } from '../../field.interface';
import { showControl } from '../validation/functions/showControl';
import { RULE_TYPE_FUNCTION_MAPPER } from '../validation/RuleFunctionmapper';

@Component({
  exportAs: 'dynamicForm',
  selector: 'dynamic-form',
  templateUrl: './dynamic-form-validation.component.html',
  styleUrls: ['./dynamic-form-validation.component.scss']
})
export class DynamicFormValidationComponent implements OnInit {

  @Input() fields: FieldConfig[] = [];
  @Input() context: any = {};
  @Input() width25?: boolean = false;
  @Output() submit: EventEmitter<any> = new EventEmitter<any>();

  public form: FormGroup;

  get value() {
    return this.form.value;
  }
  get valid() {
    return this.form.valid;
  }
  get status() {
    return  this.form.status;
  }
  get currentForm() {
    return this.form;
  }
  constructor(private fb: FormBuilder) {}

  ngOnInit() {
  this.form = this.createControl();
  const groupValidations = [];
  this.fields.forEach(field => {
    if (field.type === 'button') { return; }
    if ((field.validations !== null && field.validations !== undefined) || (field.attrRules !== null && field.attrRules !== undefined)) {
      const customValidations =  this.hookUpFieldCustomValidators(field);
      if (customValidations !== null && customValidations !== undefined) {
        customValidations.forEach(validation => {
          groupValidations.push(validation);
        });
      }
    }
  });
  this.form.setValidators(this.bindValidations(groupValidations || []));
  this.form.valueChanges.subscribe(values => {
    this.onSubmit();
  });
}

  onSubmit() {
    event.preventDefault();
    event.stopPropagation();
    if (!this.form.valid) {
      this.validateAllFormFields(this.form);
    }
    this.submit.emit(this.form.value);
  }

  findFieldById(id) {
    return this.fields.find(field => field.secAttrMapId == id);
  }

  /*  Hooks up the custom validator based on the rule mapper for the given field  */
  hookUpFieldCustomValidators(field: FieldConfig) {
    const validations = [];
    if (field.attrRules !== null && field.attrRules !== undefined) {
      field.attrRules.forEach(fieldRule => {
        const affectedField = this.findFieldById(fieldRule.affectedAttributeId);
        const ruleFunction = RULE_TYPE_FUNCTION_MAPPER.get(fieldRule.rule.ruleType);
        if (ruleFunction !== undefined && ruleFunction !== null) {
          const validation: Validator = {
            name: affectedField.dbColumnName,
            validator: ruleFunction(field, affectedField, fieldRule, this.form, this.context),
            message: 'Custom Validation Message can be fetched from backend'
          };
          validations.push(validation);
        }
      });
    }
    return validations;
  }

  createControl() {
    const group = this.fb.group({});
    this.fields.forEach(field => {
      const validations = [];
      if (field.type === 'button') { return; }
      if (field.validations !== null && field.validations !== undefined) {
        field.validations.forEach(valid => {
        validations.push(valid);
        });
      }
      const control = this.fb.control(
        {value: field.value, disabled: field.readonly},
        this.bindValidations(validations || [])
      );
      group.addControl(field.dbColumnName, control);
    });
    return group;
  }

  bindValidations(validations: any) {
    // CREATE VALIDATION FOR EACH CONTROL
    if (validations.length > 0) {
      const validList = [];
      validations.forEach(valid => {
        validList.push(valid.validator);
      });
      return Validators.compose(validList);
    }
    return null;
  }

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      control.markAsTouched({ onlySelf: true });
    });
  }

}
