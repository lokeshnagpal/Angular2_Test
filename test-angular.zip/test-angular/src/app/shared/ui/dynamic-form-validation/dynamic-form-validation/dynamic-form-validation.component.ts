import { Component, OnInit, ViewChild, Input, ChangeDetectorRef, EventEmitter, Output } from '@angular/core';
import { Validators } from '@angular/forms';
import { FieldConfig, FieldRule, RuleType } from '../field.interface';
import { DynamicFormValidationComponent as DynamicFormComponent } from '../components/dynamic-form-validation/dynamic-form-validation.component';
import { ClientService } from 'src/app/services/client.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-dynamic-form-validation',
  templateUrl: './dynamic-form-validation.component.html',
  styleUrls: ['./dynamic-form-validation.component.scss']
})
export class DynamicFormValidationComponent implements OnInit {

  @ViewChild(DynamicFormComponent, {static: false}) form: DynamicFormComponent;
  @Input() context;
  @Input() regConfig: FieldConfig[];
  @Input() width25?: boolean = false;
  @Output() submitEvent: EventEmitter<any> = new EventEmitter<any>();
  isContentInitialized = false;
  isLoaded = false;

  constructor(private cdRef: ChangeDetectorRef, private clientService: ClientService) { }

  ngOnInit() {
    if (this.regConfig) {
      this.isLoaded = false;
      let count = 0;
      this.regConfig.forEach(field => {
        if (field.type.toLowerCase().includes('lookup')) {
          if (!(field.options && field.options.length > 0)) {
            field.options = [];
          }
          if (field.source || field.group) {
            const url = environment.lookupUrl + (field.type.toLowerCase().includes('suggest') ? '/suggest' : '') + '/' + (field.source ? field.source : '0') + '/' + (field.group ? field.group : '0') + '/';
            this.clientService.setUrl(url);
            this.clientService.getClientData().subscribe(response => {
              field.options = response;
              count++;
              if (count == this.regConfig.length) {
                this.isLoaded = true;
                console.log('regConfig', this.regConfig);
              }
            });
          } else {
            count++;
            if (count == this.regConfig.length) {
              this.isLoaded = true;
              console.log('regConfig', this.regConfig);
            }
          }
        } else {
          count++;
          if (count == this.regConfig.length) {
            this.isLoaded = true;
            console.log('regConfig', this.regConfig);
          }
        }
      });
    }
  }

  ngAfterViewInit() {
    this.isContentInitialized = true;
    this.cdRef.detectChanges();
  }

  submit(value: any) {
    this.submitEvent.emit({value: this.form.value, valid: this.form.valid});
  }
}
