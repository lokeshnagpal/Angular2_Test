export interface Validator {
  name: string;
  validator: any;
  message: string;
}
export interface FieldConfig {
  attrId?: number;
  attrRules?: FieldRule[];
  dbColumnName?: string;
  name?: string;
  secAttrMapId?: string;
  type?: string;
  mandatory?: boolean;
  hidden?: boolean;
  readonly?: boolean;
  value?: any;
  source?: string;
  group?: string;
  options?: any;
  validations?: Validator[];
}
export enum RuleType {
  MANDATORY, READONLY, OPTIONAL, SHOW, HIDE, NOTIFY_ON_VALUE_CHANGE
}
export interface Rule {
  ruleType?: RuleType;
}
export interface FieldRule {
  affectedAttributeId?: number;
  affectedAttributeName?: string;
  attributeValue?: string;
  rule?: Rule;
}
