import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FilteredDropdownWithIconComponent } from './filtered-dropdown-with-icon.component';

describe('FilteredDropdownWithIconComponent', () => {
  let component: FilteredDropdownWithIconComponent;
  let fixture: ComponentFixture<FilteredDropdownWithIconComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FilteredDropdownWithIconComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FilteredDropdownWithIconComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
