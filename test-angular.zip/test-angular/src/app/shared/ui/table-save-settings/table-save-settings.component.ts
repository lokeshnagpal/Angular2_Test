import { Component, OnInit, Input, Output, EventEmitter, SimpleChanges } from '@angular/core';
import { Subject } from 'rxjs';
import { debounceTime } from 'rxjs/operators';
import { FormControl, Validators, AbstractControl, ValidatorFn } from '@angular/forms';

@Component({
  selector: 'app-table-save-settings',
  templateUrl: './table-save-settings.component.html',
  styleUrls: ['./table-save-settings.component.scss']
})
export class TableSaveSettingsComponent implements OnInit {

  @Input() settings;
  @Input() savedSettings;
  @Input() resetSettings?;
  @Output() valueChangeEvent = new EventEmitter();
  @Output() resettedSettingsEvent = new EventEmitter();

  public options: any[] = [];
  public name: string = '';
  public names: string[] = [];
  public selected: string[] = [];
  public nameControl = new FormControl('', [Validators.required, this.nameValidator()]);
  private subject: Subject<string> = new Subject();

  constructor() {}

  ngOnInit() {
    this.subject.pipe(debounceTime(300)).subscribe(name => {
      this.name = this.nameControl.value;
      this.emitChanges();
    });
    if (this.settings) {
      this.settings.forEach(setting => {
        this.options.push({
          'checked': false,
          'name': setting
        });
      });
    }
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.resetSettings) {
      if (this.resetSettings) {
        this.name = '';
        this.nameControl.setValue('');
        this.options.forEach(option => {
          option.checked = false;
        });
        this.resettedSettingsEvent.emit(true);
      }
    }
    if (changes.savedSettings) {
      this.names = ['Default Diary Filter'];
      this.savedSettings.forEach(setting => {
        this.names.push(setting.name);
      });
    }
  }

  updateSelection() {
    this.selected = [];
    this.options.forEach(option => {
      if (option.checked) {
        this.selected.push(option.name);
      }
    });
  }
  
  nameValidator(): ValidatorFn {
    return (control: AbstractControl): {[key: string]: any} | null => {
      const invalidName = this.names.includes(control.value);
      return invalidName ? {'invalidName': true} : null;
    };
  }

  emitChanges() {
    this.valueChangeEvent.emit({
      'selected': this.selected,
      'name': this.name
    });
  }

  onKeyUp() {
    this.subject.next(this.nameControl.value);
  }
}
