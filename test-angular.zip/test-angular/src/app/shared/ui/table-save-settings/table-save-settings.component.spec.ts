import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TableSaveSettingsComponent } from './table-save-settings.component';

describe('TableSaveSettingsComponent', () => {
  let component: TableSaveSettingsComponent;
  let fixture: ComponentFixture<TableSaveSettingsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TableSaveSettingsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TableSaveSettingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
