import { Constants } from './../../../util/application.constants';
import { environment } from './../../../../environments/environment';
import { MatSnackBar } from '@angular/material';
import { ClientService } from './../../../services/client.service';
import { DiaryService } from './../../../screens/diary/diary.service';
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { CommonTransformerService } from 'src/app/util/common-transformer.service';

@Component({
    selector:'app-post-mobile',
    templateUrl:'./post-mobile-component.html',
    styleUrls:['./post-mobile-component.scss']
})

export class PostMobileComponent implements OnInit{

    @Input() postComments;
    @Input() tabId;
    @Input() tabName;
    @Input() claimNumber;
    @Output() cancelPostEvent:EventEmitter<any>=new EventEmitter;

    public comments:any=[];
    public commentsTyped:any;
    public taskServiceUrl:string;
    public saveTaskComments:any;
    public taskNumber:any;
    public requestObject={};
    public postClick:boolean=true;
    public postCommLabel:any;

    constructor(private service: DiaryService, private clientService: ClientService, public commonTransformerService: CommonTransformerService){
    this.taskServiceUrl = environment.taskServiceUrl;
    this.saveTaskComments = environment.saveTaskComments;
    }

    ngOnInit(){
        this.taskNumber = this.service.getTaskNumber();
        if(this.tabId==Constants.DIARY_DATES_TAB_ID){
          this.postCommLabel=Constants.DIARY_DATES_POST_LABEL;
        }
        else if(this.tabId==Constants.FILE_NOTE_TAB_ID){
          this.postCommLabel=Constants.FILE_NOTES_POST_LABEL;
        }
    }

 public cancelComments() {
   this.postComments = false;
   this.cancelPostEvent.emit(this.postComments);
 }

 public sendComment() {
   if (this.tabName ==Constants.DIARY_DATES_TAB_NAME) {
     this.postDiaryDatesComments();
   } else if (this.tabName ==Constants.FILE_NOTE_TAB_NAME) {
     this.postFileNotesComments();
   }
 }

 public charLengthchanged(){
  if(this.commentsTyped.length>0){
    this.postClick=false;
  }
  else{
    this.postClick=true;
  }
 }

 public postDiaryDatesComments() {
   this.postComments = false;
   this.comments = [];
   let status = this.service.getStatus();
   if(this.commentsTyped){
    let obj = {
      "comment": this.commentsTyped,
      "status": status
    }
    this.comments.push(obj);
    let tabObj = {
      'code': this.tabId,
      'name': this.tabName
    }
    this.requestObject = {
      "taskNumber": this.taskNumber,
      "comments": this.comments,
      "type": tabObj
    }
    let self = this;
    this.clientService.setUrl(this.saveTaskComments);
    this.clientService.postClientData(this.requestObject).subscribe(response => {
      this.showMessage("Send Successfully", 3000);
      this.service.setCommentObservable(this.taskNumber);
    });
    this.commentsTyped = '';
    this.cancelPostEvent.emit(this.postComments);
   }

 }

 public postFileNotesComments() {
   this.postComments = false;
   this.comments = [];
   if(this.commentsTyped){
    let obj = {
      "comment": this.commentsTyped,
    }
    this.comments.push(obj);
    let tabObj = {
      'code': this.tabId,
      'name': this.tabName
    }
    this.requestObject = {
      "claimNumber": this.claimNumber,
      "comments": this.comments,
      "type": tabObj
    }
    this.clientService.setUrl(this.taskServiceUrl);
    this.clientService.postClientData(this.requestObject).subscribe(response => {
      this.showMessage("File Note saved successfully", 3000)
      this.service.setFileNoteComment({ 'tabName': this.tabName, 'tabId': this.tabId });
    });
    this.commentsTyped = '';
    this.cancelPostEvent.emit(this.postComments);
   }

 }

 public showMessage(message: string, durationValue: number) {
   this.commonTransformerService.showMessage(message, durationValue);
 }
}