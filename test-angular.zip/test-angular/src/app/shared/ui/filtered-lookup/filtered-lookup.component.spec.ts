import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FilteredLookupComponent } from './filtered-lookup.component';

describe('FilteredLookupComponent', () => {
  let component: FilteredLookupComponent;
  let fixture: ComponentFixture<FilteredLookupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FilteredLookupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FilteredLookupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
