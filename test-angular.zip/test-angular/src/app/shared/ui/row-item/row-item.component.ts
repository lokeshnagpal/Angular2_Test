import { DiaryService } from './../../../screens/diary/diary.service';
import { Component, OnInit, Output, ChangeDetectionStrategy, Input, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-row-item',
  templateUrl: './row-item.component.html',
  styleUrls: ['./row-item.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class RowItemComponent implements OnInit {
  
  @Input() rowItemsValue;
  @Input() taskNumber?;
   private activeTaskNumber:any;
   private activeTaskIndex:any=0;
  @Output() activeTask: EventEmitter<any> = new EventEmitter();
  
  constructor(public service:DiaryService) { }

  ngOnInit() {
    if (this.taskNumber && this.rowItemsValue) {
      this.rowItemsValue.forEach((row, index) => {
        if (row.leftBottomItems.value == this.taskNumber) {
          this.activeTaskNumber = this.taskNumber;
          this.activeTaskIndex = index;
        }
      });
    }
  }

  ngOnChanges(){
    this.service.setRowitemCount(this.rowItemsValue.length);
  }

  public onItemClicked(taskNumber,index){
    this.activeTaskIndex=index;
    this.activeTaskNumber=taskNumber;
    this.activeTask.emit(taskNumber);
    this.service.setPostCommObservable(taskNumber);
  }
}
