import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RowItemMobileComponent } from './row-item-mobile.component';

describe('RowItemMobileComponent', () => {
  let component: RowItemMobileComponent;
  let fixture: ComponentFixture<RowItemMobileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RowItemMobileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RowItemMobileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
