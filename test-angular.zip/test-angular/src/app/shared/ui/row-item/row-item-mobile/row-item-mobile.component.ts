import { Component, OnInit } from '@angular/core';
import { RowItemComponent } from 'src/app/shared/ui/row-item/row-item.component';
import { DiaryService } from 'src/app/screens/diary/diary.service';
import { Input } from '@angular/core';

@Component({
  selector: 'app-row-item-mobile',
  templateUrl: './row-item-mobile.component.html',
  styleUrls: ['./row-item-mobile.component.scss']
})
export class RowItemMobileComponent  implements OnInit {

  @Input() rowItem;
  constructor(public service:DiaryService) {
    
 }

  ngOnInit() {
  }

}
