import { CommonTransformerService } from './../../../../util/common-transformer.service';
import { Component, OnInit,ChangeDetectionStrategy,Input } from '@angular/core';

@Component({
  selector: 'app-row-label',
  templateUrl: './row-label.component.html',
  styleUrls: ['./row-label.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class RowLabelComponent implements OnInit {

  constructor(public commonTransformerService:CommonTransformerService) { }

  @Input() item;

  ngOnInit() {
  }

}
