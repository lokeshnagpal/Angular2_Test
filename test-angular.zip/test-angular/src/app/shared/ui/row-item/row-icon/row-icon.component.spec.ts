import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RowIconComponent } from './row-icon.component';

describe('RowIconComponent', () => {
  let component: RowIconComponent;
  let fixture: ComponentFixture<RowIconComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RowIconComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RowIconComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
