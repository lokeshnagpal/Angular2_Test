import { environment } from './../../../../../environments/environment';
import { RowItem } from './../../../../data/RowItem';
import { Component, OnInit ,ChangeDetectionStrategy,Input} from '@angular/core';

@Component({
  selector: 'app-row-icon',
  templateUrl: './row-icon.component.html',
  styleUrls: ['./row-icon.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class RowIconComponent implements OnInit {

  @Input() item;

  constructor() {
   }

  ngOnInit() {

  }

}
