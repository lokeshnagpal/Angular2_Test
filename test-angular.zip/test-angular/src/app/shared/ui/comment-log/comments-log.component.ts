import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'app-comment-log',
  templateUrl: './comments-log.component.html',
  styleUrls: ['./comments-log.component.scss']
})
export class CommentLogComponent implements OnInit {

  @Input () commentLogs;
  
  

  ngOnInit() {
    console.log("commentsLog",this.commentLogs)    
  }
  
}
