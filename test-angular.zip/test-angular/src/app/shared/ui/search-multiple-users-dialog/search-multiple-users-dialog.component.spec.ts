import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchMultipleUsersDialogComponent } from './search-multiple-users-dialog.component';

describe('SearchMultipleUsersDialogComponent', () => {
  let component: SearchMultipleUsersDialogComponent;
  let fixture: ComponentFixture<SearchMultipleUsersDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchMultipleUsersDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchMultipleUsersDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
