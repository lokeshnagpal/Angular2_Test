import { Component, OnInit, Inject, ElementRef, ViewChild } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { ClientService } from 'src/app/services/client.service';
import { ApplicationStateService } from 'src/app/util/application.state.service';
import { CommonTransformerService } from 'src/app/util/common-transformer.service';
import { Subject } from 'rxjs';
import { debounceTime } from 'rxjs/operators';

@Component({
  selector: 'app-search-multiple-users-dialog',
  templateUrl: './search-multiple-users-dialog.component.html',
  styleUrls: ['./search-multiple-users-dialog.component.scss']
})
export class SearchMultipleUsersDialog implements OnInit {

  public enableSearch: boolean = false;
  public isDesktopResolution: boolean = true;
  public dialogList: any = [];
  public selected: any[] = [];
  public selectedIds: string[] = [];
  public hover: string;
  public hasSelected: boolean = false;
  public query = '';
  public lookupUrl = '';
  public showProgressBar: boolean = false;
  private subject: Subject<string> = new Subject();
  public prevQuery: string = '';
  @ViewChild('searchField', {static: false}) searchField: ElementRef;

  constructor(@Inject(MAT_DIALOG_DATA) public data: any, @Inject(MatDialogRef) public dialogRef: MatDialogRef<SearchMultipleUsersDialog>,
    public clientService: ClientService, public commonTransformerService: CommonTransformerService,
    public applicationStateService: ApplicationStateService) {
      this.isDesktopResolution = this.applicationStateService.getIsDesktopResolution();
    }

  ngOnInit() {
    if (this.data) {
      this.lookupUrl = this.data.url;
      this.getLookupData(this.lookupUrl);
      this.loadSelectedData();
      this.prevQuery = null;
      this.subject.pipe(debounceTime(300)).subscribe(query => {
        if (query) {
          if (query != this.prevQuery) {
            const searchUrl = this.lookupUrl + this.query;
            this.getLookupData(searchUrl);
            this.prevQuery = query;
          }
        } else {
          if (this.prevQuery) {
            const searchUrl = this.lookupUrl;
            this.getLookupData(searchUrl);
            this.prevQuery = null;
          }
        }
      });
    }
  }

  getLookupData(url) {
    this.showProgressBar = true;
    this.clientService.setUrl(url);
    this.clientService.getClientData().subscribe(response => {
      this.dialogList = response;
      this.showProgressBar = false;
    });
  }

  loadSelectedData() {
    if (this.data.selected && this.data.selected.length > 0) {
      this.selected = this.data.selected;
      this.selectedIds = [];
      this.selected.forEach(item => this.selectedIds.push(item.id));
      this.hasSelected = true;
    }
  }

  public getSearchList() {
    this.subject.next(this.query);
  }

  public selectItem(item) {
    if (!this.selectedIds.includes(item.id)) {
      this.selected.push({...item});
      this.selectedIds.push(item.id);
      this.hasSelected = true;
    }
  }

  public removeItem(item) {
    const temp = [];
    if (this.selectedIds.includes(item.id)) {
      this.hover = null;
      const selTemp = [];
      this.selected.forEach(row => {
        if (row.id != item.id) {
          temp.push(row.id);
          selTemp.push(row);
        }
      });
      this.selected = [...selTemp];
      this.selectedIds = temp;
      if (this.selectedIds.length > 0) {
        this.hasSelected = true;
      } else {
        this.hasSelected = false;
      }
    }
  }

  public openSearchPanel() {
    this.enableSearch = true;
    setTimeout(()=>{
      this.searchField.nativeElement.focus();
    },0);
  }

  public hoverItem(item) {
    if (this.hover && this.hover == item.id) {
      this.hover = null;
    } else {
      this.hover = item.id;
    }
  }

  public closeSearchPanel() {
    this.enableSearch = false;
    this.getLookupData(this.lookupUrl);
    this.query = '';
  }

  close(selected?) {
    this.dialogRef.close(selected);
  }
}
