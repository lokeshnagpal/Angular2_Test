export interface Tab {
    id?:number;
    displayTitle?:string;
    navigationLink?:string;
   name?:string;
}

export interface TabMenuAction {
    id?:number;
    displayTitle?:string;
    navigationLink?:string;
   name?:string;
   
}