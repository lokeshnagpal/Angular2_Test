export * from './tabs.config';
