import { Component, OnInit, ViewChild, Output, EventEmitter, Input, ChangeDetectionStrategy } from '@angular/core';
import { MatMenuTrigger } from '@angular/material/menu';
import {Tab,TabMenuAction} from '../model/tabs-with-actions';
import { LLRService } from 'src/app/screens/llr/llr.service';
import { ClaimSummaryService } from './../../../screens/claim-summary/claim-summary.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-tabs-with-actions',
  templateUrl: './tabs-with-actions.component.html',
  styleUrls: ['./tabs-with-actions.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class TabsWithActionsComponent implements OnInit {
  @ViewChild(MatMenuTrigger, {static: false}) trigger: MatMenuTrigger;
  
@Input('tabs') tabs:Tab[];
@Input('tabMenuActions') tabMenuActions:TabMenuAction[]=[];

  /* Event handler to handle the action menu click */
  @Output() public onActionClick = new EventEmitter();

  /* Event handler to handle the tab link click */
  @Output() public onTabLinkClick = new EventEmitter();

  public icon: string = "add";
  public claimNumber: any;
  public taskTypeObj: any = {};
  constructor(public service: ClaimSummaryService, public router: Router, public llrService: LLRService) {
    this.claimNumber = this.service.getClaimSummaryQueryParameter().claimNumber
  }

  ngOnInit() {
    // this.trigger.menuOpened.subscribe(() => this.icon = 'close');
    // this.trigger.menuClosed.subscribe(() => this.icon = 'add');
  
  }
  ngOnChanges(){
  }

  openMenu() {
    this.trigger.menuOpened.subscribe(() => this.icon = 'close');
    this.trigger.menuClosed.subscribe(() => this.icon = 'add');
  }

  navigateToPage(pageName) {
    // let obj:any={};

    switch (pageName) {
      case "llr":
        // this.createTaskObj(pageName)
        // this.createTaskObj("llr_rt");
        this.createTaskObj();
        break;
      // case "llen":
      //   this.createTaskObj(pageName);
      //   break;
    }
  }

  createTaskObj() {
    // pageName = pageName.toUpperCase();
    // this.taskTypeObj.pageName = pageName;
    this.taskTypeObj.type={};
    this.llrService.setTaskTypeValue(this.taskTypeObj);
    this.router.navigate(["/llr"], {
      // queryParams: { "claimNumber": this.claimNumber, tab: pageName },
      queryParams: { "claimNumber": this.claimNumber},
    });
  }
  onTabSelection(event:any){
    
    this.onTabLinkClick.emit(this.tabs[event.index]);
  // console.log("Checkindex", this.tabs[event.index] )
 
  }
}
