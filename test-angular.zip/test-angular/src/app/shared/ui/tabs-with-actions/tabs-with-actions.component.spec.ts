import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TabsWithActionsComponent } from './tabs-with-actions.component';

describe('TabsWithActionsComponent', () => {
  let component: TabsWithActionsComponent;
  let fixture: ComponentFixture<TabsWithActionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TabsWithActionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TabsWithActionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
