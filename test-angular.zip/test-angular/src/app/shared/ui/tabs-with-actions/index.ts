export * from './tabs-with-actions.component';

