import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ClientService } from './../../../services/client.service'
import { environment } from './../../../../environments/environment'
@Component({
  selector: 'app-mind-map',
  templateUrl: './mind-map.component.html',
  styleUrls: ['./mind-map.component.scss']
})
export class MindMapComponent implements OnInit {
  @Input() claimNumber: any;
  public mindMapData
  ngOnInit() {
    this.clientService.setUrl(environment.workingLayerUrl + "/" + this.claimNumber + "/overview?linkedtowers=true")
   this.clientService.getClientData().subscribe(response => {
    //  console.log(response)
   this.dataConversion(response);
  
    });
  }
  constructor(protected route: ActivatedRoute, private clientService: ClientService) { }

  public dataConversion(response){
     this.mindMapData= response.map(el => {
      return{
        ...el,
      }
     })
  }

  public createArray(length) {
    let newLayerArray = [];
    for (let i = 1; i <= length; i++) {
      newLayerArray.push(i)
    }
    return newLayerArray
  }

  public swissRecheck(layerNum, claim) {
    let match = false;
   if(claim.swisreLayers != null){
     
    for (let i = 0; i < claim.swisreLayers.length; i++) {
      if (claim.swisreLayers[i]=== layerNum) {
        match = true;
      }
    }
    return match
  }
}
  public openTowerStructure(claimNumber) {
    window.open(window.location.origin+"/cfc/#activity:/ClaimNum="+claimNumber+"/Tab=ExcessTowerStructure")
   
  }
}