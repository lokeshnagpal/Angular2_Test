import { Subscription } from 'rxjs';
import { Constants } from './../../../util/application.constants';
import { MatSnackBar } from '@angular/material';
import { ClientService } from './../../../services/client.service';
import { environment } from './../../../../environments/environment';;
import { DiaryService } from './../../../screens/diary/diary.service';
import { Component, OnInit,Output,Input,EventEmitter } from '@angular/core';
import { CommonTransformerService } from 'src/app/util/common-transformer.service';

@Component({
  selector: 'app-post-comment',
  templateUrl: './post-comment.component.html',
  styleUrls: ['./post-comment.component.scss']
})
export class PostCommentComponent implements OnInit {

  public commentsTyped: any;
  public maxLength = Constants.MAX_CHARACTER_LENGTH;
  public charLengthLeft=Constants.MAX_CHARACTER_LENGTH;
 public saveTaskComments:string;
 public taskNumber:any;
 public postClick:boolean=true;
public status:any;
public postCommObservable:Subscription
public comments:any=[];

@Input() tabId;
@Input() tabName;

  constructor(private service:DiaryService,private clientService:ClientService,public commonTransformerService: CommonTransformerService) {
    this.saveTaskComments=environment.saveTaskComments;
  }

  ngOnInit() {
    this.postCommObservable=this.service.getPostCommObservable().subscribe(res=>{
      this.commentsTyped='';
    });
  }
  public charLengthchanged() {
    this.charLengthLeft=(this.maxLength)-(this.commentsTyped.length);
    if(this.commentsTyped.length>0){
      this.postClick=false;
    }
    else{
      this.postClick=true;
    }
     }

  public clearComments(){
     this.commentsTyped='';
    this.charLengthLeft=Constants.MAX_CHARACTER_LENGTH;
    this.postClick=true;
     }

  public postComments(){
    this.comments=[];
     this.taskNumber=this.service.getTaskNumber();
      this.status=this.service.getStatus();
      if(this.commentsTyped){
        let obj={
          "comment":this.commentsTyped,
          "status":this.status
        }
        this.comments.push(obj);
        let tabObj={
         'code':this.tabId,
         'name':this.tabName
     }
         let requestObject:any={
           "taskNumber":this.taskNumber,
           "comments":this.comments,
           "type":tabObj
         }
         let self=this;
         this.clientService.setUrl(this.saveTaskComments);
         this.clientService.postClientData(requestObject).subscribe(response => {
           this.showMessage("Comments Saved Successfully", 3000)
           this.service.setCommentObservable(this.taskNumber);
         });
         this.commentsTyped='';
         this.postClick=true;
      }

     }


  public  showMessage(message: string, durationValue: number) {
     this.commonTransformerService.showMessage(message,durationValue);
  }
}
