import { LLRService } from 'src/app/screens/llr/llr.service';
import { Router } from '@angular/router';
import { ClaimSummaryService } from './../../../screens/claim-summary/claim-summary.service';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatMenuTrigger } from '@angular/material/menu';
import { Constants } from './../../../util/application.constants';
@Component({
  selector: 'app-tabs',
  templateUrl: './tabs.component.html',
  styleUrls: ['./tabs.component.scss']
})
export class TabsComponent implements OnInit {
  @ViewChild(MatMenuTrigger, {static: false}) trigger: MatMenuTrigger;
  public icon: string = "add";
  public claimNumber: any;
  public taskTypeObj: any = {};
  constructor(public service: ClaimSummaryService, public router: Router, public llrService: LLRService) {
    this.claimNumber = this.service.getClaimSummaryQueryParameter().claimNumber
  }

  ngOnInit() {
    this.trigger.menuOpened.subscribe(() => this.icon = 'close');
    this.trigger.menuClosed.subscribe(() => this.icon = 'add');
  }

  openMenu() {
    this.trigger.menuOpened.subscribe(() => this.icon = 'close');
    this.trigger.menuClosed.subscribe(() => this.icon = 'add');
  }
  navigateToPage(pageName) {
    // let obj:any={};

    switch (pageName) {
      case "llr":
        this.createTaskObj(pageName)
        break;
      case "llen":
        this.createTaskObj(pageName);
        break;
    }
  }

  createTaskObj(pageName) {
    pageName = pageName.toUpperCase();
    // this.taskTypeObj.pageName = pageName;
    // this.taskTypeObj.type={};
    // this.llrService.setTaskTypeValue(this.taskTypeObj);
    this.router.navigate(["/llr"], {
      queryParams: { "claimNumber": this.claimNumber, tab: pageName },
    });
  }
}
