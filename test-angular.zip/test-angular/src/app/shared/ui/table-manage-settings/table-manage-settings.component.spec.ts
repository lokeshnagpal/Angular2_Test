import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TableManageSettingsComponent } from './table-manage-settings.component';

describe('TableManageSettingsComponent', () => {
  let component: TableManageSettingsComponent;
  let fixture: ComponentFixture<TableManageSettingsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TableManageSettingsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TableManageSettingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
