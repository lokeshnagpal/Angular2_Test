import { Component, OnInit, Inject, ElementRef, ViewChild } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { ClientService } from 'src/app/services/client.service';
import { ApplicationStateService } from 'src/app/util/application.state.service';
import { CommonTransformerService } from 'src/app/util/common-transformer.service';
import { Subject } from 'rxjs';
import { debounceTime } from 'rxjs/operators';

@Component({
  selector: 'app-search-user-dialog',
  templateUrl: './search-user-dialog.component.html',
  styleUrls: ['./search-user-dialog.component.scss']
})
export class SearchUserDialog implements OnInit {

  public enableSearch: boolean = false;
  public isDesktopResolution: boolean = true;
  public dialogList: any = [];
  public selected: any;
  public hasSelected: boolean = false;
  public query = '';
  public lookupUrl = '';
  public showProgressBar: boolean = false;
  private subject: Subject<string> = new Subject();
  public prevQuery: string = '';
  @ViewChild('searchField', {static: false}) searchField: ElementRef;

  constructor(@Inject(MAT_DIALOG_DATA) public data: any, @Inject(MatDialogRef) public dialogRef: MatDialogRef<SearchUserDialog>,
    public clientService: ClientService, public commonTransformerService: CommonTransformerService,
    public applicationStateService: ApplicationStateService) {
      this.isDesktopResolution = this.applicationStateService.getIsDesktopResolution();
    }

  ngOnInit() {
    if (this.data) {
      this.lookupUrl = this.data.url;
      this.getLookupData(this.lookupUrl);
      this.prevQuery = null;
      this.subject.pipe(debounceTime(300)).subscribe(query => {
        if (query) {
          if (query != this.prevQuery) {
            const searchUrl = this.lookupUrl + this.query;
            this.getLookupData(searchUrl);
            this.prevQuery = query;
          }
        } else {
          if (this.prevQuery) {
            const searchUrl = this.lookupUrl;
            this.getLookupData(searchUrl);
            this.prevQuery = null;
          }
        }
      });
    }
  }

  getLookupData(url) {
    this.showProgressBar = true;
    this.clientService.setUrl(url);
    this.clientService.getClientData().subscribe(response => {
      this.dialogList = response;
      this.showProgressBar = false;
    });
  }

  public getSearchList() {
    this.subject.next(this.query);
  }

  public selectItem(item) {
    if (this.hasSelected && this.selected && item.id == this.selected.id) {
      this.selected = null;
      this.hasSelected = false;
    } else {
      this.selected = item;
      this.hasSelected = true;
    }
  }

  public openSearchPanel() {
    this.enableSearch = true;
    setTimeout(()=>{
      this.searchField.nativeElement.focus();
    },0);
  }

  public closeSearchPanel() {
    this.enableSearch = false;
    this.getLookupData(this.lookupUrl);
    this.query = '';
  }

  close(selected?) {
    this.dialogRef.close(selected);
  }
}
