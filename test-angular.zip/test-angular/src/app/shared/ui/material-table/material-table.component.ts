import { Component, OnInit,Output,EventEmitter,Input } from '@angular/core';

@Component({
  selector: 'app-material-table',
  templateUrl: './material-table.component.html',
  styleUrls: ['./material-table.component.scss']
})
export class MaterialTableComponent implements OnInit {
// @Output() elementClick= new EventEmitter();
// @Input('displayedColumns') displayedColumns:any
// @Input('dataSource') dataSource:any
// @Input('sectionDetails') sectionDetails:any

  constructor() { }

  ngOnInit() {
  }
  // emitfunction(element){
  //   this.elementClick.emit(element);
  // }
}
