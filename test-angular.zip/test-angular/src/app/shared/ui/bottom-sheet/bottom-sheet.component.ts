import { DiaryService } from 'src/app/screens/diary/diary.service';
import { Component, OnInit, Input, Inject, Output, EventEmitter } from '@angular/core';
import {MatBottomSheet, MatBottomSheetRef,MAT_BOTTOM_SHEET_DATA} from '@angular/material';
@Component({
  selector: 'app-bottom-sheet',
  templateUrl: './bottom-sheet.component.html',
  styleUrls: ['./bottom-sheet.component.scss']
})
export class BottomSheetComponent implements OnInit {

 @Input() footerActionName;
 @Input() footerCommentsName;
 @Input() showFooterAction;
@Input() postComments;
@Input() activeDiaryName;
@Input() moreOptionsList;
 @Output() openMobDiaryEvent:EventEmitter<any>=new EventEmitter();
 @Output() postCommEvent:EventEmitter<any>=new EventEmitter();
 
  constructor(private bottomSheet: MatBottomSheet,private service:DiaryService) {}
  
    openBottomSheet(): void {
      const bottomSheetRef = this.bottomSheet.open(BottomSheetDialog, {
        //data: { name: this.footerActionName, activeDiary:this.activeDiaryName },
        data: { name: this.footerActionName,  optionsData:this.moreOptionsList },
      });
      bottomSheetRef.afterDismissed().subscribe(res => {
        this.openMobDiaryEvent.emit(res);
      })

      //   if(res=="All Open Diary"){
      //     this.openMobDiaryEvent.emit("allDiary");
      //   }else if(res=="Close Diary"){
      //     this.openMobDiaryEvent.emit("closeDiary");
      //   }else if(res=="Edit Diary"){
      //     this.openMobDiaryEvent.emit("editDiary");
      //   }else if(res=="Next Open Diary"){
      //     this.openMobDiaryEvent.emit("nextOpenDiary");
      //   }   
      // });
    }

  ngOnInit() {
  }

  public openCommentSec(){
 this.postComments=true;
 this.postCommEvent.emit(this.postComments);
  }


}

@Component({
  selector: 'bottom-sheet-dialog',
  templateUrl: 'bottom-sheet-dialog.html',
  styleUrls: ['./bottom-sheet.component.scss']
})
export class BottomSheetDialog {
 
  public footerName:string;
  //public activeDiaryLabel:string;
  public displayList
  
  constructor(private bottomSheetRef: MatBottomSheetRef<BottomSheetDialog>,@Inject(MAT_BOTTOM_SHEET_DATA) public data: any) {
  this.footerName=data.name;
  //this.activeDiaryLabel=data.activeDiary;
  this.displayList= data.optionsData;
  }

  openLink(event: MouseEvent): void {
    this.bottomSheetRef.dismiss();
    event.preventDefault();
  }

  public dialogemit(action ){
    this.bottomSheetRef.dismiss(action)  
  }

// public openDiaryList(){
//   this.bottomSheetRef.dismiss("All Open Diary");
// }

// public closeDiary(){
//   this.bottomSheetRef.dismiss("Close Diary");
// }

// public editDiary(){
//   this.bottomSheetRef.dismiss("Edit Diary");
// }

// public openNextDiary(){
//   this.bottomSheetRef.dismiss("Next Open Diary");
// }
}

