import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FilteredLookupCustomValuesComponent } from './filtered-lookup-custom-values.component';

describe('FilteredLookupCustomValuesComponent', () => {
  let component: FilteredLookupCustomValuesComponent;
  let fixture: ComponentFixture<FilteredLookupCustomValuesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FilteredLookupCustomValuesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FilteredLookupCustomValuesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
