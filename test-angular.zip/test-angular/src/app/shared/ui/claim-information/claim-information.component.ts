import { ClientService } from 'src/app/services/client.service';
import {TooltipPosition} from '@angular/material/tooltip';

import { LLRService } from './../../../screens/llr/llr.service';
import { Component, OnInit } from '@angular/core';
import { CommonTransformerService } from 'src/app/util/common-transformer.service';
import { FormControl, FormGroup, FormBuilder, Validators, ValidatorFn } from '@angular/forms';
@Component({
  selector: 'app-claim-information',
  templateUrl: './claim-information.component.html',
  styleUrls: ['./claim-information.component.scss']
})
export class ClaimInformationComponent implements OnInit {
  positionOptions: TooltipPosition[] = ['after', 'before', 'above', 'below', 'left', 'right'];
  public section: any;
  public dynamicAttributesForm: FormGroup;
  public lookupUrl: any;
  public lookupVal: any = [];
  public optionValue: any;
  public attributeHolder: any = [];
  public sectionDetails: any;
  public dynamicAttributesArray: any = [];
  constructor(public llrService: LLRService, public commonTransformerService: CommonTransformerService, 
    public fb: FormBuilder, public clientService:ClientService) {

  }

  ngOnInit() {
    this.dynamicAttributesForm = this.createForm(this.section.attributes);
    //   console.log("Claim Information",this.section);

    //  let  sectionAttrHolderObject = {
    //     "sectionName": this.section.sectionName,
    //     "attributeMap": this.section.attributes
    //   }    
    // this.llrService.setTaskDetailsData(sectionAttrHolderObject);
  }
  public createForm(obj) {
    const group = this.fb.group({});
    // obj.forEach(control => group.addControl(control.dbColumnName, this.createControl(control)));
    obj.forEach(control => {
      if(control.dbColumnName==undefined){
        control.dbColumnName=control.name;
      }
      group.addControl(control.dbColumnName, this.createControl(control))
     
    }); 
    return group;
  }

  public createControl(config) {
    const { isDisabled } = config;
    let value;
    let validation;
    let item = config;
    if (config.mandatory) {
      validation = Validators.required;
    }
    if (item.type == 'DATEBOX' && item.dbdateValue!=undefined) {
       value = this.commonTransformerService.dateFormatChange(item.dbdateValue);      
      // value = new Date(dateValue);
    }
    else if (item.type == 'SIMPLELOOKUP' && item.dbColumnName == config.dbColumnName && item.referenceDataValue) {
      value = item.referenceDataValue.name;
    }
    //  else if (item.type == 'NUMBERBOX' && item.dbColumnName == config.dbColumnName &&  item.bigDecimalValue) {      
    //     value=item.bigDecimalValue;
    //  }
    else {
      value = item.value;
    }

    let control = this.fb.control({ 'value': value, 'disabled': isDisabled }, validation);
    control.valueChanges.subscribe(res => {
      this.controlChange(control, config);
    })
    return control;
  }

  // method triggered when change in form control
  public controlChange(ctrl, attr) {
    if (attr.type == 'SIMPLELOOKUP' || attr.type == 'MULTISELECTLOOKUP') {
      this.getFilteredLookup(ctrl, attr);
    }
    this.createTaskDetails();
    // this.llrService.setFormValidation();
  }

  //method triggered when lookup input change
  public getFilteredLookup(ctrl, attr) {
    this.optionValue = ctrl.value;
    // if (ctrl.value == "") {
    //   this.firstLastName = undefined;
    // }
    let urlForLookup = this.lookupUrl + '/' + attr.source + '/' + attr.group + '/'
    if (attr.referenceDataValue && attr.referenceDataValue.id && ctrl.value == attr.referenceDataValue.name) {
      urlForLookup = urlForLookup + attr.referenceDataValue.id;
    } else {
      delete attr['referenceDataValue']
      urlForLookup = urlForLookup + ctrl.value;
    }
    this.clientService.setUrl(urlForLookup);
    this.clientService.getClientData().subscribe(response => {
      attr.attributeOptions = response;
    })
  }

  public checkLookupSelectedValue(lokupAttr, ctrl, lookupData) {
    if (lookupData.attributeOptions && lookupData.attributeOptions.length >= 0) {
      let selLookupval = lookupData.attributeOptions.find(x => x.name == ctrl.value);
      if (!selLookupval && !lookupData.referenceDataValue) {
        ctrl.setValue('');
      }
    }
  }

  public lookupOptionSelected(valSelected, config) {
    this.dynamicAttributesForm.controls[config.dbColumnName].setValue(valSelected.option.value);
    config['referenceDataValue'] = config.attributeOptions.find(x => x.name == valSelected.option.value);

  }

  public getLookupData(data, controlName) {
    this.lookupVal = [];
    let urlForLookup = this.lookupUrl + '/' + data.source + '/' + data.group + '/';

    if (data.referenceDataValue && data.referenceDataValue.id && data.value == data.referenceDataValue.name) {
      urlForLookup = urlForLookup + data.referenceDataValue.id;
    }
    this.clientService.setUrl(urlForLookup);
    this.clientService.getClientData().subscribe(response => {
      data.attributeOptions = response;
    })
  }

  createTaskDetails() {
    let attributeMap: any = {};
    let sectionAttrHolderObject: any;

    this.attributeHolder = [];
    for (let attribute of this.section.attributes) {
      let val: any
      if (attribute.value != undefined) {
        val = attribute.value;
      }
      else {
        val = this.dynamicAttributesForm.controls[attribute.dbColumnName].value;
      }

      if (attribute.type == 'TEXTBOX' || attribute.type == 'LABEL' || attribute.type == 'TEXTAREA') {
        let taskObj = {
          attrId: attribute.attrId,
          dbColumnName: attribute.dbColumnName,
          type: attribute.type,
          value: val
        }
        this.attributeHolder.push(taskObj);
      }
      else if (attribute.type == "DATEBOX") {
        let convertedDate;
        if (val) {
          convertedDate = this.commonTransformerService.convertDateInServiceFormat(val);
        }
        let diaryObj = {
          attrId: attribute.attrId,
          dbColumnName: attribute.dbColumnName,
          type: attribute.type,
          dateValue: convertedDate
        }
        this.attributeHolder.push(diaryObj);
      }
      else if (attribute.type == "NUMBERBOX") {
        let taskObj = {
          attrId: attribute.attrId,
          dbColumnName: attribute.dbColumnName,
          type: attribute.type,
          bigDecimalValue: val
        }
        this.attributeHolder.push(taskObj);
      }
      else if (attribute.type == "SIMPLELOOKUP") {
        let referenceObj: any = {
          refDataId: '',
          name: '',
          code: ''
        }
        //  let lookupVal = this.dynamicAttributesForm.controls[attribute.dbColumnName].value;
        if (val && val != '') {
          let itemFound = attribute.attributeOptions.find(x => x.name == val);
          if (itemFound) {
            referenceObj["code"] = itemFound.id;
            referenceObj["refDataId"] = itemFound.refDataId;
            referenceObj["name"] = itemFound.name;
          }
          else {
            if (attribute.referenceDataValue && attribute.referenceDataValue.name == val) {
              referenceObj["code"] = attribute.referenceDataValue.id;
              referenceObj["refDataId"] = attribute.referenceDataValue.refDataId;
              referenceObj["name"] = attribute.referenceDataValue.name;
            }
          }
        }
        let taskObj = {
          attrId: attribute.attrId,
          referenceDataValue: referenceObj,
          dbColumnName: attribute.dbColumnName,
          type: attribute.type,
          value: val
        }
        this.attributeHolder.push(taskObj);
      }
    }

    sectionAttrHolderObject = {
      "sectionName": this.section.sectionName,
      "attributeMap": this.attributeHolder
    }
    this.llrService.setTaskDetailsData(sectionAttrHolderObject);
  }

  // getAttributes() {
  //   for (let attr of this.section.attributes) {
  //     if (attr.type == "DATEBOX") {
  //       let dateValue = this.commonTransformerService.dateFormatChange(attr.dateValue);
  //       attr.dateValue = dateValue;
  //     }
  //   }
  // }
}
