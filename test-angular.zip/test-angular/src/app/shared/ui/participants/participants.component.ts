import { Constants } from './../../../util/application.constants';
import { CommonTransformerService } from './../../../util/common-transformer.service';
import { LLRService } from './../../../screens/llr/llr.service';
import { LlrParticipantsDialogComponent } from './../../../screens/llr/component/llr-participants-dialog/llr-participants-dialog.component';
import { MatDialog } from '@angular/material';
import { Component, OnInit, Input } from '@angular/core';
import { environment } from 'src/environments/environment';
import { SearchMultipleUsersDialog } from '../search-multiple-users-dialog/search-multiple-users-dialog.component';
import { FormControl, FormGroup, FormBuilder, Validators, ValidatorFn } from '@angular/forms';

@Component({
  selector: 'app-participants',
  templateUrl: './participants.component.html',
  styleUrls: ['./participants.component.scss']
})
export class ParticipantsComponent implements OnInit {

  public dialogDataList: any;
  public selectedParticipants: any = [];
  public partList: any;
  public section: any;
  public attributeHolder: any = [];
  @Input() isDisableField: boolean;
  public dateValue: any;
  public dynamicAttributesForm: FormGroup;
  constructor(public dialog: MatDialog, public service: LLRService, public commonTransformerService: CommonTransformerService, public llrService: LLRService, public fb: FormBuilder) { }

  ngOnInit() {
    this.setDataItem();
  }

  //add the participants list in selected partcipants when having referenceDataValueList
  public setDataItem() {
    // let index = this.section.attributes.findIndex(x=>x.sectionCode===Constants.PARTICIPANTS)

    this.section.attributes.forEach((item, index) => {
      switch (item.type) {
        case "MULTISELECTLOOKUP": {
          let initialData = this.section.attributes[index].referenceDataValueList;
          if (initialData === undefined) {
            initialData = null;
          }
          this.createSelectedListObj(initialData);
          if (initialData !== null) this.addSelectedListToTaskDetails();
          break;
        }
        case "DATEBOX": {
          let event: any;
          this.dynamicAttributesForm = this.createForm(item);
          this.llrService.setFormAttributes(this.dynamicAttributesForm,item.sectionName);
          // this.createInServiceFormat(event, index);
          break;
        }
      }

    });




    // let initialData = this.section.attributes[0].referenceDataValueList;  
    //   if(initialData===undefined){
    //     initialData = null;
    //   }
    //   this.createSelectedListObj(initialData);
    //  if(initialData!==null) this.addSelectedListToTaskDetails();
  }

  //add the participants list for selected value in selected participants
  public setSelectedData(dataList, index) {
    this.createSelectedListObj(dataList);
    this.addSelectedListToTaskDetails();
  }

  //create object for selected item 
  public createSelectedListObj(data) {
    this.selectedParticipants = [];
    if (data !== null) {
      for (let item of data) {
        let obj = {
          'id': item.id,
          'code': item.id,
          'name': item.name
        }
        this.selectedParticipants.push(obj);
      }
    } else {
      this.selectedParticipants = [];
    }

  }

  //add selected list to task details section
  addSelectedListToTaskDetails() {
    let sectionAttrHolderObject: any;
    this.attributeHolder = [];
    let isDateCheck = false;
    // if (this.section.attributes[0].type == "MULTISELECTLOOKUP") {
    this.section.attributes.forEach((attribute, index) => {
      if (attribute.type == "MULTISELECTLOOKUP") {
        let taskObj = {
          attrId: attribute.attrId,
          referenceDataValueList: this.selectedParticipants,
          dbColumnName: attribute.dbColumnName,
          type: attribute.type,
          // value: val
        }
        if (this.selectedParticipants.length > 0) {
          attribute.referenceDataValueList = this.selectedParticipants;
        } else {
          this.selectedParticipants = attribute.referenceDataValueList;
        }

        this.attributeHolder.push(taskObj);
      }
      if (attribute.type == "DATEBOX") {
        // let convertedDate: any
        // if (this.dateValue) {
        //   convertedDate = this.dateValue;
        //   attribute.dbdateValue = convertedDate;
        // } else {
        //   if (attribute.dbdateValue) {
        //     let date = this.commonTransformerService.getDatepickerFormat(attribute.dbdateValue);
        //     convertedDate = new Date(date);
        //     attribute.dbdateValue = this.commonTransformerService.dateInServiceFormat(convertedDate);
        //   }
        // }

        // let dateObj = {
        //   attrId: attribute.attrId,
        //   dbColumnName: attribute.dbColumnName,
        //   type: attribute.type,
        //   dateValue: attribute.dbdateValue
        // }
        // this.attributeHolder.push(dateObj);

        let val: any;
        if (this.dynamicAttributesForm.controls[attribute.dbColumnName].value !== undefined) {
          val = this.dynamicAttributesForm.controls[attribute.dbColumnName].value;
        }
        else {
          val = attribute.value;
        }
        let convertedDate;
        if (val) {
          convertedDate = this.commonTransformerService.dateInServiceFormat(val);
        }
        let dateObj = {
          attrId: attribute.attrId,
          dbColumnName: attribute.dbColumnName,
          type: attribute.type,
          dateValue: convertedDate
        }
        this.attributeHolder.push(dateObj);

      }
    });


    sectionAttrHolderObject = {
      "sectionName": this.section.sectionName,
      "attributeMap": this.attributeHolder
    }
    this.llrService.setTaskDetailsData(sectionAttrHolderObject);
  }
  //open the dilalog to add participants
  public openParticipantsPanel(index) {

    if (!this.section.isDisableField) {
      let dialogRef;
      const data = {
        header: 'Add Participants',
        url: environment.lookupUrl + '/' + this.section.attributes[index].source + '/' + this.section.attributes[index].group + '/',
        selected: this.section.attributes[index].referenceDataValueList ? this.section.attributes[index].referenceDataValueList : [],
        select: 'ADD',
        cancel: 'CANCEL'
      };
      dialogRef = this.dialog.open(SearchMultipleUsersDialog, {
        width: '30%',
        minWidth: '480px',
        height: '65%',
        data,
        autoFocus: false
      });
      dialogRef.afterClosed().subscribe(result => {
        if (result) {
          this.setSelectedData(result, index);
        }
      });
    }


  }

  //removed the added participants
  public removeAddedParticipants(index) {
    if (!this.section.isDisableField) {
      this.selectedParticipants.splice(index, 1);
    }
  }

  // createInServiceFormat(event, index) {
  //   if (event != undefined) {
  //     this.dateValue = this.commonTransformerService.dateInServiceFormat(event);
  //   }
  //   this.addSelectedListToTaskDetails();
  // }

  createInServiceFormat(event,attribute) {  
    this.addSelectedListToTaskDetails();
  }

  public createForm(control) {
    const group = this.fb.group({});    
    group.addControl(control.dbColumnName, this.createControl(control))
    return group;
  }

  public createControl(config) {
    const { isDisabled } = config;
    let value;
    let validation;
    let item = config;
    if (config.mandatory) {
      validation = Validators.required;
    }
    if (item.type == 'DATEBOX' && item.dbColumnName == config.dbColumnName && item.dbdateValue) {
      let dateValue = this.commonTransformerService.getDatepickerFormat(item.dbdateValue);
      value = new Date(dateValue);
    }

    let control = this.fb.control({ 'value': value, 'disabled': isDisabled }, validation);
    control.valueChanges.subscribe(res => {
      this.controlChange(control, config);
    })
    return control;
  }

  public controlChange(ctrl, attr) {   
    this.createInServiceFormat(ctrl,attr);
  }
}
