import { CommentLogComponent } from './comment-log/comments-log.component';
import { ClaimDescComponent } from 'src/app/screens/claim-summary/claim-desc/claim-desc.component';
import { RowLabelComponent } from './row-item/row-label/row-label.component';
import { RowIconComponent } from './row-item/row-icon/row-icon.component';
import { NgModule } from '@angular/core';
import { MaterialModule } from './../material/material-module.module';
import { CommonModule } from '@angular/common';
import { PostCommentComponent } from './post-comment/post-comment.component';
import { CommentListComponent } from './comment-list/comment-list.component';
import { FormsModule , ReactiveFormsModule} from '@angular/forms';
import { RowItemComponent } from './row-item/row-item.component';
import { ChipsComponent } from './chips/chips.component';
import { DonutChartComponent } from './charts/donut-chart/donut-chart.component';
// import { SliderDialogComponent } from './sliderDialog/sliderDialog.component';
import { BottomSheetComponent, BottomSheetDialog } from './bottom-sheet/bottom-sheet.component';
import { RowItemMobileComponent } from './row-item/row-item-mobile/row-item-mobile.component';
import { PostMobileComponent } from './post-comment-mobile/post-mobile.component';
import { BaseComponent } from './base/base.component';
import { RichTextComponent } from './rich-text/rich-text.component';
import { ParticipantsComponent } from './participants/participants.component';
import { DynamicFormComponent } from './dynamic-form/dynamic-form.component';
import { ProcessFlowComponent } from './process-flow/process-flow.component';
import { ProcessFlowMobileComponent } from './process-flow-mobile/process-flow-mobile.component';
import { ProcessFlowDesktopComponent } from './process-flow-desktop/process-flow-desktop.component';
import { EditorComponent } from 'src/app/shared/ui/editor/editor.component';
import { FroalaEditorModule, FroalaViewModule } from 'angular-froala-wysiwyg';
import { FinancialInformationComponent } from './financial-information/financial-information.component';
import { ClaimInformationComponent } from './claim-information/claim-information.component';
import { TabsComponent } from './tabs/tabs.component';
import { ConfirmationDialog } from './confirmation-dialog/confirmation-dialog.component';
import { DynamicFieldDirective } from './dynamic-form-validation/components/dynamic-field/dynamic-field.directive';
import { ButtonComponent } from './dynamic-form-validation/components/button/button.component';
import { CheckboxComponent } from './dynamic-form-validation/components/checkbox/checkbox.component';
import { DateComponent } from './dynamic-form-validation/components/date/date.component';
import { InputComponent } from './dynamic-form-validation/components/input/input.component';
import { RadiobuttonComponent } from './dynamic-form-validation/components/radiobutton/radiobutton.component';
import { SelectComponent } from './dynamic-form-validation/components/select/select.component';
import { DynamicFormValidationComponent as DynamicForm } from './dynamic-form-validation/components/dynamic-form-validation/dynamic-form-validation.component';
import { DynamicFormValidationComponent } from './dynamic-form-validation/dynamic-form-validation/dynamic-form-validation.component';
import { TextareaComponent } from './dynamic-form-validation/components/textarea/textarea.component';
import { ConfigureColumnComponent } from './configure-column/configure-column.component';
import { TabsWithActionsComponent} from './tabs-with-actions';
import { FilteredLookupComponent } from './filtered-lookup/filtered-lookup.component';
import { FilteredDropdownComponent } from './filtered-dropdown/filtered-dropdown.component';
import { LookupComponent } from './dynamic-form-validation/components/lookup/lookup.component';
import { PipesModule } from '../pipes/pipes.module';
import { FilteredLookupCustomValuesComponent } from './filtered-lookup-custom-values/filtered-lookup-custom-values.component';
import { FilteredDropdownCustomValuesComponent } from './filtered-dropdown-custom-values/filtered-dropdown-custom-values.component';
import { MaterialTableComponent } from './material-table/material-table.component';
import { FilteredDropdownWithInputComponent } from './filtered-dropdown-with-input/filtered-dropdown-with-input.component';
import { TableSaveSettingsComponent } from './table-save-settings/table-save-settings.component';
import { TableManageSettingsComponent } from './table-manage-settings/table-manage-settings.component';
import { TableLoadSettingsComponent } from './table-load-settings/table-load-settings.component';
import { LinkDocumentsDialog } from './link-documents-dialog/link-documents-dialog.component';
import { ScrollToTopComponent } from './scroll-to-top/scroll-to-top.component';
import { MindMapComponent } from './mind-map/mind-map.component';
import { OverviewComponent } from './overview/overview.component';
import { OverviewDesktopComponent } from './overview-desktop/overview-desktop.component';
import { OverviewMobileComponent } from './overview-mobile/overview-mobile.component';
import { PreviewDocumentComponent } from './preview-document/preview-document.component';
import { SearchLocationDialog } from './search-location-dialog/search-location-dialog.component';
import { MoreDetailsSidenavComponent } from './more-details-sidenav/more-details-sidenav.component';
import { LocationFiltersSidenavComponent } from './location-filters-sidenav/location-filters-sidenav.component';
import { FilteredDropdownWithIconComponent } from './filtered-dropdown-with-icon/filtered-dropdown-with-icon.component';
import { IconLookupComponent } from './dynamic-form-validation/components/icon-lookup/icon-lookup.component';
import { SearchUserDialog } from './search-user-dialog/search-user-dialog.component';
import { SearchMultipleUsersDialog } from './search-multiple-users-dialog/search-multiple-users-dialog.component';
import { LinkPolicyDocumentsDialog } from './link-policy-documents/link-policy-documents.component';
import { HorizontalBarStackedComponent } from './charts/horizontal-bar-stacked/horizontal-bar-stacked.component';
@NgModule({
  declarations: [EditorComponent, ClaimDescComponent, BaseComponent, PostCommentComponent, CommentListComponent,
    RowItemComponent, RowIconComponent, RowLabelComponent, ChipsComponent, DonutChartComponent, BottomSheetComponent,
    BottomSheetDialog, RowItemMobileComponent, PostMobileComponent, RichTextComponent, ParticipantsComponent,
    DynamicFormComponent, ProcessFlowComponent, ProcessFlowMobileComponent, ProcessFlowDesktopComponent,
    FinancialInformationComponent, ClaimInformationComponent, TabsComponent, ConfirmationDialog, DynamicFieldDirective,
    ButtonComponent, CheckboxComponent, DateComponent, InputComponent, RadiobuttonComponent, SelectComponent,
    TextareaComponent, ConfigureColumnComponent, DynamicForm, DynamicFormValidationComponent, ConfigureColumnComponent,
    TabsWithActionsComponent, FilteredLookupComponent, FilteredDropdownComponent, LookupComponent,
    FilteredLookupCustomValuesComponent, FilteredDropdownCustomValuesComponent, FilteredDropdownWithInputComponent,
    MaterialTableComponent, TableSaveSettingsComponent, TableManageSettingsComponent, TableLoadSettingsComponent,
    LinkDocumentsDialog, ScrollToTopComponent, MindMapComponent, OverviewComponent, OverviewDesktopComponent,
    OverviewMobileComponent, PreviewDocumentComponent, SearchLocationDialog, MoreDetailsSidenavComponent,
    LocationFiltersSidenavComponent, FilteredDropdownWithIconComponent, IconLookupComponent, SearchUserDialog,
    SearchMultipleUsersDialog,CommentLogComponent, LinkPolicyDocumentsDialog, HorizontalBarStackedComponent],
  imports: [
    FormsModule , ReactiveFormsModule, CommonModule, MaterialModule, PipesModule,
    FroalaEditorModule.forRoot(), FroalaViewModule.forRoot()
  ],
  entryComponents: [
    BottomSheetDialog,
    CommentListComponent,
    PostCommentComponent,
    DynamicFormComponent,
    ParticipantsComponent,
    EditorComponent,
    ClaimDescComponent,
    FinancialInformationComponent,
    RichTextComponent,
    ClaimInformationComponent,
    TabsComponent,
    ConfirmationDialog,
    DynamicFormValidationComponent,
    ButtonComponent,
    CheckboxComponent,
    DateComponent,
    InputComponent,
    RadiobuttonComponent,
    SelectComponent,
    TextareaComponent,
    LookupComponent,
    DynamicForm,
    FilteredLookupComponent,
    FilteredDropdownComponent,
    FilteredLookupCustomValuesComponent,
    FilteredDropdownCustomValuesComponent,
    FilteredDropdownWithInputComponent,
    MaterialTableComponent,
    TableSaveSettingsComponent,
    TableManageSettingsComponent,
    TableLoadSettingsComponent,
    LinkDocumentsDialog,
    ScrollToTopComponent,
    MindMapComponent,
    PreviewDocumentComponent,
    SearchLocationDialog,
    MoreDetailsSidenavComponent,
    LocationFiltersSidenavComponent,
    FilteredDropdownWithIconComponent,
    IconLookupComponent,
    SearchUserDialog,
    SearchMultipleUsersDialog,
    CommentLogComponent,
    LinkPolicyDocumentsDialog,
    HorizontalBarStackedComponent
  ],
  exports: [
    ClaimDescComponent,
    PostCommentComponent,
    RowIconComponent,
    RowLabelComponent,
    RowItemComponent,
    ConfigureColumnComponent,
    CommentListComponent,
    FormsModule ,
    ReactiveFormsModule,
    CommonModule,
    MaterialModule,
    ChipsComponent,
    BottomSheetDialog,
    BottomSheetComponent,
    DonutChartComponent,
    PostMobileComponent,
    BaseComponent,
    RichTextComponent,
    ParticipantsComponent,
    DynamicFormComponent,
    ProcessFlowComponent,
    ProcessFlowMobileComponent,
    ProcessFlowDesktopComponent,
    //  SliderDialogComponent,
    RowItemMobileComponent,
    EditorComponent,
    FinancialInformationComponent,
    ClaimInformationComponent,
    TabsComponent,
    ConfirmationDialog,
    DynamicFormValidationComponent,
    DynamicFieldDirective,
    ButtonComponent,
    CheckboxComponent,
    DateComponent,
    InputComponent,
    RadiobuttonComponent,
    SelectComponent,
    TextareaComponent,
    LookupComponent,
    DynamicForm,
    TabsWithActionsComponent,
    FilteredLookupComponent,
    FilteredDropdownComponent,
    FilteredLookupCustomValuesComponent,
    FilteredDropdownCustomValuesComponent,
    FilteredDropdownWithInputComponent,
    MaterialTableComponent,
    TableSaveSettingsComponent,
    TableManageSettingsComponent,
    TableLoadSettingsComponent,
    LinkDocumentsDialog,
    ScrollToTopComponent,
    MindMapComponent,
    OverviewComponent,
    OverviewDesktopComponent,
    OverviewMobileComponent,
    PreviewDocumentComponent,
    SearchLocationDialog,
    FilteredDropdownWithIconComponent,
    IconLookupComponent,
    SearchUserDialog,
    SearchMultipleUsersDialog,
    CommentLogComponent,
    LinkPolicyDocumentsDialog,
    HorizontalBarStackedComponent
  ],
})
export class UiModule { }
