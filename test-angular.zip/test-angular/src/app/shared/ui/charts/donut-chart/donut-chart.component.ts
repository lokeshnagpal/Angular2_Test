import { ApplicationStateService } from './../../../../util/application.state.service';
import { Component, OnInit, ViewChild, ElementRef, Input, OnDestroy } from '@angular/core';
import { Chart } from 'chart.js';
import { Subscription } from 'rxjs';


@Component({
    selector: 'app-donut-chart',
    templateUrl: './donut-chart.component.html',
    styleUrls: ['./donut-chart.component.scss'],

})
export class DonutChartComponent implements OnInit {
    public subscription: Subscription;
    private chart: any;
    public doNutData: any;
    private doNutDataSets: any;
    private doNutOptions: any;
    private ctx: any
    private doNutChart: any;
    private canvas: any;
    public mobileView: boolean = false;
    @ViewChild('canvas', {static: false}) canvasRef: ElementRef;
    @ViewChild('donutlegend', {static: false}) donutLegend: ElementRef;
    @Input('labelData') labelData: any;
   
    constructor(public appStateService: ApplicationStateService) {

        this.mobileView = !this.appStateService.getIsDesktopResolution();

    }


    ngOnInit() {
       

    }
    ngAfterViewInit() {     
      
        this.showChart(false);
    }

    ngOnChanges() {    
        this.ctx="";     
        this.ctx = this.canvasRef.nativeElement.getContext('2d');  
        this.ctx.canvas.width=150;
        this.ctx.canvas.height=150; 
        this.showChart(true);
    }

    showChart(isCreate) {

        this.doNutData = this.labelData.summary.values;

        this.doNutDataSets = {
            labels: [],
            mobileView: this.mobileView,
            datasets: [
                {
                    name: this.labelData.summary.name,
                    data: this.doNutData,
                    labelData: this.labelData.summary.labels,                 
                    backgroundColor: this.labelData.summary.background,
                    currency: this.labelData.summary.currency,
                    borderWidth: 1,
                    fill:true
                }
            ]
        };
        this.doNutOptions = {
            responsive: false,
            maintainAspectRatio:true,         
           showTooltips:false,
            animation: {
                animateScale: true,
                animateRotate: true
            },
           
            cutoutPercentage: 60,
            rotation: -0.5 * Math.PI,   
         
            tooltips: {
                // mode: 'label',
                // position:"nearest",
                // yAlign: 'top',
                // xAlign: 'center',
                // xPadding: 25,
                // yPadding: 15,              
                // titleAlign: 'center',
                // footerAlign: 'center',
                // bodyAlign: 'center',
                enabled: false,
                // custom: this.chartToolTip,
            },
            legendCallBack: function (chart) {
                var text = [];             
                text.push('<ul >');
                for (var i = 0; i < chart.config.data.labels.length; i++) {
                    text.push('<li >' + chart.config.data.labels[i]);
                    text.push('</li>');
                }
                text.push('</ul>');
                return text.join('');

            },
            legend: false,
            // plugins: {               
            //     zoom: {
            //       enabled: true,
            //     //   drag: true,
            //     //   mode: 'x',
            //       onZoom: function () { console.log('I was zoomed!!!'); }
            //     },
            //   },

        };        
        if(isCreate){
            if(this.doNutChart!=undefined)
            {
                this.chart.destroy();
                this.doNutChart.destroy();
            }
            this.doNutChart = new Chart(this.ctx, {
                type: 'doughnut',
                data: this.doNutDataSets,
                options:this.doNutOptions
              });     
            
              if(!this.doNutChart.data.mobileView){
                this.doNutChart.options.tooltips.enabled=false;
                this.doNutChart.options.tooltips.custom=this.chartToolTip;
              }   
            
              this.addLabelData(this.doNutChart);
             this.donutLegend.nativeElement.innerHTML=this.doNutChart.options.legendCallBack(this.doNutChart);             
         }else {
            this.doNutChart.data=this.doNutDataSets;
            this.doNutChart.update();      
            if(!this.doNutChart.data.mobileView){
                this.doNutChart.options.tooltips.enabled=false;
                this.doNutChart.options.tooltips.custom=this.chartToolTip;
              }       
            this.addLabelData(this.doNutChart);
            this.donutLegend.nativeElement.innerHTML=this.doNutChart.options.legendCallBack(this.doNutChart);
             
         }


    }

    addLabelData(chart){
        this.chart = chart;
        // let data:any = chart.config.data;
        let datasetObj: any = chart.config.data.datasets[0];
        chart.config.data.labels = [];
        for (let i = 0; i < datasetObj.labelData.length; i++) {
            let val: any;
            // if (datasetObj.data[i] != "0") {
                if (datasetObj.name == "Finance_Info") {
                    val = '<span style="background-color:' + datasetObj.backgroundColor[i] + '"></span><span class="legend-label">' + datasetObj.labelData[i] + '</span><br><span class="legend-value">' + (datasetObj.currency ? datasetObj.currency : 'USD')+ '&nbsp' + datasetObj.data[i] + '</span>';
                }
                else {
                    val = '<span style="background-color:' + datasetObj.backgroundColor[i] + '"></span><span class="legend-label">' + datasetObj.labelData[i] + '</span>';
                    if (chart.config.data.mobileView) {
                        val = val + '<span  class="legend-value">' + datasetObj.data[i] + '%' + '</span>'
                    }
                }
                chart.config.data.labels.push(val);
            // }
        }
    }    

    chartToolTip(tooltipModel) {   
        // tooltipModel.yAlign='bottom';
        // tooltipModel.xAlign='center';
        // // tooltipModel.xPadding= 25,
        // tooltipModel.yPadding= 15;
        // tooltipModel.xPadding=45;
    //   console.log("tooltipmodel",tooltipModel);
       
        let datasets: any = this['_chart'].config.data.datasets[0];
        let tooltipEl: any = document.getElementById('chartjs-tooltip');
        if (!tooltipEl) {
            tooltipEl = document.createElement('div');
            tooltipEl.id = 'chartjs-tooltip';          
            tooltipEl.innerHTML = "<div></div>"
            document.body.appendChild(tooltipEl);
        }
        // Hide if no tooltip
        if (tooltipModel.opacity === 0) {
            tooltipEl.style.opacity = 0;
            return;
        }
        // Set caret Position
        tooltipEl.classList.remove('above', 'below', 'no-transform');
        if (tooltipModel.yAlign) {
            tooltipEl.classList.add(tooltipModel.yAlign);
        } else {
            tooltipEl.classList.add('no-transform');
        }

        function getBody(bodyItem) {
            return bodyItem.lines;
        }
        // Set Text
        if (tooltipModel.body) {
            var titleLines = tooltipModel.title || [];
            var bodyLines = tooltipModel.body.map(getBody);
            var innerHtml = '<div style="background:rgba(245, 245, 245, 1);font-size:18px;font-family:swissReOtFontRegular;display:inline-block;padding:9px 16px;border-radius:0px">'
            // var body = '<span>' + datasets.labelData[tooltipModel.dataPoints[0].index] + '</span>' + ' ' + '<span>' + datasets.data[tooltipModel.dataPoints[0].index] + '%' + '</span>'
            var body; 
            if(datasets.name=="Finance_Info"){
                 body = '<span>' + datasets.labelData[tooltipModel.dataPoints[0].index] + '</span>' + ': ' + (datasets.currency ? datasets.currency : 'USD') + '&nbsp' + '<span>' + datasets.data[tooltipModel.dataPoints[0].index] + '</span>'
              }else{
                body = '<span>' + datasets.labelData[tooltipModel.dataPoints[0].index] + '</span>' + ' ' + '<span>' + datasets.data[tooltipModel.dataPoints[0].index] + '%' + '</span>'
              }
            innerHtml += body + '</div>';
            var tableRoot = tooltipEl.querySelector('div');
            tableRoot.innerHTML = innerHtml;
        }

        // `this` will be the overall tooltip
        var position = this['_chart'].canvas.getBoundingClientRect();
    
        // Display, position, and set styles for font
        tooltipEl.style.opacity = 1;
        tooltipEl.style.position = 'absolute';
        tooltipEl.style.left = position.left + window.pageXOffset + tooltipModel.caretX + 'px';
        tooltipEl.style.top = position.top + window.pageYOffset + tooltipModel.caretY + 'px';
        tooltipEl.style.fontFamily = tooltipModel._bodyFontFamily;
        tooltipEl.style.fontSize = tooltipModel.bodyFontSize + 'px';
        tooltipEl.style.fontStyle = tooltipModel._bodyFontStyle;
        tooltipEl.style.padding = tooltipModel.yPadding + 'px ' + tooltipModel.xPadding + 'px';
        tooltipEl.style.pointerEvents = 'none';      
    }  




}



