import { Component, OnInit, Input, ElementRef, ViewChild } from '@angular/core';
import { ApplicationStateService } from './../../../../util/application.state.service';
import { Chart } from 'chart.js';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-horizontal-bar-stacked',
  templateUrl: './horizontal-bar-stacked.component.html',
  styleUrls: ['./horizontal-bar-stacked.component.scss']
})
export class HorizontalBarStackedComponent implements OnInit {

  @Input() financeData;
  @ViewChild('canvas', {static: false}) canvasRef: ElementRef;
  @ViewChild('horizontalBarLegend', {static: false}) legend: ElementRef;

  public mobileView: boolean = false;
  private ctx: any;
  private data: any;
  private options: any;

  constructor(public appStateService: ApplicationStateService) {
    this.mobileView = !this.appStateService.getIsDesktopResolution();
  }

  ngOnInit() {
  }
  ngOnChanges() {
    if (this.financeData) {
      this.parseData();
      this.ctx = this.canvasRef.nativeElement.getContext('2d');
      this.ctx.canvas.width = 150;
      this.ctx.canvas.height = 150;
      // tslint:disable-next-line: no-unused-expression
      new Chart(this.ctx, {
        type: 'horizontalBar',
        data: this.data,
        options: this.options
      });
    }
  }

  parseData() {
    console.log(this.financeData);
    this.data = {
      labels: this.financeData.summary.labels,
      datasets: [{
        data: [1000, 2000, 500, 600, 200, 100, 175],//this.financeData.summary.values,
        backgroundColor: [
          'rgba(40, 54, 147, 1)',
          'rgba(60, 90, 253, 1)',
          'rgba(60, 90, 253, 0.6)',
          'rgba(140, 158, 255, 1)',
          'rgba(140, 158, 255, 0.6)',
          'rgba(179, 135, 255, 1)',
          'rgba(29, 233, 182, 1)'
        ]
      }]
    };
    this.options = {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true
                }
            }]
        }
    };
  }
}
