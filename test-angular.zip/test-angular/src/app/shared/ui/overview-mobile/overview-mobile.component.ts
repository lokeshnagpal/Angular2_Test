import { ApplicationStateService } from './../../../util/application.state.service';
import { OverviewComponent } from './../overview/overview.component';
import { Component, OnInit, Output, EventEmitter, Input, OnDestroy } from '@angular/core';
import { ClientService } from 'src/app/services/client.service';
import { CommonTransformerService } from 'src/app/util/common-transformer.service';
import { BaseComponent } from '../base/base.component';

@Component({
  selector: 'app-overview-mobile',
  templateUrl: './overview-mobile.component.html',
  styleUrls: ['./overview-mobile.component.scss']
})
export class OverviewMobileComponent extends OverviewComponent implements OnInit {
  
public headerData:any;
public contentData:any;
public chipsList:any;
public mobileOverviewData: any;
// public claimDescriptionData: string;
// public isExpanded: boolean = false;
@Input() claimNumber:string
  constructor(public clientService: ClientService, public commonTransformerService: CommonTransformerService,
  public applicationStateService: ApplicationStateService, public baseComponent: BaseComponent) {
    super(clientService, commonTransformerService,applicationStateService);
  }

  ngOnInit() {
    // this.subscribeToData();
    this.subscription = this.clientService.overviewData.subscribe(res => {         
      if(Object.keys(res).length>0){
        this.mobileOverviewData= res;
        if(this.mobileOverviewData.attributes!=null){
          this.headerData = this.commonTransformerService.headerDataConverter(this.mobileOverviewData.attributes)
          this.contentData = this.commonTransformerService.mobileOverviewListData(this.mobileOverviewData.attributes)
          // this.chipsList = this.mobileOverviewData.attributes[1].chips;
         
          let index=this.mobileOverviewData.attributes.findIndex(x=>x.type==='CHIP');
          if(index!==-1){
            this.chipsList = this.mobileOverviewData.attributes[index].chips;
          }
        }    
      }    
    });
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
    this.clientService.setOverviewData({})
  }
  public viewFileNavigate(url,tabIndex) {
    // let obj=this.clientService.getQueryParams();
    const fileNoteUrl:any=window.location.origin +window.location.pathname + '#' + url+'?claimNumber='+this.claimNumber +'&tabIndex='+tabIndex;
    window.open(fileNoteUrl);
}
// subscribeToData() {

//   this.subscription = this.baseComponent._getClaimSummary().subscribe(res => {
//     if (res.claimDescription != null) {
//       this.claimDescriptionData = res.claimDescription;
//     }
//   });

// }

}
