import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OverviewMobileComponent } from './overview-mobile.component';

describe('LlrOverviewMobileComponent', () => {
  let component: OverviewMobileComponent;
  let fixture: ComponentFixture<OverviewMobileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [OverviewMobileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OverviewMobileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
