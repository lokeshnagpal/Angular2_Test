import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { ClientService } from 'src/app/services/client.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-search-location-dialog',
  templateUrl: './search-location-dialog.component.html',
  styleUrls: ['./search-location-dialog.component.scss']
})
export class SearchLocationDialog implements OnInit {

  public location: any;
  public locationList: any[];
  public option: string = '';
  public selected: any;
  public showProgressBar: boolean = false;
  public sidenavLabel: any = {
    'details': 'More Details',
    'filter': 'Filters',
    'sort': 'Sort'
  };
  public totalCount: number = 0;
  @ViewChild('sidenav', {static: false}) sidenav: any;
  
  constructor(@Inject(MAT_DIALOG_DATA) public data: any, @Inject(MatDialogRef) public dialogRef: MatDialogRef<SearchLocationDialog>,
    public clientService: ClientService) { }

  ngOnInit() {
    this.fetchLocationData();
  }

  fetchLocationData(query?) {
    // https://corflowclm-train1.swissreapps-np.com/ccc/locationConfigurator/locations

    // if (this.data && this.data.claimNumber) {
    //   const attr = {
    //     'searchCriteria': {
    //       'claimNumber': this.data.claimNumber,
    //       'queryString': query ? query : '',
    //       'startRow': '0',
    //       'endRow': '12'
    //     }
    //   };
    //   this.showProgressBar = true;
    //   this.clientService.setUrl(environment.lookupUrl + '/location');
    //   this.clientService.postClientData(attr).subscribe(response => {
    //     console.log('fetchLocationData', response);
    //     this.showProgressBar = false;
    //     // this.totalCount = response.totalCount;
    //     // this.locationList = response.locations;
    //   });
    // }
    this.locationList = [
      {
        'lmsId': '12312314',
        'keyLocation': 'true',
        'countryId': 'USA',
        'countryName': 'United States',
        'address': {
          'line1': '12525 ELLA BLVD, Houston',
          'line2': 'Texas, 77067'
        }
      },
      {
        'lmsId': '323445545',
        'keyLocation': 'false',
        'countryId': 'ROM',
        'countryName': 'Romania',
        'address': {
          'line1': '266 Tiffany Place Rehrersburg North',
          'line2': 'Dakota Romania 458'
        }
      },
      {
        'lmsId': '12312315',
        'keyLocation': 'true',
        'countryId': 'USA',
        'countryName': 'United States',
        'address': {
          'line1': '12525 ELLA BLVD, Houston',
          'line2': 'Texas, 77067'
        }
      },
      {
        'lmsId': '323445546',
        'keyLocation': 'false',
        'countryId': 'ROM',
        'countryName': 'Romania',
        'address': {
          'line1': '266 Tiffany Place Rehrersburg North',
          'line2': 'Dakota Romania 458'
        }
      }
    ];
  }

  getCompleteAddress(address) {
    let completeAddress = '';
    let count = 0;
    for (const i in address) {
      if (count != 0) {
        completeAddress += ', ';
      }
      completeAddress += address[i];
      count++;
    }
    return completeAddress;
  }

  loadDetails(location) {
    this.location = location;
    this.openSidenav('details');
  }

  selectLocation(item) {
    if (this.selected && this.selected.lmsId == item.lmsId) {
      this.selected = null;
    } else {
      this.selected = item;
    }
  }

  openSidenav(option) {
    this.option = option;
    this.sidenav.open();
  }

  close(selected?) {
    this.dialogRef.close(selected);
  }
}
