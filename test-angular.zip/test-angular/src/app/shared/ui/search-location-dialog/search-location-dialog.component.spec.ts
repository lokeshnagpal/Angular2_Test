import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchLocationDialog } from './search-location-dialog.component';

describe('SearchLocationDialog', () => {
  let component: SearchLocationDialog;
  let fixture: ComponentFixture<SearchLocationDialog>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchLocationDialog ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchLocationDialog);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
