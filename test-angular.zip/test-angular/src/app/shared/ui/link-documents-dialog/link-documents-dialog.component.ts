import { Component, OnInit, Inject } from '@angular/core';
import { CommonTransformerService } from 'src/app/util/common-transformer.service';
import { ClientService } from 'src/app/services/client.service';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { environment } from 'src/environments/environment';
import { ApplicationStateService } from 'src/app/util/application.state.service';

@Component({
  selector: 'app-link-documents-dialog',
  templateUrl: './link-documents-dialog.component.html',
  styleUrls: ['./link-documents-dialog.component.scss']
})
export class LinkDocumentsDialog implements OnInit {

  public linkedDocumentsIds: string[] = [];
  public documentUrl: string;
  public allDocuments: any[] = [];
  public linkedDocuments: any[] = [];
  public dataSource: any;
  public displayedColumns: string[] = ['document_name', 'launch', 'doc_id', 'created_by', 'document_date', 'linked'];
  public isIE;
  public tab: string = 'all';
  public changes: string[] = [];

  constructor(@Inject(MAT_DIALOG_DATA) public data: any, @Inject(MatDialogRef) public dialogRef: MatDialogRef<LinkDocumentsDialog>,
    public clientService: ClientService, public commonTransformerService: CommonTransformerService,
    public applicationStateService: ApplicationStateService) {
      this.isIE = this.applicationStateService.isBrowserIE();
     

  }

  ngOnInit() {
    if (this.data) {
      this.linkedDocumentsIds = [];
      if(this.data.linkedDocuments){
        this.data.linkedDocuments.forEach(document => {
          this.linkedDocumentsIds.push(document.doc_id);
        });
      }     
      this.documentUrl = this.data.documentUrl;
      this.fetchDocuments();
      // this.parseData(); //To Be Removed
    }
  }

  fetchDocuments() {
    this.clientService.setUrl(this.documentUrl);
    this.clientService.getClientData().subscribe(response => {
      this.allDocuments = response;
      this.parseData();
    }); 
  }

  parseData() {
    const data = [];
    const linked = [];
    this.data.linkedDocuments.forEach(document => {
      const parameters = {
        'linked': true
      };
      linked.push({...document, ...parameters});
    });
    this.linkedDocuments = linked;
    this.allDocuments.forEach(row => {
      const paramters = {
        'linked': this.linkedDocumentsIds.includes(row.doc_id)
      };
      data.push({...row, ...paramters});
    });
    this.allDocuments = data;
    this.dataSource = data;
  }

  loadDocuments(tab) {
    if(tab.index == 1) {
      this.tab = 'linked';
      this.dataSource = this.linkedDocuments;
    } else {
      this.tab = 'all';
      this.dataSource = this.allDocuments;
    }
  }

  dateFormatChange(date) {
    return this.commonTransformerService.dateObjectFormatChange(date);
  }

  launchDocument(document) {
    const url = environment.streamingServlet + '?docId=' + document.doc_id + '&appName=NATIVE&openInline=Y ';
    window.open(url);
  }

  toggleLinkDocument(document) {
    const docId = document.doc_id;
    const found = this.allDocuments.find(document => document.doc_id == docId);
    if (found) {
      if (!this.changes.includes(docId)) {
        this.changes.push(docId);
      }
      found.linked = !found.linked;
      if (found.linked) {
        this.linkedDocuments.push(found);
      } else {
        this.linkedDocuments = this.linkedDocuments.filter(document => document.doc_id != docId);
      }
      if (this.tab == 'linked') {
        this.dataSource = this.linkedDocuments;
      }
    }
  }

  link(documents) {
    const attr = {
      'taskNumber': this.data.taskNumber,
      'docAction': 'LINK',
      'documents': {},
    };
    documents.forEach(docId => {
      attr.documents[docId] = null;
    });
    this.clientService.setUrl(environment.documentUrl + 'link');
    this.clientService.linkDocuments(attr).subscribe();
  }

  delink(documents) {
    const attr = {
      'taskNumber': this.data.taskNumber,
      'docAction': 'DELINK',
      'documents': {}
    };
    documents.forEach(docId => {
      attr.documents[docId] = null;
    });
    this.clientService.setUrl(environment.documentUrl + 'link');
    this.clientService.linkDocuments(attr).subscribe();
  }

  close(save?) {
    if (save) {
      const link = [];
      const delink = [];
      this.changes.forEach(docId => {
        const isLinked = this.linkedDocuments.find(document => document.doc_id == docId);
        if (isLinked) {
          link.push(docId);
        } else {
          delink.push(docId);
        }
      });
      if (link.length > 0) {
        this.link(link);
      }
      if (delink.length > 0) {
        this.delink(delink);
      }
      this.dialogRef.close(this.linkedDocuments);
    } else {
      this.dialogRef.close(null);
    }
  }
}
