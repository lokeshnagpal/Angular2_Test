import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LinkDocumentsDialogComponent } from './link-documents-dialog.component';

describe('LinkDocumentsDialogComponent', () => {
  let component: LinkDocumentsDialogComponent;
  let fixture: ComponentFixture<LinkDocumentsDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LinkDocumentsDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LinkDocumentsDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
