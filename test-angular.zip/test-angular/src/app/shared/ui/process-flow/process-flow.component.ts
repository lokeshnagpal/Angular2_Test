import { ClientService } from './../../../services/client.service';
import { environment } from './../../../../environments/environment';
import { Component, OnInit,Input } from '@angular/core';
import { LLRService } from 'src/app/screens/llr/llr.service';

@Component({
  selector: 'app-process-flow',
  templateUrl: './process-flow.component.html',
  styleUrls: ['./process-flow.component.scss']
})
export class ProcessFlowComponent implements OnInit {

  public stepProcessUrl:any;
  public stepData;
  public activeStepIndex:any;
  public isStepCompleted:boolean=false;
 @Input() stepsCreated:any;
 @Input() tab:string;
 public status:string;
  constructor(protected clientService: ClientService,public llrService:LLRService) {
    this.stepProcessUrl=environment.processStepUrl;
    this.getProcessFlowData();
   }

  ngOnInit() {
  }

  ngOnChanges(){
    if(this.stepsCreated){
      this.getProcessFlowData();
    }
  }
  

  public getProcessFlowData(){
    let taskNumber:any;   
    // this.clientService.setUrl(this.stepProcessUrl + this.clientService.getQueryParams().tab + '/' +this.clientService.getQueryParams().taskNumber);
    this.clientService.setUrl(this.stepProcessUrl + "LLR_RT" + '/' +this.clientService.getQueryParams().taskNumber);
    this.clientService.getClientData().subscribe(res=>{
    this.llrService.setProcessStatus(res.status);  
    this.status=res.status;
    this.stepData=res.processSteps;
    this.activeStepIndex = this.stepData.findIndex(x=>x.active==true);
    if(this.activeStepIndex===-1){
      this.activeStepIndex=0;
    }
    if(this.stepData.length-1===this.activeStepIndex){
        this.isStepCompleted=true;
    }
    console.log(this.activeStepIndex);
  
    })
  }
}
