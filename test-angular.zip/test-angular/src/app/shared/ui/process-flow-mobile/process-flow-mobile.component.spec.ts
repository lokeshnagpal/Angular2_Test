import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProcessFlowMobileComponent } from './process-flow-mobile.component';

describe('ProcessFlowMobileComponent', () => {
  let component: ProcessFlowMobileComponent;
  let fixture: ComponentFixture<ProcessFlowMobileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProcessFlowMobileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProcessFlowMobileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
