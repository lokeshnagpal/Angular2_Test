import { LLRService } from 'src/app/screens/llr/llr.service';
import { ProcessFlowComponent } from './../process-flow/process-flow.component';
import { Component, OnInit } from '@angular/core';
import { ClientService } from './../../../services/client.service';
@Component({
  selector: 'app-process-flow-mobile',
  templateUrl: './process-flow-mobile.component.html',
  styleUrls: ['./process-flow-mobile.component.scss']
})
export class ProcessFlowMobileComponent extends ProcessFlowComponent implements OnInit {

  constructor(protected clientService: ClientService,public llrSrvice:LLRService) {
    super(clientService,llrSrvice);
   }

  ngOnInit() {
  }

}
