import { LLRService } from 'src/app/screens/llr/llr.service';
import { Constants } from './../../../util/application.constants';
import { Component, OnInit,Input } from '@angular/core';
import { CommonTransformerService } from 'src/app/util/common-transformer.service';

@Component({
  selector: 'app-financial-information',
  templateUrl: './financial-information.component.html',
  styleUrls: ['./financial-information.component.scss']
})
export class FinancialInformationComponent implements OnInit {
  // public financeInfoArray = Array(4).fill(4);
  // public inputVal: number;
  public constant = Constants;
  public financialsData:any;
  public section:any;
  @Input() isDisableField: boolean;
  constructor(public commonTranformService: CommonTransformerService,public llrService:LLRService) { }

  ngOnInit() {    
    
     this.financialsData=this.llrService.getFinancialInformation();
     this.calculate();
  }

  // method to add the row and column values
  add(before, proposed, after) {

       var invalidcharacters = /[^0-9]/gi;
       this.financialsData[proposed]= this.financialsData[proposed].replace(invalidcharacters, "");
      this.financialsData[after] = (Number(this.financialsData[before]) + Number(this.financialsData[proposed])).toString();

    //Total incurred
    this.calculate();
  }
  calculate(){
    if(this.financialsData){
      this.financialsData['indemnityAfterIncurred']=(Number(this.financialsData['indemnityBeforeIncurred']) + Number(this.financialsData['indemnityProposedIncurred'])).toString();
      this.financialsData['expenseAfterIncurred']=(Number(this.financialsData['expenseBeforeIncurred']) + Number(this.financialsData['expenseProposedIncurred'])).toString();
      
      this.financialsData['totalBeforeIncurred']=(Number(this.financialsData['totalBeforeIncurred'])).toString();
      this.financialsData['totalProposedIncurred'] = (Number(this.financialsData['indemnityProposedIncurred']) + Number(this.financialsData['expenseProposedIncurred'])).toString();
      this.financialsData['totalAfterIncurred'] = (Number(this.financialsData['indemnityAfterIncurred']) + Number(this.financialsData['expenseAfterIncurred'])).toString();
     
      this.llrService.setCalculatedFinancialInformation(this.financialsData)
    }   
  }
}
