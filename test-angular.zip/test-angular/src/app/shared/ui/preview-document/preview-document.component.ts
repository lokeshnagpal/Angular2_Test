import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-preview-document',
  templateUrl: './preview-document.component.html',
  styleUrls: ['./preview-document.component.scss']
})
export class PreviewDocumentComponent implements OnInit {

  @Input() documentSrc;

  constructor() { }

  ngOnInit() {
  }
}
