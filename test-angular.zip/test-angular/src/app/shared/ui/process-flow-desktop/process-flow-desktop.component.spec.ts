import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProcessFlowDesktopComponent } from './process-flow-desktop.component';

describe('ProcessFlowDesktopComponent', () => {
  let component: ProcessFlowDesktopComponent;
  let fixture: ComponentFixture<ProcessFlowDesktopComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProcessFlowDesktopComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProcessFlowDesktopComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
