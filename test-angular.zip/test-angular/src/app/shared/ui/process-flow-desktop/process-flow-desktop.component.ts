import { LLRService } from 'src/app/screens/llr/llr.service';
import { ClientService } from './../../../services/client.service';
import { ProcessFlowComponent } from './../process-flow/process-flow.component';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-process-flow-desktop',
  templateUrl: './process-flow-desktop.component.html',
  styleUrls: ['./process-flow-desktop.component.scss']
})
export class ProcessFlowDesktopComponent extends ProcessFlowComponent implements OnInit {

  constructor(protected clientService: ClientService,public llrSrvice:LLRService) {
 super(clientService,llrSrvice);

   }

  ngOnInit() {
  }

}
