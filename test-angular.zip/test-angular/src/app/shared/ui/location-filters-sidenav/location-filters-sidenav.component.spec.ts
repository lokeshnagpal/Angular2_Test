import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LocationFiltersSidenavComponent } from './location-filters-sidenav.component';

describe('LocationFiltersSidenavComponent', () => {
  let component: LocationFiltersSidenavComponent;
  let fixture: ComponentFixture<LocationFiltersSidenavComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LocationFiltersSidenavComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LocationFiltersSidenavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
