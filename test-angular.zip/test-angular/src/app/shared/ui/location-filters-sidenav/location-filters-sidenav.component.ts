import { Component, OnInit } from '@angular/core';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-location-filters-sidenav',
  templateUrl: './location-filters-sidenav.component.html',
  styleUrls: ['./location-filters-sidenav.component.scss']
})
export class LocationFiltersSidenavComponent implements OnInit {

  public testUrl: string = environment.lookupUrl + '/REFDATA/Categories_Diary_Date/';
  public filterList: any[] = [1,2,3,4,5,6,7,8,9];

  constructor() { }

  ngOnInit() {
  }

  logger(event) {
    console.log(event);
  }

  clearFilters() {
    
  }
}
