import { CommonTransformerService } from './../../../util/common-transformer.service';
import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'app-comment-list',
  templateUrl: './comment-list.component.html',
  styleUrls: ['./comment-list.component.scss']
})
export class CommentListComponent implements OnInit {

  @Input () taskComments;
  
  constructor(private commonTransformerService: CommonTransformerService) { }

  ngOnInit() {    
  }

  getDateTime(datetime) {
    const date = this.commonTransformerService.dateTimeZoneChange(datetime);
    return this.commonTransformerService.dateObjectToDateTimeChange(date);
  }
}
