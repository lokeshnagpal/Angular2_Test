import { Constants } from './../../../util/application.constants';
import { LLRService } from 'src/app/screens/llr/llr.service';
import { CommonTransformerService } from 'src/app/util/common-transformer.service';
import { ClientService } from 'src/app/services/client.service';
import { environment } from './../../../../environments/environment';
import { FormControl, FormGroup, FormBuilder, Validators, ValidatorFn } from '@angular/forms';
import { DynamicComponentDirective } from './../../../screens/llr/directive/dynamic-component.directive';
import { Component, OnInit, ViewChild, ChangeDetectorRef, Input } from '@angular/core';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';

@Component({
  selector: 'app-dynamic-form',
  templateUrl: './dynamic-form.component.html',
  styleUrls: ['./dynamic-form.component.scss']
})
export class DynamicFormComponent implements OnInit {

  public section: any;
  public lookupUrl: any;
  public lookupVal: any = [];
  public optionValue: any;
  public dynamicAttributesForm: FormGroup;
  public attributeHolder: any = [];
  public sectionDetails: any;
  public dynamicAttributesArray: any = [];
  public firstLastName: string;
  public maxLength = Constants.CHARACTER_LENGTH;
  public charLengthLeft = Constants.CHARACTER_LENGTH;
  @Input() isDisableField;
  public lookupSelectedValue: any;
  public usersRoleStatus: any;
  public addMultiLevelButton: boolean = false;
  public deleteMultiLevelButton: boolean = false;
  public referenceListLength:any;
  public constants:any=[];
  private subject: Subject<string> = new Subject();
  public isLoading: boolean = false;
  public tempCtrl: any;
  public tempAttr: any;

  constructor(public fb: FormBuilder, public clientService: ClientService, private commonTransformerService: CommonTransformerService,
     public llrService: LLRService) {
    this.lookupUrl = environment.lookupUrl;
   this.constants=Constants.MULTI_LEVEL_OPTIONS
  }

  ngOnInit() {
    this.dynamicAttributesForm = this.createForm(this.section.attributes);
    this.llrService.setFormAttributes(this.dynamicAttributesForm, this.section.sectionName);
    // this.createTaskDetails();
    this.showMultiLevel();
    // this.disableControls();
    this.subject.pipe(debounceTime(300), distinctUntilChanged(),
    switchMap((query) => {
      const split = query.split('#^#');
      const dbColumnName = split[1];
      this.tempCtrl = this.dynamicAttributesForm.controls[dbColumnName];
      this.tempCtrl.setValue(split[0]);
      if (split.length > 2) {
        this.tempAttr = this.section.attributes.find(attribute => attribute.dbColumnName == split[2]);
      } else {
        this.tempAttr = this.section.attributes.find(attribute => attribute.dbColumnName == dbColumnName);
      }
      this.createTaskDetails(this.tempCtrl);
      return this.getFilteredLookup(this.tempCtrl, this.tempAttr);
    })).subscribe(response => {
      if (this.tempCtrl.value.indexOf('-') == -1) {
        this.addAttrId(this.tempAttr, response);
      }
      this.isLoading = false;
    });
  }


  public createForm(obj) {
    const group = this.fb.group({});
    if(obj[0].type==='MULTI_VALUE_LOOKUP'){
       this.createControl(obj[0],group);
    }else{
      obj.forEach(control => group.addControl(control.dbColumnName, this.createControl(control)));      
    }
    return group;
   
  }

  public createControl(config,group?) {
    const { isDisabled } = config;
    let value;
    let validation;
    let item = config;
    if (config.mandatory) {
      validation = Validators.required;
    }
    if (item.type == 'DATEBOX' && item.dbColumnName == config.dbColumnName && item.dbdateValue) {
      let dateValue = this.commonTransformerService.getDatepickerFormat(item.dbdateValue);
      value = new Date(dateValue);
    }
    else if (item.type == 'SIMPLELOOKUP' && item.dbColumnName == config.dbColumnName && item.referenceDataValue) {
      value = item.referenceDataValue.name;
      this.getFirstAndLastName(value);
    }
    else if (item.type == 'NUMBERBOX' && item.dbColumnName == config.dbColumnName && item.bigDecimalValue) {
      value = item.bigDecimalValue;
    }
    else if (item.type == 'MULTI_VALUE_LOOKUP' && item.dbColumnName == config.dbColumnName) {
   
      if (item.referenceDataValueList === undefined) {
        let referenceObj: any = {
          refDataId: '',
          name: '',
          code: '',
          dbColumnName: Constants.MULTI_LEVEL_OPTIONS[0].dbColumnName,
          firstLastName: '',
          placeHolderName: Constants.MULTI_LEVEL_OPTIONS[0].name,
          active:false
        }
        item.referenceDataValueList = [];
        item.referenceDataValueList.push(referenceObj)
        value = referenceObj.name;      
        group.addControl(Constants.MULTI_LEVEL_OPTIONS[0].dbColumnName,this.multiLookUpContrl(value,isDisabled,validation,item));
      }
      else {
        let controlFound:any;
        item.referenceDataValueList.forEach((element,index) => {    
          element["placeHolderName"]=Constants.MULTI_LEVEL_OPTIONS[index].name;
          element["dbColumnName"]=Constants.MULTI_LEVEL_OPTIONS[index].dbColumnName;   
          element['firstLastName']= this.getFirstAndLastName(element.name);
         if(item.referenceDataValueList[index].active==undefined){
          item.referenceDataValueList[index].active=false;
         }
         controlFound=group.controls[Constants.MULTI_LEVEL_OPTIONS[index].dbColumnName];
         value = config.referenceDataValueList[index].name;
          if(!controlFound){
            group.addControl(Constants.MULTI_LEVEL_OPTIONS[index].dbColumnName,this.multiLookUpContrl(value,isDisabled,validation,item));  
          }   
        
        });
        // let index = config.referenceDataValueList.length - 1;        
        this.referenceListLength=config.referenceDataValueList.length;
      }
      this.dynamicAttributesForm=group;
    }
    else {
      value = item.value;
    }

    if(config.type!=="MULTI_VALUE_LOOKUP"){
      let control = this.fb.control({ 'value': value, 'disabled': isDisabled }, validation);
      control.valueChanges.subscribe(res => {
        this.controlChange(control, config);

      })
      return control;
    }
 
  }

  multiLookUpContrl(value,isDisabled,validation,config){
   let control = this.fb.control({ 'value': value, 'disabled': isDisabled }, validation);
        control.valueChanges.subscribe(res => {
          this.controlChange(control, config);  
        });     
        return control
  }

  // method triggered when change in form control
  public controlChange(ctrl, attr) {
    // if (attr.type === 'SIMPLELOOKUP' || attr.type === 'MULTI_VALUE_LOOKUP') {
    //   this.getFilteredLookup(ctrl, attr);
    // }
    if (attr.type === 'TEXTAREA') {
      this.charLengthLeft = (this.maxLength) - (ctrl.value.length);
    }
    this.checkFieldTypeValidation(ctrl, attr);
    this.createTaskDetails(ctrl);
  }

  public debouncedFilteredLookup(dbColumnName, attr?) {    
    let query = this.dynamicAttributesForm.controls[dbColumnName].value + '#^#' + dbColumnName;
    if (attr) {
      query += '#^#' + attr;
    }
    this.subject.next(query);
    this.firstLastName = undefined;
  }

  //method to check the validation based on type
  checkFieldTypeValidation(control, attribute) {
    switch (attribute.type) {
      case "PERCENTAGE_INPUT" || "NUMBERBOX":
        {
          if (this.commonTransformerService.onlyNumber(control.value)) {
            control.errors = "Please enter only number";
            control['_status'] = 'INVALID'
            control.markAsTouched();
          }
          else {
            control['_status'] = 'VALID'
          }
          break;
        }
      case "CURRENCY_INPUT":
        {
          let checkNumber: any = this.commonTransformerService.numberWithDecimal(control.value)
          if (checkNumber.flag) {
            control.errors = "Please enter only number with decimal";
            control['_status'] = 'INVALID'
            control.markAsTouched();
          }
          else {
            control.setValue(checkNumber.value, { emitEvent: false });
            // control.markAsTouched();   
            control['_status'] = 'VALID';


          }
        }
    }
  }

  //method triggered when lookup input change
  public getFilteredLookup(ctrl, attr) {
    this.optionValue = ctrl.value;
    if (ctrl.value == "") {
      this.firstLastName = undefined;
    }
    let urlForLookup = this.lookupUrl + '/' + attr.source + '/' + attr.group + '/'
    if (attr.referenceDataValue && attr.referenceDataValue.id && ctrl.value == attr.referenceDataValue.name) {
      urlForLookup = urlForLookup + attr.referenceDataValue.id;
    } else {
      delete attr['referenceDataValue']
      urlForLookup = urlForLookup + ctrl.value;
    }
    this.isLoading = true;
    this.clientService.setUrl(urlForLookup);
    return this.clientService.getClientData();
  }

  public checkLookupSelectedValue(lokupAttr, ctrl, lookupData, index?) {
    let selLookupval;
    if (ctrl.value && !this.lookupSelectedValue) {
      if (lookupData.attributeOptions && lookupData.attributeOptions.length >= 0) {
        let selLookupval = lookupData.attributeOptions.find(x => x.name == ctrl.value);
        if (lookupData.type === "MULTI_VALUE_LOOKUP") {
          // if (!lookupData.referenceDataValueList[index]) {
            const found = lookupData.attributeOptions.find(attribute => ctrl.value == attribute.name || ctrl.value == attribute.displayNameId);
            let foundRef;
            if (lookupData.referenceDataValueList) {
              foundRef = lookupData.referenceDataValueList.find(item => item.displayNameId == ctrl.value || item.name == ctrl.value);
            }
            if ((lookupData.attributeOptions.length == 0 || !found) && ((lookupData.referenceDataValueList && !foundRef) || !lookupData.referenceDataValueList)) {
              ctrl.setValue('');
            }
          // }
        } else {
          // if (!lookupData.referenceDataValue) {
            const found = lookupData.attributeOptions.find(attribute => ctrl.value == attribute.name || ctrl.value == attribute.displayNameId);
            const foundRef = lookupData.referenceDataValue && (lookupData.referenceDataValue.displayNameId == ctrl.value || lookupData.referenceDataValue.name == ctrl.value);
            if (!found && (!foundRef || !lookupData.referenceDataValue)) {
              ctrl.setValue('');
            }
          // }
        }
      }
    }
    else if (this.lookupSelectedValue) {
      if (lookupData.attributeOptions && lookupData.attributeOptions.length >= 0) {
        let selLookupval = lookupData.attributeOptions.find(x => x.name == this.lookupSelectedValue);
        if (lokupAttr.type === "MULTI_VALUE_LOOKUP" || lookupData.type === "MULTI_VALUE_LOOKUP") {
          const found = lookupData.referenceDataValueList.find(item => item.displayNameId == this.lookupSelectedValue || item.name == this.lookupSelectedValue);
          if (!selLookupval && !lookupData.referenceDataValueList[index] && !found) {
            ctrl.setValue('');
          }
        } else {
          if (!selLookupval && !lookupData.referenceDataValue) {
            ctrl.setValue('');
          }
        }
      }
    }
    this.lookupSelectedValue = '';
  }

  public lookupOptionSelected(valSelected, config, dbColumnName?, index?) {
    if (config.type === "MULTI_VALUE_LOOKUP") {
      this.dynamicAttributesForm.controls[dbColumnName].setValue(valSelected.option.value, { emitEvent: false });
      this.lookupSelectedValue = valSelected.option.value;
      config['referenceDataValueList'][index] = config.attributeOptions.find(x => x.displayNameId == valSelected.option.value);
      config['referenceDataValueList'][index].dbColumnName = dbColumnName;
      config['referenceDataValueList'][index].firstLastName = this.getFirstAndLastName(valSelected.option.value);
    } else {
      this.dynamicAttributesForm.controls[config.dbColumnName].setValue(valSelected.option.value, { emitEvent: false });
      this.lookupSelectedValue = valSelected.option.value;
      if (config.dbColumnName === Constants.LINE_MANAGER || config.dbColumnName === Constants.FINAL_REVIEWER ||
        config.dbColumnName === Constants.DELEGATED_TO) {
        config['referenceDataValue'] = config.attributeOptions.find(x => x.displayNameId == valSelected.option.value);
      }
      else {
        config['referenceDataValue'] = config.attributeOptions.find(x => x.name == valSelected.option.value);
      }
      this.getFirstAndLastName(valSelected.option.value);
    }

  }

  public getLookupData(data, controlName) {
    this.lookupVal = [];
    let urlForLookup = this.lookupUrl + '/' + data.source + '/' + data.group + '/';

    if (data.referenceDataValue && data.referenceDataValue.id && data.value == data.referenceDataValue.name) {
      urlForLookup = urlForLookup + data.referenceDataValue.id;
    }
    this.clientService.setUrl(urlForLookup);
    this.clientService.getClientData().subscribe(response => {
      // data.attributeOptions = response;
      this.addAttrId(data, response);
    })
  }

  //append id with name for assignee lookup
  public addAttrId(attr, response) {
    // if (attr.dbColumnName === Constants.LINE_MANAGER || attr.dbColumnName === Constants.FINAL_REVIEWER ||
    //   attr.dbColumnName === Constants.DELEGATED_TO) {
      attr.attributeOptions = response;
      for (let item of attr.attributeOptions) {
        item["displayNameId"] = item.id + " " + "-" + " " + item.name;
      }
    // }
    // else {
    //   attr.attributeOptions = response;
    // }
  }

  createTaskDetails(ctrl?) {
    let attributeMap: any = {};
    let sectionAttrHolderObject: any;

    this.attributeHolder = [];
    for (let attribute of this.section.attributes) {
      let val: any
      if (this.dynamicAttributesForm.controls[attribute.dbColumnName].value !== undefined) {
        val = this.dynamicAttributesForm.controls[attribute.dbColumnName].value;
      }
      else {
        val = attribute.value;
      }

      if (attribute.type == 'TEXTBOX' || attribute.type == 'LABEL' || attribute.type == 'TEXTAREA' ||
        attribute.type == 'CURRENCY_INPUT' || attribute.type == 'PERCENTAGE_INPUT') {
        let taskObj = {
          attrId: attribute.attrId,
          dbColumnName: attribute.dbColumnName,
          type: attribute.type,
          value: val
        }
        this.attributeHolder.push(taskObj);
      }
      else if (attribute.type == "DATEBOX") {
        let convertedDate;
        if (val) {
          convertedDate = this.commonTransformerService.dateInServiceFormat(val);
        }
        let diaryObj = {
          attrId: attribute.attrId,
          dbColumnName: attribute.dbColumnName,
          type: attribute.type,
          dateValue: convertedDate
        }
        this.attributeHolder.push(diaryObj);
      }
      else if (attribute.type == "NUMBERBOX") {
        let taskObj = {
          attrId: attribute.attrId,
          dbColumnName: attribute.dbColumnName,
          type: attribute.type,
          bigDecimalValue: val
        }
        this.attributeHolder.push(taskObj);
      }
      else if (attribute.type == "SIMPLELOOKUP") {
        let referenceObj: any = {
          refDataId: '',
          name: '',
          code: ''
        }
        //  let lookupVal = this.dynamicAttributesForm.controls[attribute.dbColumnName].value;
        if (attribute.dbColumnName === Constants.LINE_MANAGER || attribute.dbColumnName === Constants.FINAL_REVIEWER ||
          attribute.dbColumnName === Constants.DELEGATED_TO || attribute.dbColumnName===Constants.SCHEDULER
           || attribute.sectionCode === Constants.LLR_MAILBOX_DETAILS) {
          // let value=this.dynamicAttributesForm.controls[attribute.dbColumnName].value;
          if (val) {
            const index = val.indexOf('-');
            if (index != -1) {
              val = val.slice(index + 2, val.length);
            }
          }
        }
        else {
          val = this.dynamicAttributesForm.controls[attribute.dbColumnName].value;
        }
        if (val && val != '') {
          let itemFound = attribute.attributeOptions.find(x => x.name == val);
          if (itemFound) {
            referenceObj["code"] = itemFound.id;
            referenceObj["refDataId"] = itemFound.refDataId;
            referenceObj["name"] = itemFound.name;
          }
          else {
            if (attribute.referenceDataValue && attribute.referenceDataValue.name == val) {
              referenceObj["code"] = attribute.referenceDataValue.id;
              referenceObj["refDataId"] = attribute.referenceDataValue.refDataId;
              referenceObj["name"] = attribute.referenceDataValue.name;
            }
          }
          let taskObj = {
            attrId: attribute.attrId,
            referenceDataValue: referenceObj,
            dbColumnName: attribute.dbColumnName,
            type: attribute.type,
            value: val
          }
          // this.getFirstAndLastName(val);
          this.attributeHolder.push(taskObj);
        }
      }
      else if (attribute.type == "MULTI_VALUE_LOOKUP") {
      
        let taskObj: any;;        
        let referenceValueArray = [];
        let controlFound:any;
        // for (let item of attribute.referenceDataValueList) {
        attribute.referenceDataValueList.forEach((item, index) => {
          item.dbColumnName = Constants.MULTI_LEVEL_OPTIONS[index].dbColumnName;        
          if (this.dynamicAttributesForm.controls[item.dbColumnName].value !== undefined && this.dynamicAttributesForm.controls[item.dbColumnName].value !== null) {
            val = this.dynamicAttributesForm.controls[item.dbColumnName].value;
          }
          else {
            val = item.name;
          }
          if (item.dbColumnName === Constants.MULTI_LEVEL_OPTIONS[index].dbColumnName) {
            if (val) {
              const index = val.indexOf('-');
              if (index != -1) {
                val = val.slice(index + 2, val.length);
              }
            }
            else {
              val = this.dynamicAttributesForm.controls[item.dbColumnName].value;
            }
          }
          item['firstLastName']= undefined; 
          if (val && val != '') {
            let itemFound = attribute.attributeOptions.find(x => x.name == val);
            if (itemFound) {
              item["code"] = itemFound.id;
              item["refDataId"] = itemFound.refDataId;
              item["name"] = itemFound.name;
              item['firstLastName'] = this.getFirstAndLastName(itemFound.name);
              item["placeHolderName"]=Constants.MULTI_LEVEL_OPTIONS[index].name;
              item["dbColumnName"]=Constants.MULTI_LEVEL_OPTIONS[index].dbColumnName;
            }
            else {
              if(item.name===val){
                item['firstLastName'] = this.getFirstAndLastName(item.name);
                item["placeHolderName"]=Constants.MULTI_LEVEL_OPTIONS[index].name
                item["dbColumnName"]=Constants.MULTI_LEVEL_OPTIONS[index].dbColumnName
              }          
            }
            let obj = Object.assign({}, item);
            delete obj["dbColumnName"];
            delete obj["firstLastName"];
            delete obj["placeHolderName"];
            delete obj["active"];
            referenceValueArray.push(obj);
            taskObj = {
              attrId: attribute.attrId,
              referenceDataValueList: referenceValueArray,
              dbColumnName: attribute.dbColumnName,
              type: attribute.type,
              // value: val
            }
          }
          // }
          item["dbColumnName"]=Constants.MULTI_LEVEL_OPTIONS[index].dbColumnName;
          item["placeHolderName"]=Constants.MULTI_LEVEL_OPTIONS[index].name;       
        });
        if(taskObj){
          this.attributeHolder.push(taskObj);
        }      
      }
    }
    sectionAttrHolderObject = {
      "sectionName": this.section.sectionName,
      "attributeMap": this.attributeHolder,
      "sectionCode": this.section.sectionCode
    }
    this.llrService.setTaskDetailsData(sectionAttrHolderObject);
  }

  getFirstAndLastName(name) {
    const index = name.indexOf('-');
    let splitArray = [];
    if (index != -1) {
      name = splitArray = name.split("-")[1].trim();
    }
    //  splitArray=name.split(",");
    // this.firstLastName=splitArray[1].trim().substring(0,1) + splitArray[0].substring(0,1);
    this.firstLastName = this.commonTransformerService.createChips(name);
    return this.firstLastName;
  }
  addDeleteMultilevelApprover(mode, attribute) {
    let obj: any = {
      refDataId: "",
      code: "",
      name: "",
      dbColumnName: "",
      firstLastName: "",
      placeHolderName: "",
      active:true
    }
    let refListLength;
    if (mode === 'ADD') {
      if(attribute.referenceDataValueList.length<=10){
        this.addMultiLevelButton = false;
        this.deleteMultiLevelButton = true;
        obj.dbColumnName = Constants.MULTI_LEVEL_OPTIONS[attribute.referenceDataValueList.length].dbColumnName;
        obj.placeHolderName = Constants.MULTI_LEVEL_OPTIONS[attribute.referenceDataValueList.length].name;
        attribute.referenceDataValueList.push(obj); 
        this.createForm(this.section.attributes);
      }     
    } else if (mode === 'DELETE') {
      this.addMultiLevelButton = true;
      this.deleteMultiLevelButton = false;
      if (attribute.referenceDataValueList.length > 1) {
        refListLength = attribute.referenceDataValueList.length - 1;
        this.dynamicAttributesForm.removeControl(attribute.referenceDataValueList[refListLength].dbColumnName);     
        attribute.referenceDataValueList.pop();
        this.referenceListLength=attribute.referenceDataValueList.length;
        this.createTaskDetails();
       console.log("form",this.dynamicAttributesForm)
      }
    }
  }

  showMultiLevel() {
    console.log("multilevel")
    if(this.usersRoleStatus!==undefined){
      if (Object.keys(this.usersRoleStatus).length > 0) {
        switch (true) {
          case this.usersRoleStatus.role === Constants.LINE_MANAGER &&
            (this.usersRoleStatus.status === Constants.SENT_TO_LINE_MANAGER):
            this.addMultiLevelButton = true;
            this.deleteMultiLevelButton = false;
            return true;
          case this.usersRoleStatus.role === Constants.ASSIGNEE &&
            (this.usersRoleStatus.status === Constants.DRAFT_APPROVED):
            this.addMultiLevelButton = true;
            this.deleteMultiLevelButton = false;
            return true;
          default:
            return false;
        }
      }
    }  
  }
}
