import { Component, OnInit, Input, Output, EventEmitter, SimpleChanges } from '@angular/core';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { ApplicationStateService } from 'src/app/util/application.state.service';

@Component({
  selector: 'app-configure-column',
  templateUrl: './configure-column.component.html',
  styleUrls: ['./configure-column.component.scss']
})
export class ConfigureColumnComponent implements OnInit {
@Input('configColumns' )configColumns = [];
@Input() DIARY_DATA: any;
@Input() diaryData: any;
@Input() clearConfig: boolean;
@Output() onClearConfigure = new EventEmitter();
@Output() public onConfigureColumnsEvent = new EventEmitter();
@Output () stickyColumnEvent = new EventEmitter();
@Output() closeNavEvent = new EventEmitter();
public showLock: boolean = true;
public selectedHeader: any;
public showClosedLock: boolean = false;
public checkedColumnLength: any;
public isIE: boolean = false;

  constructor(public applicationStateService: ApplicationStateService) {
    this.isIE = this.applicationStateService.isBrowserIE();
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.clearConfig && changes.clearConfig.currentValue) {
      this.clearConfigure();
    }
    if (changes.configColumns) {
      this.getMandatoryCount();
    }
  }

  ngOnInit() {
    if (this.DIARY_DATA) {
      this.diaryData = { ...this.DIARY_DATA };
    }
  }

  getMandatoryCount() {    
    this.checkedColumnLength = 0;
    for (let item of this.configColumns){
      if (item.mandatory){
        this.checkedColumnLength++;
      }
    }
  }

  /* Method to handle the reordering of columns */
  reOrder(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.configColumns, event.previousIndex, event.currentIndex);
    const columns = [];
    this.configColumns.forEach(column => {
      if (column.mandatory) {
        columns.push(column.columnName);
      }
    });
    this.onConfigureColumnsEvent.emit({
     columns: ['select', ...columns]
    });  
  }

   /* Update columns based on the selection */
   public updateColumnSelections(item, event) {
    let columns = this.configColumns.filter((header, index) => {
      if (header.columnName === item) {
        if (event.checked) {
          if ( this.checkedColumnLength < 9) {
            header.mandatory = true;
            this.checkedColumnLength++;
          } else {
            header.mandatory = false;
            this.configColumns[index].mandatory = false;
          }
        } else if (!event.checked){
          header.mandatory = false;
          this.checkedColumnLength --;
        }
      }
      return header.mandatory;
    });
    const columnNames = columns.map(column => column.columnName);
    columns = ['select', ...columnNames];
     this.onConfigureColumnsEvent.emit({columns});
  }

  public columnSticky(colName) {
      this.selectedHeader = colName;
      for (const item of this.diaryData.headers) {
        if (colName == item.columnName) {
               this.showClosedLock = true;
              this.showLock = false;
            item["sticky"] = true;
        } else {
          item["sticky"] = false;
        }
      }
      this.stickyColumnEvent.emit("actionColumnSticky");
  }
  public columnNonSticky(colName) {
      for (const item of this.diaryData.headers) {
        if (colName == item.columnName) {
          this.showClosedLock = false;
          this.showLock = true;
            item["sticky"] = false;
        }
      }
      this.stickyColumnEvent.emit("actionColumnNonSticky");
  }

  public clearConfigure() {
    let column = [];
    this.configColumns = [];
   for (const item of this.diaryData.headers) {
     item["sticky"] = false;
   }
   this.showClosedLock = false;
   this.showLock = true;
   this.closeNavEvent.emit("sideNavClose");
   this.DIARY_DATA.sectionDetails.forEach(header => {
    if (!header.hidden) {
      column.push({...header});
      this.configColumns.push({...header});
    }
  });  
  const columnNames = [];
  column.forEach(header => {
    if (header.mandatory) {
      columnNames.push(header.columnName);
    }
  });
  this.onClearConfigure.emit(false);
  this.onConfigureColumnsEvent.emit({
    columns: ['select', ...columnNames]
   });
 }
}
