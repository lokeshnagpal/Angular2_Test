import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigureColumnComponent } from './configure-column.component';

describe('ConfigureColumnComponent', () => {
  let component: ConfigureColumnComponent;
  let fixture: ComponentFixture<ConfigureColumnComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfigureColumnComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigureColumnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
