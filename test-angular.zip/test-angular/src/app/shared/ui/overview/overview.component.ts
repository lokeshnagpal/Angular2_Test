import { ApplicationStateService } from 'src/app/util/application.state.service';

import { Subscription } from 'rxjs';
import { environment } from './../../../../environments/environment';
import { Component, OnInit, Output, EventEmitter,Input } from '@angular/core';
import { ClientService } from 'src/app/services/client.service';
import { CommonTransformerService } from 'src/app/util/common-transformer.service';

@Component({
  selector: 'app-overview',
  templateUrl: './overview.component.html',
  styleUrls: ['./overview.component.scss']
})
export class OverviewComponent implements OnInit {

  public taskOverviewUrl:any;
  public claimOverviewUrl:any;
  public overviewData:any;
  public resRecieved:boolean=false;
  public subscription: Subscription;
  // public claimNumber:any;
  @Input() queryParams:any;
  @Output() getOverviewResponseEvent:EventEmitter<any>=new EventEmitter();
  @Input()  claimNumber:any;
  @Input() taskNumber:any;
   constructor(public clientService:ClientService, public commonTransformerService: CommonTransformerService,
    public applicationStateService:ApplicationStateService ) { 
     this.taskOverviewUrl=environment.taskOverviewUrl;
     this.claimOverviewUrl=environment.claimOverviewUrl;
     
   }
 
   ngOnInit() {   
       this.getOverviewData();
   }
   getOverviewData(){ 
      // if(this.clientService.getQueryParams().claimNumber!="" && (this.clientService.getQueryParams().taskNumber==null || this.clientService.getQueryParams().taskNumber=="0")){
      //   this.getClaimOverViewData();
      // }else{
      //   this.getTaskOverviewData();
      // }    

    if(this.claimNumber!=="" && this.taskNumber===undefined){
        this.getClaimOverViewData();
      } 
      else{
          this.getTaskOverviewData();
      }
   }

   getTaskOverviewData(){
      // let url= this.taskOverviewUrl + this.clientService.getQueryParams().taskNumber; 
       let url= this.taskOverviewUrl + this.taskNumber; 
      this.clientService.setUrl(url);
      this.clientService.getClientData().subscribe(res=>{
        this.overviewData=res.sectionDetails[0];
        // this.resRecieved=true;
        // this.getOverviewResponseEvent.emit(this.resRecieved)
        this.clientService.setOverviewData( this.overviewData);
      })
   }

   getClaimOverViewData(){
    // let url= this.claimOverviewUrl + this.clientService.getQueryParams().claimNumber; 
    let url= this.claimOverviewUrl + this.claimNumber; 
    this.clientService.setUrl(url);
    this.clientService.getClientData().subscribe(res=>{
      this.overviewData=res;
      this.resRecieved=true;
      this.getOverviewResponseEvent.emit(this.resRecieved)
      this.clientService.setOverviewData( this.overviewData)     
    })
   }

}
