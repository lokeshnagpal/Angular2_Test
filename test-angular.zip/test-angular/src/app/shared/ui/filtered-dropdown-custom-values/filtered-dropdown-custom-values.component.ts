import { Component, OnInit, Input, Output, EventEmitter, SimpleChanges } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Observable, Subject } from 'rxjs';
import { map, startWith, debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { ClientService } from 'src/app/services/client.service';

@Component({
  selector: 'app-filtered-dropdown-custom-values',
  templateUrl: './filtered-dropdown-custom-values.component.html',
  styleUrls: ['./filtered-dropdown-custom-values.component.scss']
})
export class FilteredDropdownCustomValuesComponent implements OnInit {

  @Input() label;
  @Input() url;
  @Input() attr?;
  @Input() baseValue?;
  @Input() icon?;
  @Input() hint?;
  @Input() fontSize15?;
  @Input() mandatory?: boolean = false;
  @Output() valueChangeEvent = new EventEmitter();

  public options: any[] = [];
  public filteredOptions: Observable<any[]>;
  public myControl: FormControl;
  private subject: Subject<string> = new Subject();
  public isLoading: boolean = false;

  constructor(public clientService: ClientService) {
    this.myControl = new FormControl();
  }

  ngOnInit() {
    this.subject.pipe(debounceTime(300), distinctUntilChanged(),
    switchMap((query) => {
      let response;
      if (query) {
        if (!(this.baseValue && this.baseValue.length > 1 && this.baseValue == query)) {
          response = this.fetchLookupData(query);
        } else {
          response = this.fetchLookupData();
        }
      } else {
        response = this.fetchLookupData();
      }
      return response;
    })).subscribe(response => {
      if (response) {
        this.parseResponse(response);
        this.isLoading = false;
      }
    });
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.baseValue) {
      this.myControl.setValue(this.baseValue);
    }
  }

  fetchLookupData(query?) {
    if (this.url) {
      if (this.attr) {
        const attr = { ...this.attr };
        if (query && query.length > 0) {
          attr.query = query;
        }
        this.isLoading = true;
        this.clientService.setUrl(this.url);
        return this.clientService.postClientData(attr);
      } else {
        let url = this.url;
        if (query && query.length > 0) {
          if (url.charAt(url.length - 1) != '/') {
            url += '/';
          }
          url += query;
        }
        this.isLoading = true;
        this.clientService.setUrl(url);
        return this.clientService.getClientData();
      }
    }
    return null;
  }

  public parseResponse(response) {
    if (response && response.length > 0) {
      this.options = [];
      if (typeof response[0] == 'string') {
        response.forEach(item => {
          this.options.push({'name': item});
        });
      } else {
        response.forEach(item => {
          this.options.push(item);
        });
      }
      this.filteredOptions = this.myControl.valueChanges
        .pipe(
          startWith(''),
          map(value => this._filter(value))
      );
    }
  }

  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();
    return this.options.filter(option => option.name.toLowerCase().includes(filterValue));
  }

  emitChanges(option?) {
    if (option) {
      this.myControl.setValue(option.name);
      this.valueChangeEvent.emit(option);
    }
    this.valueChangeEvent.emit({'name': this.myControl.value});
  }
  
  fetchFilteredLookup() {
    this.subject.next(this.myControl.value);
  }
}
