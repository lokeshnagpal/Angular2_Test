import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FilteredDropdownCustomValuesComponent } from './filtered-dropdown-custom-values.component';

describe('FilteredDropdownCustomValuesComponent', () => {
  let component: FilteredDropdownCustomValuesComponent;
  let fixture: ComponentFixture<FilteredDropdownCustomValuesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FilteredDropdownCustomValuesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FilteredDropdownCustomValuesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
