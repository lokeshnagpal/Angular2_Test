import { environment } from './../../../../environments/environment';
import { Constants } from './../../../util/application.constants';
import { Component, OnInit, Inject } from '@angular/core';
import { BaseComponent } from './../../../shared/ui/base/base.component';
import { Subscription } from 'rxjs';
import { MAT_DIALOG_DATA, MatDialogRef, MatSnackBar } from '@angular/material';

import * as $ from 'jquery';

@Component({
  selector: 'app-editor',
  templateUrl: './editor.component.html',
  styleUrls: ['./editor.component.scss']
})
export class EditorComponent {
  public claimDescriptionData: any;
  public editorTemplateData: any;
  public editorOptions: Object = {
    embedlyKey: 'AA13A5C6D4xC2D2F2C2A29B4A5A8A1B1sg1Ti1LXd2URVJh1DWXG==',
    key: 'AA13A5C6D4xC2D2F2C2A29B4A5A8A1B1sg1Ti1LXd2URVJh1DWXG==',
    // toolbarButtons: ['bold', 'italic', 'underline', 'strikeThrough', 'subscript', 'superscript', '-', 'paragraphFormat', 'align', 'formatOL', 'formatUL', 'indent', 'outdent', '-', 'insertImage', 'insertLink', 'insertFile', 'insertVideo', 'undo', 'redo'],
    // toolbarButtons: ['bold', 'italic', 'underline', 'strikeThrough', 'subscript', 'superscript', 'paragraphFormat', 'align', 'formatOL', 'formatUL', 'indent', 'outdent','undo', 'redo'],
    toolbarButtons: Constants.TOOLBAR_OPTIONS,
    heightMin: 286,
    heightMax: 286,
    imageUploadParam: 'image_param',
    imageDefaultWidth: 200,
    // Set the image upload URL.
    imageUploadURL: environment.uploadUrl,
    // Additional upload params.
    imageUploadParams: { id: 'my_editor' },
    // Set request type.
    imageUploadMethod: 'POST',
    // Set max image size to 5MB.
    imageMaxSize: 5 * 1024 * 1024,
    // Allow to upload PNG and JPG.
    imageAllowedTypes: ['jpeg', 'jpg', 'png'],
  };
  constructor( @Inject(MAT_DIALOG_DATA) public data, @Inject(MatDialogRef) public dialogRef: MatDialogRef<EditorComponent>) {

    dialogRef.disableClose = true;
  }
  ngOnInit() {
    this.claimDescriptionData = this.data.editorValue;
    this.editorTemplateData = this.data.editorTemplate;
  }

  saveDraft() {
    this.dialogRef.close(this.claimDescriptionData);
  }
  cancelDraft() {
    this.dialogRef.close(this.data.editorValue);
  }

}
