import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import {OverviewDesktopComponent } from './overview-desktop.component';

describe('OverviewComponent', () => {
  let component: OverviewDesktopComponent;
  let fixture: ComponentFixture<OverviewDesktopComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [OverviewDesktopComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OverviewDesktopComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
