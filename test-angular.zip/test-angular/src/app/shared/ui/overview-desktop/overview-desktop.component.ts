import { ApplicationStateService } from './../../../util/application.state.service';
import { OverviewComponent } from './../overview/overview.component';

import { Component, OnInit, Output, EventEmitter, Input, OnDestroy, SimpleChanges } from '@angular/core';
import { ClientService } from 'src/app/services/client.service';
import { CommonTransformerService } from 'src/app/util/common-transformer.service';
import { BaseComponent } from '../base/base.component';
import { Router } from '@angular/router';

@Component({
  selector: 'app-overview-desktop',
  templateUrl: './overview-desktop.component.html',
  styleUrls: ['./overview-desktop.component.scss']
})
export class OverviewDesktopComponent extends OverviewComponent implements OnInit {

  public overviewData: any;
  public isClaimOverview:boolean=true;
  // public isExpanded: boolean = false;
  @Input() claimNumber:string
  @Input() expanded?: boolean = true;
  @Input() fullOverview?: boolean = true;
  // public claimDescriptionData: string;
  constructor(public clientService: ClientService, public commonTransformerService: CommonTransformerService,
  public applicationStateService: ApplicationStateService, public baseComponent: BaseComponent,  private router: Router) {
    super(clientService,commonTransformerService,applicationStateService);
  }

  ngOnInit() {
    // this.subscribeToData();
    this.subscription = this.clientService.overviewData.subscribe(res => {
      this.overviewData = res;     
      console.log(this.overviewData, 'data');
      if(res.sectionCode==="TASK_OVERVIEW") {
        this.isClaimOverview=false;
      }   
    });
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
    this.clientService.setOverviewData({})
  }
  public viewFileNavigate(url,tabIndex?) {
    // const obj=this.clientService.getQueryParams();
    const fileNoteUrl:any=window.location.origin +window.location.pathname + '#' + url+'?claimNumber='+this.claimNumber + (tabIndex ? '&tabIndex='+tabIndex : '');
    window.open(fileNoteUrl);
}

getIndicatorHtml(label) {
  return `<span  style="background-color: #DCE2FF; margin: 0px 8px 0px 0px; border-radius: 35px; padding:2px 9px 1px 7px; position: relative; font-family: swissReOtFontRegular; font-size: 12px; color: #333333;">` + label + `</span>`;
}
redirectToDiary(diaryId, diaryStatus) {
  this.router.navigate([''], { queryParams: { claimNumber: diaryId.split('.')[0], redirect: true, diaryId, diaryStatus } });
}
// subscribeToData() {

//   this.subscription = this.baseComponent._getClaimSummary().subscribe(res => {
//     if (res.claimDescription != null) {
//       this.claimDescriptionData = res.claimDescription;
//     }
//   });
// }
}
