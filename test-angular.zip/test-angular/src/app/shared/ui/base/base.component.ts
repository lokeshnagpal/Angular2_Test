import { Component, OnInit, OnDestroy, Injectable } from '@angular/core';
import { Subscription } from 'rxjs';
import { Subject } from 'rxjs';
import { Observable } from 'rxjs/internal/Observable';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';

@Component({
  selector: 'app-base',
  template: ''
})

@Injectable()
export class BaseComponent implements OnInit, OnDestroy {
  public subject = new Subject<any>();
  public getClaimSummaryDetail = new BehaviorSubject<any>({});
  public getRichTextData=new BehaviorSubject<any>({});
  public parent: string;
  constructor() {

  }
  _getSubject() {
    return this.subject;
  }

  public _getClaimSummary(): Observable<any> {
    return this.getClaimSummaryDetail.asObservable();
  }

  public _setClaimSummary(claimSummaryData): void {
    
    this.getClaimSummaryDetail.next(claimSummaryData);
  }

  public _setRichTextContent(richTextData,obj?):void {
    const resultAndOptionalObj:any={
      result:richTextData,
      optional:obj
    }
    this.getRichTextData.next(resultAndOptionalObj);
  }
  public _getRichTextContent(): Observable<any>{
       return this.getRichTextData.asObservable();
      }
  ngOnInit() {
  }

  ngOnDestroy() {

  }



}
