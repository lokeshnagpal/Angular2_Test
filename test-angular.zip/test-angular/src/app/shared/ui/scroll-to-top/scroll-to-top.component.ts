import { Component, OnInit, HostListener, Inject } from '@angular/core';
import { DOCUMENT } from '@angular/common';

@Component({
  selector: 'app-scroll-to-top',
  templateUrl: './scroll-to-top.component.html',
  styleUrls: ['./scroll-to-top.component.scss']
})
export class ScrollToTopComponent implements OnInit {

  windowScrolled: boolean;
  showLimit: number = 200;
  hideLimit: number = 100;

  constructor(@Inject(DOCUMENT) private document: Document) { }

  @HostListener('window:scroll', [])

  onWindowScroll() {
    if (window.pageYOffset > this.showLimit || this.document.documentElement.scrollTop > this.showLimit || this.document.body.scrollTop > this.showLimit) {
      this.windowScrolled = true;
    } else if (this.windowScrolled && (window.pageYOffset < this.hideLimit || document.documentElement.scrollTop < this.hideLimit || document.body.scrollTop < this.hideLimit)) {
      this.windowScrolled = false;
    }
  }

  scrollToTop() {
    window.scrollTo({
      top: 0,
      left: 0,
      behavior: 'smooth'
    });
  }

  ngOnInit() {
  }

}
