import { Component, OnInit,Input } from '@angular/core';
import { ApplicationStateService } from 'src/app/util/application.state.service';

@Component({
  selector: 'app-chips',
  templateUrl: './chips.component.html',
  styleUrls: ['./chips.component.scss']
})
export class ChipsComponent implements OnInit {
@Input("chipsList") chipsList:any;
@Input("headerTag") headerTag:string;
@Input() tagLevel:number;

public chips:any;
  constructor(public appState:ApplicationStateService) { }

  ngOnInit() {
    this.chips=[];   
    if(this.chipsList!==undefined){
      for(let item of this.chipsList){  
        if(this.tagLevel!=undefined){
           if(item.tagLevel===this.tagLevel){
             this.chips.push(item);
           }         
         }    
         else{
           this.chips.push(item);
         }      
       }
    }  

  }

}
