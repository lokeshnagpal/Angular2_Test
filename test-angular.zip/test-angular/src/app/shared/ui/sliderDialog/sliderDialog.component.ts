import { ApplicationStateService } from './../../../util/application.state.service';
import { Component, OnInit ,Input,Output,EventEmitter,Inject,ChangeDetectorRef} from '@angular/core';
import { BaseComponent } from './../../../shared/ui/base/base.component';
import { Subscription } from 'rxjs';
import { MAT_DIALOG_DATA, MatDialogRef, MatSnackBar } from '@angular/material';


@Component({
  selector: 'app-slider',
  templateUrl: './sliderDialog.component.html',
  styleUrls: ['./sliderDialog.scss']
})
export class SliderDialogComponent  implements OnInit {
  public subscription: Subscription;
  public slideValue:any
  public action:any;
  // @Input('sliderData') sliderData:any;
  // @Output() updateSliderData:EventEmitter<any>=new EventEmitter();

  public chartLabelValueData:any;  
  public totalPercentage:any;
  public background:any=['#283693', '#3C5AFD', '#8C9EFF', '#B387FF', '#9576CE', '#6520FF', '#0291EB', '#3FC4FF', '#B3E5FC', '#C6CAEA'];
  public updatedCoinsuranceData:any=[];
  public updateCoins:boolean=true;
  constructor(@Inject(MAT_DIALOG_DATA) public data,
  @Inject(MatDialogRef) public dialogRef: MatDialogRef<SliderDialogComponent>
  ,public ref:ChangeDetectorRef, public applicationStateService: ApplicationStateService) {
    
    
   }


  ngOnInit() {
  this.chartLabelValueData=this.data.labelValue; 
  this.calculateTotalPercentage();
    
  }
  // ngOnChange(){
  //   // console.log(this.chartLabelValueData);
  // }
   
      updateChartData(action){
       this.data.summary.labels=[];
       this.data.summary.values=[];     
        for(let i=0;i<this.data.labelValue.length;i++){
          // if(this.data.labelValue[i].label!="" && this.data.labelValue[i].value!="" ){
            // this.data.summary.labels[i]=this.data.labelValue[i].label;
            // this.data.summary.values[i]=this.data.labelValue[i].value; 
           if(this.data.labelValue[i].name!="" && this.data.labelValue[i].value!="" ){     
            this.data.summary.labels[i]=this.data.labelValue[i].name;
            this.data.summary.values[i]=this.data.labelValue[i].value;       
            this.data.summary.background[i]=this.data.labelValue[i].background;             
          }
          // else{
          //   this.data.labelValue.splice(i,1)
          //   this.data.summary.labels.splice(i,1)
          //   this.data.summary.values.splice(i,1)
          //   this.data.summary.background.splice(i,1)
          // }
        }
        if (action!="Delete")
        this.dialogRef.close(this.data)                 
      }
      deleteRow(index){     
        // this.deletedBackground.push(this.data.labelValue[index])
        this.data.labelValue.splice(index,1);
        this.data.summary.background.splice(index,1);        
        this.updateChartData('Delete');
        this.calculateTotalPercentage();  
      }

      addCoinsurer(){
   
        let colorName:any;
        if(this.chartLabelValueData.length<10){
          let obj:any={
            // label:"",
            name:"",
            value:"",
         
          }
        
          for(let val of this.background){
            let item =this.chartLabelValueData.find(x=>x.background==val)
            if(item==undefined){
              obj.background=val;
              break;
            }
          }
        
          this.chartLabelValueData.push(obj);
        }
       this.calculateTotalPercentage();
      }

      calculateTotalPercentage(){
        this.totalPercentage=0;
        for(let i=0;i<this.chartLabelValueData.length;i++){        
          this.totalPercentage=Number(this.chartLabelValueData[i].value)+ this.totalPercentage;
          if(this.totalPercentage<100 || this.totalPercentage>100){
            this.updateCoins=true;
          }else{
            this.updateCoins=false;
          }
        }
        if(this.chartLabelValueData.length==0){
          this.updateCoins=true;
        }
      }

      preventInput(e,data,index){
           var invalidcharacters = /[^0-9]/gi        
          if (invalidcharacters.test(data)) {         
            this.chartLabelValueData[index].value=data.replace(invalidcharacters, "");    
          }else if(parseInt(data)>100){
            e.preventDefault();
            this.chartLabelValueData[index].value="100"
          }
        else{
          this.chartLabelValueData[index].value =data.toString();  
          // this.calculateTotalPercentage();
        }
        this.calculateTotalPercentage();   
      }
      closeDialog(){     
        this.dialogRef.close();
      }
}
