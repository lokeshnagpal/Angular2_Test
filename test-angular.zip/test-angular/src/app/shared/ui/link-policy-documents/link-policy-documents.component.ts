import { Component, OnInit, Inject } from '@angular/core';
import { CommonTransformerService } from 'src/app/util/common-transformer.service';
import { ClientService } from 'src/app/services/client.service';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { environment } from 'src/environments/environment';
import { ApplicationStateService } from 'src/app/util/application.state.service';

@Component({
  selector: 'app-link-policy-documents',
  templateUrl: './link-policy-documents.component.html',
  styleUrls: ['./link-policy-documents.component.scss']
})
export class LinkPolicyDocumentsDialog implements OnInit {

  public linkedDocumentsIds: string[] = [];
  public documentUrl: string;
  public allDocuments: any[] = [];
  public linkedDocuments: any[] = [];
  public dataSource: any;
  public displayedColumns: string[] = ['document_name', 'launch', 'doc_id', 'created_by', 'document_date', 'linked'];
  public isIE: boolean;
  public tab: string = 'all';
  public changes: any[] = [];
  public attr: any;
  public showProgressBar: boolean = false;

  constructor(@Inject(MAT_DIALOG_DATA) public data: any, @Inject(MatDialogRef) public dialogRef: MatDialogRef<LinkPolicyDocumentsDialog>,
    public clientService: ClientService, public commonTransformerService: CommonTransformerService,
    public applicationStateService: ApplicationStateService) {
      this.isIE = this.applicationStateService.isBrowserIE();
    }
  
    ngOnInit() {
      if (this.data) {
        this.linkedDocumentsIds = [];
        const policy = {
          type: {},
          id: {}
        };
        if (this.data.linkedDocuments) {
          this.data.linkedDocuments.forEach(document => {
            this.linkedDocumentsIds.push(document.docId);
            policy.type[document.docId] = document.docType;
            policy.id[document.docId] = document.id;
          });
        }
        this.documentUrl = this.data.documentUrl;
        this.fetchDocuments(policy);
      }
    }
  
    fetchDocuments(policy) {
      this.showProgressBar = true;
      this.clientService.setUrl(this.documentUrl);
      this.clientService.getClientData().subscribe(response => {
        this.allDocuments = response;
        this.parseData(policy);
      });
    }
  
    parseData(policy) {
      const data = [];
      const linked = [];
      this.allDocuments.forEach(row => {
        const isLinked = this.linkedDocumentsIds.includes(row.doc_id);
        const parameters = {
          'linked': isLinked,
          'type': isLinked ? policy.type[row.doc_id] : null,
          'id': isLinked ? policy.id[row.doc_id] : 0
        };
        if (isLinked) {
          linked.push({...row, ...parameters});
        }
        data.push({...row, ...parameters});
      });
      this.allDocuments = data;
      this.linkedDocuments = linked;
      this.dataSource = data;
      this.showProgressBar = false;
    }
  
    loadDocuments(tab) {
      if(tab.index == 1) {
        this.tab = 'linked';
        this.dataSource = this.linkedDocuments;
      } else {
        this.tab = 'all';
        this.dataSource = this.allDocuments;
      }
    }
  
    dateFormatChange(date) {
      if (date) {
        const split = date.split('-');
        return this.commonTransformerService.dateFormatChange(split[0]+split[1]+split[2]);
      }
    }
  
    launchDocument(document) {
      const url = environment.streamingServlet + '?docId=' + document.doc_id + '&appName=NATIVE&openInline=Y ';
      window.open(url);
    }
  
    linkDocument(document, type) {
      const docId = document.doc_id;
      const present = this.changes.find(doc => doc.doc_id == docId);
      document.type = type;
      document.linked = true;
      if (!present) {
        this.changes.push(document);
      } else {
        present.type = type;
        present.linked = true;
      }
      const linked = this.linkedDocuments.find(doc => doc.doc_id == docId);
      if (linked) {
        linked.type = type;
      } else {
        this.linkedDocuments.push(document);
      }
      if (this.tab == 'linked') {
        this.dataSource = this.linkedDocuments;
      }
    }

    delinkDocument(document) {
      const docId = document.doc_id;
      const present = this.changes.find(doc => doc.doc_id == docId);
      document.linked = false;
      if (!present) {
        this.changes.push(document);
      } else {
        present.linked = false;
      }
      this.linkedDocuments = this.linkedDocuments.filter(doc => doc.doc_id != docId);
      if (this.tab == 'linked') {
        this.dataSource = this.linkedDocuments;
      }
    }
  
    link(documents) {
      if (documents && documents.length > 0) {
        documents.forEach(document => {
          const doc = {
            'claimNumber': this.data.claimNumber,
            'policyNumber': this.data.policyNumber,
            'docId': document.doc_id,
            'docType':  document.type,
            'docName': document.document_name,
            'id': document.id,
            'action': 'LINK'
          };
          this.attr.policyDocDatas.push(doc);
        });
      }
    }
  
    delink(documents) {
      if (documents && documents.length > 0) {
        documents.forEach(document => {
          const doc = {
            'claimNumber': this.data.claimNumber,
            'policyNumber': this.data.policyNumber,
            'docId': document.doc_id,
            'docType':  document.type,
            'docName': document.document_name,
            'id': document.id,
            'action': 'DELINK'
          };
          this.attr.policyDocDatas.push(doc);
        });
      }
    }
  
    close(save?) {
      if (save) {
        const link = [];
        const delink = [];
        this.changes.forEach(document => {
          const wasLinked = this.linkedDocumentsIds.includes(document.doc_id);
          if (wasLinked && !document.linked) {
            delink.push(document);
          } else if (document.linked) {
            link.push(document);
          }
        });
        this.attr = {
          'policyDocDatas': []
        };
        this.link(link);
        this.delink(delink);
        this.showProgressBar = true;
        this.clientService.setUrl(environment.policyDocumentsUrl);
        this.clientService.linkDocuments(this.attr).subscribe(response => {
          this.showProgressBar = false;
          this.dialogRef.close(this.linkedDocuments);
        });
      } else {
        this.dialogRef.close(null);
      }
    }
  }
