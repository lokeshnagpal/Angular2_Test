import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LinkPolicyDocumentsComponent } from './link-policy-documents.component';

describe('LinkPolicyDocumentsComponent', () => {
  let component: LinkPolicyDocumentsComponent;
  let fixture: ComponentFixture<LinkPolicyDocumentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LinkPolicyDocumentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LinkPolicyDocumentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
