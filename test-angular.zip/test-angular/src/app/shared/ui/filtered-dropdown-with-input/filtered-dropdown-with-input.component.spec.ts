import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FilteredDropdownWithInputComponent } from './filtered-dropdown-with-input.component';

describe('FilteredDropdownWithInputComponent', () => {
  let component: FilteredDropdownWithInputComponent;
  let fixture: ComponentFixture<FilteredDropdownWithInputComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FilteredDropdownWithInputComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FilteredDropdownWithInputComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
