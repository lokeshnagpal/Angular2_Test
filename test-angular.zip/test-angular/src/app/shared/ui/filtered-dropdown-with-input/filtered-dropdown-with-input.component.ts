import { Component, OnInit, Input, Output, EventEmitter, SimpleChanges } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';

@Component({
  selector: 'app-filtered-dropdown-with-input',
  templateUrl: './filtered-dropdown-with-input.component.html',
  styleUrls: ['./filtered-dropdown-with-input.component.scss']
})
export class FilteredDropdownWithInputComponent implements OnInit {

  @Input() label;
  @Input() baseValue?;
  @Input() icon?;
  @Input() options: any[];
  @Input() displayAttr?;
  @Input() hint?;
  @Input() fontSize15?;
  @Input() mandatory?: boolean = false;
  @Output() valueChangeEvent = new EventEmitter();

  public filteredOptions: Observable<string[]>;
  public parsedOptions: string[] = [];
  public myControl: FormControl;

  constructor() {
    this.myControl = new FormControl();
  }

  ngOnInit() {
    if (this.options) {
      this.parseOptions();
    }
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.baseValue) {
      this.myControl.setValue(this.baseValue);
    }
    if (changes.options) {
      this.parseOptions();
    }
  }

  parseOptions() {
    this.parsedOptions = [];
    this.options.forEach(option => {
      if (this.displayAttr) {
        this.parsedOptions.push(option[this.displayAttr]);
      } else {
        this.parsedOptions.push(option);
      }
    });
    this.fetchFilteredLookup();
  }

  fetchFilteredLookup() {
    this.filteredOptions = this.myControl.valueChanges
      .pipe(
        startWith(''),
        map(value => this._filter(value))
    );
  }

  private _filter(value: string): string[] {
    if (value && value.length > 0) {
      const filterValue = value.toLowerCase();
      const filteredOptions = [];
      this.parsedOptions.forEach((option, index) => {
        if (option.toLowerCase().includes(filterValue)) {
          filteredOptions.push(this.options[index]);
        }
      });
      return filteredOptions;
    }
    return this.options;
  }

  checkSelectedValue() {
    if (this.myControl.value && this.myControl.value.length > 0) {
      const selected = this.parsedOptions.find(option => option == this.myControl.value);
      if (!selected) {
        this.myControl.setValue('');
      }
    }
  }

  emitChanges(value) {
    this.myControl.setValue(this.displayAttr ? value[this.displayAttr] : value);
    this.valueChangeEvent.emit(value);
  }
}
