import { Component, OnInit, Input, SimpleChanges } from '@angular/core';
import { ClientService } from 'src/app/services/client.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-more-details-sidenav',
  templateUrl: './more-details-sidenav.component.html',
  styleUrls: ['./more-details-sidenav.component.scss']
})
export class MoreDetailsSidenavComponent implements OnInit {

  @Input() location: any;
  public detailList: any[] = [];
  public locationDetails: any;
  public showSidenavProgressBar: boolean = false;

  constructor(private clientService: ClientService) { }

  ngOnInit() {
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.location) {
      this.fetchLocationDetails();
    }
  }

  fetchLocationDetails() {
    if (this.location) {
      // this.locationDetails = null;
      // this.showSidenavProgressBar = true;
      // this.clientService.setUrl(environment.lookupUrl + '/location/' + id);
      // this.clientService.getClientData().subscribe(response => {
      //   console.log('fetchLocationDetails', response);
      //   this.showSidenavProgressBar = false;
        // this.locationDetails = response.location;
        this.locationDetails = {
          'lmsid': '12312314',
          'keyLocation': 'true',
          'countryId': 'USA',
          'countryName': 'United States',
          'constructionYear': '2012',
          'latitude': '29.95445709',
          'longitude': '-95.95445709',
          'totalBuilding': '8840000',
          'totalContent': '26530000',
          'fireProtectionName': 'Sprinkled where necessarry',
          'geoEncodingName': 'Lat/Long as provided',
          'address': {
            'line1': '12525 ELLA BLVD, Houston',
            'line2': 'Texas, 77067'
          }
        };
        this.detailList = [];
        for (const i in this.locationDetails) {
          this.detailList.push({
            'label': i,
            'value': this.locationDetails[i]
          });
        }        
      // });
    }
  }

  getCompleteAddress(address) {
    let completeAddress = '';
    let count = 0;
    for (const i in address) {
      if (count != 0) {
        completeAddress += ', ';
      }
      completeAddress += address[i];
      count++;
    }
    return completeAddress;
  }
}
