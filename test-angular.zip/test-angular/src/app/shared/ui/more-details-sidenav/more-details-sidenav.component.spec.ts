import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MoreDetailsSidenavComponent } from './more-details-sidenav.component';

describe('MoreDetailsSidenavComponent', () => {
  let component: MoreDetailsSidenavComponent;
  let fixture: ComponentFixture<MoreDetailsSidenavComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MoreDetailsSidenavComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MoreDetailsSidenavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
