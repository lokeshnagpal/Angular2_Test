import { ClaimSummaryService } from './../../../screens/claim-summary/claim-summary.service';
import { LLRService } from 'src/app/screens/llr/llr.service';
import { Constants } from './../../../util/application.constants';
import { ApplicationStateService } from './../../../util/application.state.service';
import { Component, OnInit, Input, ChangeDetectorRef} from '@angular/core';
import { BaseComponent } from './../../../shared/ui/base/base.component';
import { Subscription } from 'rxjs';
import { MatSnackBar, MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { EditorComponent } from './../../../shared/ui/editor/editor.component';
import { environment } from './../../../../environments/environment';
import { ElementRef, ViewChild } from '@angular/core';

@Component({
  selector: 'app-rich-text',
  templateUrl: './rich-text.component.html',
  styleUrls: ['./rich-text.component.scss']
})
export class RichTextComponent implements OnInit {

  public subscription: Subscription;
  
 
  @Input() isEdit: boolean;
  
  public editFlag: boolean = false;  
  public section: any;
  @Input() key: any;  

  @Input() descLabel: any;
  @Input() descriptionData:any;

  @ViewChild('parentContent', {static: false})
  parentContent: ElementRef;

  @ViewChild('childContent', {static: false})
  childContent: ElementRef;

  constructor(private service: ClaimSummaryService, public baseComponent: BaseComponent,
    private snackBar: MatSnackBar, public dialog: MatDialog, public applicationState: ApplicationStateService, public llrService: LLRService,private cdRef: ChangeDetectorRef) {  
 
  }

  ngOnInit() {
    
  }
  // ngAfterViewInit(){
  //   // this.cdRef.detectChanges();
  // }

  
  // ngOnDestroy() {
  //   if (this.subscription != undefined) {
  //     this.subscription.unsubscribe();
  //   }
  // }

  //open editor to update claim desc data
  editEditor() {
    this.editFlag = true;
    let dialogRef;
    dialogRef = this.dialog.open(EditorComponent, {
      width: '750px', height: 'auto',
      panelClass: 'rich-text-editor-panel',
      data: {
        editorValue: this.descriptionData,
        editorTemplate: {
          editorLabel: this.descLabel,
          cancel: Constants.CANCEL,
          save: Constants.SAVE_DRAFT
        }
      }
    })
    dialogRef.afterClosed().subscribe(result => {
      this.editFlag = false;
      this.descriptionData = result;    
      let optionalObj:any={
        section:this.section,
        key:this.key
      }       
      
      this.baseComponent._setRichTextContent(result,optionalObj);

    });

  }

  toggleView($event) {

  if (this.parentContent.nativeElement.offsetHeight >46) {
    this.parentContent.nativeElement.style.height = '46px';
    this.childContent.nativeElement.innerHTML =  'VIEW MORE';
        
    } else {
      this.parentContent.nativeElement.style.height = 'auto';
      this.childContent.nativeElement.innerHTML = 'VIEW LESS';
      
    }
     
    }
}

