import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SafeHtmlPipe } from './safe-html.pipe';
import { SafeResourceUrlPipe } from './safe-resource-url.pipe';

@NgModule({
  declarations: [
    SafeHtmlPipe,
    SafeResourceUrlPipe
  ],
  imports: [
    CommonModule
  ],
  exports: [
    SafeHtmlPipe,
    SafeResourceUrlPipe
  ]
})
export class PipesModule { }
