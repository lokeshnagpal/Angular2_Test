import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UiModule } from './ui/ui.module';
import { PipesModule } from './pipes/pipes.module';
import { DirectivesModule } from './directives/directives.module';


@NgModule({

  imports: [
    CommonModule, UiModule, PipesModule, DirectivesModule
  ],
  exports:[
    CommonModule, UiModule, PipesModule, DirectivesModule
  ],
  declarations: []
})
export class SharedModule { }
